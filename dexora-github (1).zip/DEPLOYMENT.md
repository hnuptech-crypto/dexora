# Mettre Dexora IA en ligne — guide de déploiement

Ce guide t'emmène de "ça tourne sur mon ordinateur" à "c'est un vrai site accessible à
n'importe qui, en HTTPS, sur ton propre nom de domaine". Exemple avec DigitalOcean, mais
la même procédure fonctionne sur n'importe quel VPS (Hetzner, OVH, AWS Lightsail, un
serveur dédié...) — c'est juste Docker, aucune dépendance à un hébergeur précis.

**Ce que je ne peux pas faire à ta place** : acheter le nom de domaine, créer le compte
chez l'hébergeur, ou entrer une carte bancaire. Tout le reste (configuration, code,
vérifications) est prêt à l'emploi ci-dessous.

## Vue d'ensemble

```
                    ┌─────────────┐
  Internet ────────▶│    Caddy    │  (HTTPS automatique, ports 80/443)
                    └──────┬──────┘
              ┌────────────┼────────────┐
              ▼            ▼            ▼
        dexora.ai    app.dexora.ai  api.dexora.ai
        (landing)     (dashboard)      (API)
                                          │
                                    ┌─────┴─────┐
                                    ▼           ▼
                                Postgres      Redis
```

Un seul serveur suffit pour démarrer (les 6 services tournent dedans via Docker).

## 1. Acheter un nom de domaine

N'importe quel registrar (Namecheap, OVH, Google Domains, Gandi...). Exemple utilisé
dans ce guide : `dexora.ai` — remplace par le tien partout.

## 2. Créer un serveur (VPS)

Sur [DigitalOcean](https://digitalocean.com) (ou équivalent) :
- Créer un Droplet : Ubuntu 22.04, **minimum 2 Go de RAM** (Postgres + Redis + 3 apps
  Node en même temps — un plan à 1 Go sera trop juste)
- Note l'adresse IP du serveur une fois créé

## 3. Pointer le domaine vers le serveur

Chez ton registrar, dans la gestion DNS du domaine, crée ces enregistrements **A** :

| Type | Nom | Valeur |
|---|---|---|
| A | `@` (ou `dexora.ai`) | IP du serveur |
| A | `www` | IP du serveur |
| A | `app` | IP du serveur |
| A | `api` | IP du serveur |

La propagation DNS peut prendre de quelques minutes à quelques heures.

## 4. Préparer le serveur

Connecte-toi en SSH (`ssh root@<ip-du-serveur>`), puis installe Docker :

```bash
curl -fsSL https://get.docker.com | sh
```

Ouvre uniquement les ports nécessaires (SSH + HTTP/HTTPS) :

```bash
ufw allow OpenSSH
ufw allow 80
ufw allow 443
ufw enable
```

Postgres et Redis ne sont volontairement **pas** exposés publiquement dans
`docker-compose.prod.yml` (pas de mapping de port vers l'hôte) — ils ne sont
joignables que par les autres conteneurs sur le réseau Docker interne.

## 5. Envoyer le code sur le serveur

Depuis ton poste (ou en clonant depuis ton dépôt Git si tu en as un) :

```bash
scp dexora-final.zip root@<ip-du-serveur>:/opt/
ssh root@<ip-du-serveur>
cd /opt && unzip dexora-final.zip -d dexora && cd dexora
```

## 6. Configurer les variables de production

```bash
cp .env.example .env
nano .env
```

En plus des variables habituelles (JWT, OpenAI, WhatsApp...), ajoute celles requises par
`docker-compose.prod.yml` :

```env
POSTGRES_PASSWORD=un-mot-de-passe-solide-et-different-de-dev
ROOT_DOMAIN=dexora.ai
APP_DOMAIN=app.dexora.ai
API_DOMAIN=api.dexora.ai
ACME_EMAIL=toi@dexora.ai
```

`ACME_EMAIL` sert uniquement à Let's Encrypt pour t'avertir en cas de problème de
renouvellement de certificat — utilise une vraie adresse que tu consultes.

## 7. Démarrer

```bash
docker compose -f docker-compose.prod.yml up -d --build
```

Le premier build prend quelques minutes (compilation des 3 apps Next.js/NestJS). Caddy
demande et installe automatiquement les certificats HTTPS pour les domaines configurés
dès qu'il les voit — aucune action manuelle.

## 8. Initialiser la base de données

```bash
docker compose -f docker-compose.prod.yml exec api npx prisma migrate deploy
```

⚠️ Ne lance **pas** `db:seed` en production — le seed crée un compte
`admin@dexora.ai / admin123456` en clair, utile en développement mais pas en prod. Le
premier vrai compte se crée directement sur le site (`https://app.<ton-domaine>/register`).

## 9. Vérifier

- `https://dexora.ai` → la landing page, avec le cadenas HTTPS
- `https://app.dexora.ai/register` → crée ton premier vrai compte
- `https://api.dexora.ai/health` → doit répondre `{"status":"ok",...}`

Si l'un des trois ne répond pas : `docker compose -f docker-compose.prod.yml logs -f <service>`
(`caddy`, `api`, `dashboard` ou `landing`) pour voir l'erreur exacte.

## 10. Connecter WhatsApp pour de vrai

Le webhook a maintenant une vraie URL publique — plus besoin de ngrok. Dans la
configuration de ton app Meta for Developers :

- URL du webhook : `https://api.dexora.ai/api/v1/whatsapp/webhook`
- Verify Token : la valeur de `WHATSAPP_VERIFY_TOKEN` dans ton `.env`

Puis renseigne le Phone Number ID et l'Access Token fournis par Meta dans le dashboard,
sous Réglages → WhatsApp.

## 11. Mettre à jour le site après un changement de code

```bash
cd /opt/dexora
# renvoie le nouveau code (scp ou git pull selon ton flux)
docker compose -f docker-compose.prod.yml up -d --build
docker compose -f docker-compose.prod.yml exec api npx prisma migrate deploy
```

## 12. Sauvegardes (à mettre en place toi-même — pas fait par défaut)

Aucune sauvegarde automatique n'est configurée. À minima, un cron quotidien sur le
serveur :

```bash
docker compose -f docker-compose.prod.yml exec -T postgres pg_dump -U dexora dexora | gzip > /opt/backups/dexora-$(date +%F).sql.gz
```

À adapter avec une rotation (supprimer les sauvegardes de plus de 30 jours) et,
idéalement, un envoi vers un stockage externe (S3...) — ce n'est pas fait ici, c'est une
vraie lacune à combler avant d'y stocker des données clients réelles.

## 13. Limites connues à ce stade

- **Un seul serveur** : pas de haute disponibilité. Si le serveur tombe, tout tombe.
  Suffisant pour démarrer, pas pour une charge sérieuse.
- **Stockage des factures PDF en local** (volume Docker) : ne survit que sur ce serveur.
  À migrer vers S3/Cloudinary si tu passes un jour à plusieurs instances API.
- **Pas de CDN** : les assets Next.js sont servis directement par les conteneurs. Pour un
  trafic important, mettre Cloudflare devant (gratuit, quelques clics) est la première
  amélioration à faire.
- **`deploy.yml` (GitHub Actions)** publie les images Docker mais ne déploie pas
  automatiquement ici — le squelette SSH commenté dans ce fichier permet d'automatiser
  les étapes 11, une fois que tout tourne manuellement et que tu veux passer à
  l'automatisation.

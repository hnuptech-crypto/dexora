# Héberger Dexora IA « via GitHub »

## D'abord, la clarification qui évite de perdre du temps

**GitHub stocke et versionne du code — il ne fait pas tourner d'application.** Pas de
serveur permanent, pas de base de données, pas de process Node.js qui écoute en
continu. La seule exception est **GitHub Pages**, qui sert des fichiers HTML/CSS/JS
100% statiques — et Dexora a une API NestJS avec base de données, des webhooks
WhatsApp, des files d'attente Redis : rien de tout ça n'est statique. Ça ne rentrera
jamais dans GitHub Pages, quelle que soit la configuration.

**Ce que GitHub fait très bien, et que ce projet utilise déjà** :
- Stocker le code, avec historique (`git`)
- Faire tourner la CI (`.github/workflows/ci.yml`) à chaque push — lint, build, tests
- Construire et publier les images Docker (`.github/workflows/deploy.yml`)

**Le chemin qui marche** : GitHub reste la source du code + la CI, et deux hébergeurs
gratuits/pas chers se branchent dessus pour faire tourner l'app à chaque push —
exactement l'expérience "j'héberge depuis GitHub" que tu cherches, juste avec un
exécutant réel derrière.

- **Railway** → API + Postgres + Redis
- **Vercel** → Dashboard + Landing (Next.js — c'est littéralement fait par eux, zéro config)

Les deux : compte gratuit pour démarrer, connexion directe à ton repo GitHub,
redéploiement automatique à chaque `git push`.

## 0. Mettre le code sur GitHub

⚠️ **Avant de commiter** : si ce n'est pas déjà fait (voir `QUICKSTART.md` étape 3),
lance `npm install` à la racine du projet. Ça génère `package-lock.json` — un fichier
que je n'ai jamais pu produire moi-même (aucun accès au registre npm depuis mon
environnement). **Sans lui, `.github/workflows/ci.yml` échouera immédiatement** : il
utilise `npm ci`, qui exige ce fichier verrouillé. Vérifie qu'il apparaît bien dans
`git status` avant de commiter.

Depuis le dossier du projet, sur ta machine :

```bash
cd dexora
npm install          # si pas déjà fait — génère package-lock.json
git init
git add .
git status            # vérifie que package-lock.json est bien listé, pas ignoré
git commit -m "Dexora IA — version initiale"
```

Crée un dépôt vide sur [github.com/new](https://github.com/new) (ne pas cocher
"Initialize with README"), puis :

```bash
git remote add origin https://github.com/<ton-compte>/dexora.git
git branch -M main
git push -u origin main
```

À partir de là, `.github/workflows/ci.yml` se déclenche automatiquement à chaque push.

## 1. API + base de données sur Railway

*(Les libellés exacts de l'interface Railway peuvent avoir légèrement changé depuis la
rédaction de ce guide — la logique ci-dessous reste valable : garder la racine du repo
comme contexte de build, pointer vers `apps/api/Dockerfile`.)*

1. Va sur [railway.app](https://railway.app), connecte-toi avec GitHub
2. **New Project → Deploy from GitHub repo** → sélectionne ton dépôt `dexora`
3. Railway crée un premier service ; configure-le :
   - **Settings → Source** : Root Directory = `/` (racine du repo, important — les
     Dockerfiles sont écrits pour être construits depuis la racine)
   - **Settings → Build** : Builder = Dockerfile, chemin = `apps/api/Dockerfile`
4. **New → Database → Add PostgreSQL** (plugin managé Railway — pas besoin de conteneur
   Postgres séparé)
5. **New → Database → Add Redis** (idem)
6. Dans le service API, onglet **Variables**, ajoute toutes les variables de `.env.example`
   (JWT, OpenAI, WhatsApp...). Pour `DATABASE_URL` et `REDIS_URL`, Railway propose de
   référencer directement les plugins : `${{Postgres.DATABASE_URL}}` et
   `${{Redis.REDIS_URL}}` — pas besoin de les copier-coller à la main
7. Ajoute aussi `CORS_ORIGIN` (renseigne-le une fois que tu as les URLs Vercel à l'étape
   suivante) et `PUBLIC_API_URL` (l'URL Railway du service, ex.
   `https://dexora-api-production.up.railway.app`)
8. **Deploy**. Une fois en ligne, ouvre le Shell du service (bouton dans l'interface
   Railway) et lance :
   ```bash
   npx prisma migrate deploy
   ```
9. Railway te donne une URL publique (`https://....up.railway.app`) — note-la, elle sert
   d'URL d'API pour les deux prochaines étapes. Tu peux brancher un domaine perso dessus
   dans Settings → Networking si tu en as un.

## 2. Dashboard sur Vercel

1. Sur [vercel.com](https://vercel.com), connecte-toi avec GitHub
2. **Add New → Project** → sélectionne le repo `dexora`
3. **Root Directory** : `apps/dashboard` (Vercel détecte Next.js automatiquement, pas de
   config supplémentaire nécessaire)
4. **Environment Variables** : `NEXT_PUBLIC_API_URL` = l'URL Railway de l'étape précédente
5. **Deploy**

## 3. Landing sur Vercel

Même procédure, un deuxième projet Vercel :
1. **Add New → Project** → même repo `dexora`
2. **Root Directory** : `apps/landing`
3. **Environment Variables** : `NEXT_PUBLIC_DASHBOARD_URL` = l'URL Vercel du dashboard
   (étape 2)
4. **Deploy**

## 4. Boucler la boucle CORS

Retourne dans Railway (service API) → Variables → mets à jour `CORS_ORIGIN` avec les
deux URLs Vercel obtenues :

```
CORS_ORIGIN=https://<ton-dashboard>.vercel.app,https://<ta-landing>.vercel.app
```

Railway redéploie automatiquement dès qu'une variable change.

## 5. Vérifier

- Ouvre l'URL Vercel de la landing → clique "Commencer gratuitement" → doit rediriger
  vers le dashboard
- Crée un compte, une entreprise → le catalogue doit se charger (preuve que le dashboard
  parle bien à l'API Railway)
- `<url-railway>/health` doit répondre `{"status":"ok",...}`

## 6. À partir de maintenant

Chaque `git push` sur `main` redéploie automatiquement les trois services — Railway et
Vercel écoutent ton repo GitHub en continu. C'est la CI (`ci.yml`) qui te protège :
si le lint ou les tests échouent sur une pull request, tu le vois avant de merger.

## Domaine personnalisé (optionnel)

Railway et Vercel acceptent tous les deux un domaine perso gratuitement (Settings →
Domains, sur chacun des 3 projets) — même principe que dans `DEPLOYMENT.md`, sans avoir
à gérer toi-même Caddy/HTTPS/serveur : ces plateformes s'en chargent.

## Pourquoi pas `docker-compose.prod.yml` + un VPS, alors ?

Les deux chemins sont valides, pour des besoins différents :

| | Railway + Vercel | VPS + Docker (`DEPLOYMENT.md`) |
|---|---|---|
| Mise en route | ~15 min, aucune administration serveur | ~30-45 min, tu gères le serveur |
| Coût de départ | Gratuit à quelques dollars/mois | Prix du VPS (~6-12$/mois) dès le premier jour |
| Contrôle | Limité à ce que les plateformes exposent | Total |
| Ce qui convient | Démarrer vite, valider le produit | Charge importante, besoins spécifiques (ex. rester à 100% sur une infra que tu maîtrises) |

Pour démarrer et voir Dexora tourner en ligne rapidement, Railway + Vercel est le plus
direct. Rien n'empêche de migrer vers `DEPLOYMENT.md` plus tard si le besoin change.

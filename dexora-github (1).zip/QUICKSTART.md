# Démarrer Dexora IA — guide pas à pas

Ce guide part du principe que tu as extrait le dernier zip livré (`dexora-tests-ci.zip` —
c'est un instantané cumulatif complet du projet, pas besoin des zips précédents).

## 0. Prérequis

- Node.js 18+ et npm 9+
- Docker & Docker Compose
- Un terminal, et éventuellement [ngrok](https://ngrok.com) si tu veux tester le webhook
  WhatsApp avec un vrai compte Meta (voir étape 7)

## 1. Extraire et se placer dans le projet

```bash
unzip dexora-tests-ci.zip -d dexora
cd dexora
```

## 2. Configurer les variables d'environnement

```bash
cp .env.example .env
```

Édite `.env` et renseigne **au minimum** deux secrets JWT (n'importe quelle chaîne
aléatoire de 32+ caractères) :

```bash
# Génère deux secrets aléatoires
openssl rand -hex 32   # → colle le résultat dans JWT_ACCESS_SECRET
openssl rand -hex 32   # → colle le résultat dans JWT_REFRESH_SECRET
```

Tout le reste (`OPENAI_API_KEY`, `WHATSAPP_*`, `MTN_MOMO_*`, etc.) peut rester vide pour
l'instant — ce sont des intégrations externes, l'app démarre sans elles (avec les
fonctionnalités correspondantes simplement inactives).

## 3. Installer les dépendances

```bash
npm install
```

Ceci installe les 3 apps (api, dashboard, landing) d'un coup grâce aux workspaces npm.

## 4. Démarrer Postgres et Redis

```bash
docker compose up -d postgres redis
```

## 5. Base de données : générer, migrer, peupler

```bash
npm run db:generate --workspace=@dexora/api
npm run db:migrate --workspace=@dexora/api
```

⚠️ **C'est la première fois que cette commande tourne réellement** (je n'avais pas
d'accès à une vraie base pendant la construction du projet). Elle va te demander un nom
de migration — tape par exemple `init` et valide. Elle va créer le dossier
`apps/api/prisma/migrations/`. **Commite ce dossier** (`git add apps/api/prisma/migrations`)
une fois que ça fonctionne : sans lui, la CI et un futur déploiement ne pourront pas
recréer la base.

Si cette commande échoue (erreur de schéma, contrainte, etc.), c'est le tout premier
bug réel à corriger — dis-le-moi et je le répare immédiatement.

Ensuite, peuple avec des données de démonstration :

```bash
npm run db:seed --workspace=@dexora/api
```

Ça crée une entreprise de démo, un compte admin (`admin@dexora.ai` / `admin123456`), un
agent, 5 produits et un client de test.

## 6. Démarrer les 3 applications

Depuis la racine, en une seule commande :

```bash
npm run dev
```

Ça lance en parallèle :

| App | URL | Rôle |
|---|---|---|
| API | http://localhost:3000 | Backend NestJS |
| Dashboard | http://localhost:3001 | Interface de gestion |
| Landing | http://localhost:3002 | Site vitrine public |

Tu peux aussi les lancer séparément : `npm run dev:api`, `npm run dev:dashboard`,
`npm run dev:landing`.

## 7. Vérifier que ça fonctionne

1. Ouvre **http://localhost:3001/login**
2. Connecte-toi avec `admin@dexora.ai` / `admin123456` (le compte créé par le seed)
3. Tu devrais arriver sur la Vue d'ensemble avec les 5 produits de démo déjà comptés
4. Va dans **Catalogue** → tu dois voir iPhone 13 Pro Max, Samsung Galaxy S24, etc.
5. Va dans **Réglages** → l'entreprise "Dexora Demo Store" doit apparaître

Si tout ça s'affiche, l'app tourne correctement de bout en bout.

### Tester un compte neuf (parcours complet)

1. Ouvre **http://localhost:3002** (la landing page)
2. Clique sur "Commencer gratuitement" → redirige vers `/register`
3. Crée un compte → tu arrives sur la Vue d'ensemble, qui te demande de créer une
   entreprise (formulaire d'onboarding)
4. Une fois l'entreprise créée, tout se débloque (catalogue, réglages, etc.)

## 8. Ce qui NE fonctionnera PAS sans configuration supplémentaire

Ces fonctionnalités sont codées mais nécessitent de vraies clés externes pour être
réellement utilisables :

| Fonctionnalité | Ce qu'il faut |
|---|---|
| Assistant IA | Une clé `OPENAI_API_KEY` valide (dans `.env`, redémarrer l'API) |
| Réception de messages WhatsApp | Un compte Meta Business + un numéro WhatsApp Business API + un webhook joignable depuis internet (voir ci-dessous) |
| Envoi de messages WhatsApp | Le même compte Meta, configuré dans Réglages → connexion WhatsApp |
| Paiements Mobile Money/Wave | De vrais comptes marchands MTN/Orange/Wave — **et rappel : ces intégrations n'ont jamais été testées contre un vrai sandbox**, prévois du temps de debug |

### Tester le webhook WhatsApp en local (optionnel, pour aller plus loin)

Le webhook doit être joignable depuis internet pour que Meta puisse t'envoyer les
messages. En local, utilise ngrok :

```bash
ngrok http 3000
```

Puis, dans la config Meta for Developers de ton app WhatsApp Business :
- URL du webhook : `https://<ton-sous-domaine-ngrok>.ngrok-free.app/api/v1/whatsapp/webhook`
- Verify Token : la même valeur que `WHATSAPP_VERIFY_TOKEN` dans ton `.env`

Renseigne ensuite dans Réglages → WhatsApp du dashboard le `Phone Number ID` et l'`Access
Token` fournis par Meta pour ton compte.

## 9. Alternative : tout lancer via Docker (sans installer Node en local)

```bash
cp .env.example .env   # + secrets JWT comme à l'étape 2
docker compose up -d --build
```

Ça construit et démarre les 5 services (postgres, redis, api, dashboard, landing).
Migre et peuple la base une fois les conteneurs démarrés :

```bash
docker compose exec api npm run db:migrate:deploy --workspace=@dexora/api
docker compose exec api npm run db:seed --workspace=@dexora/api
```

## 10. Lancer les tests

```bash
npm run test --workspace=@dexora/api          # unitaires (rapides, sans DB)
npm run test:e2e --workspace=@dexora/api      # e2e (nécessite postgres+redis démarrés)
```

---

**En cas de blocage** : dis-moi exactement le message d'erreur et à quelle étape tu es —
je corrige. C'est le passage obligé de "code écrit" à "code qui tourne", et c'est normal
qu'il y ait un ou deux ajustements au premier lancement réel.

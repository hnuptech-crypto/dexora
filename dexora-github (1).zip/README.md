# Dexora IA 🚀

> L'intelligence commerciale au service de votre WhatsApp.

Assistant commercial intelligent qui transforme WhatsApp en boutique automatisée pour les commerçants africains.

## 📦 État du projet

Ce dépôt est construit **par phases**. État actuel :

| Phase | Contenu | Statut |
|---|---|---|
| 1 | Fondations (repo, Docker, schéma Prisma, seed) | ✅ Fait |
| 2 | Auth + gestion des utilisateurs | ✅ Fait |
| 3 | Catalogue produits (CRUD) | ✅ Fait |
| 4 | WhatsApp + webhook (+ module business débloquant) | ✅ Fait |
| 5 | Assistant IA | ✅ Fait |
| 6 | Conversations (inbox), commandes, CRM | ✅ Fait |
| 7 | Relances, campagnes, analytics | ✅ Fait |
| 8 | Dashboard Next.js | ✅ Fait |
| 9 | Landing page | ✅ Fait |
| 10 | CI/CD, tests, déploiement | ✅ Fait (voir limites ci-dessous) |
| Bonus | Dashboard mobile/PWA | ✅ Fait |
| Bonus | Paiements Mobile Money/Wave | 🟡 Fait, non testé sandbox |
| Bonus | Facture PDF | ✅ Fait |
| Backlog | 2FA (mentionnée optionnelle au cahier des charges) | ⬜ À venir |

## 🛠️ Stack

| Composant | Technologie |
|---|---|
| Backend | Node.js, NestJS, TypeScript, Prisma |
| Base de données | PostgreSQL, Redis |
| Frontend | Next.js 14, Tailwind CSS, Framer Motion |
| IA | OpenAI GPT-4 (function calling) |
| WhatsApp | Meta WhatsApp Business API |
| Paiements | MTN MoMo, Orange Money, Wave (non testés sandbox) |
| Infra | Docker, Docker Compose |

## 📁 Structure actuelle

```
dexora/
├── apps/
│   ├── api/              # Backend NestJS (fondations posées)
│   │   ├── src/
│   │   │   ├── modules/  # Modules métier (squelettes, à implémenter)
│   │   │   ├── common/   # Guards/interceptors/filters transverses
│   │   │   ├── config/   # Validation des variables d'environnement (Zod)
│   │   │   ├── prisma/   # PrismaService + PrismaModule
│   │   │   ├── app.module.ts
│   │   │   ├── health.controller.ts
│   │   │   └── main.ts
│   │   ├── prisma/
│   │   │   ├── schema.prisma
│   │   │   └── seed.ts
│   │   ├── Dockerfile
│   │   └── package.json
│   ├── dashboard/         # Next.js — toutes les pages opérationnelles (phase 8)
│   └── landing/           # Next.js — site vitrine public (phase 9)
├── packages/               # Packages partagés (à peupler au besoin)
├── docker-compose.yml
├── docker-compose.prod.yml
├── .env.example
└── package.json
```

## 🚀 Démarrage (phase actuelle)

> 📘 Guide pas à pas complet (installation, vérification, Docker, webhook WhatsApp en
> local, dépannage) : voir **[QUICKSTART.md](./QUICKSTART.md)**.
>
> 🌍 Pour mettre le projet en ligne sur un vrai domaine (HTTPS, serveur, DNS) : voir
> **[DEPLOYMENT.md](./DEPLOYMENT.md)**.
>
> 🐙 Pour héberger en partant de GitHub (Railway + Vercel, sans gérer de serveur) : voir
> **[GITHUB_HOSTING.md](./GITHUB_HOSTING.md)**.


### Prérequis
- Node.js 18+
- Docker & Docker Compose

### Installation

```bash
# 1. Cloner et entrer dans le projet
cd dexora

# 2. Configurer l'environnement
cp .env.example .env
# éditez .env et renseignez au minimum JWT_ACCESS_SECRET et JWT_REFRESH_SECRET

# 3. Installer les dépendances
npm install

# 4. Lancer Postgres + Redis
docker compose up -d postgres redis

# 5. Générer le client Prisma et migrer la base
npm run db:generate
npm run db:migrate
# Première exécution : Prisma va créer le dossier apps/api/prisma/migrations/
# avec la migration initiale — pensez à le commiter (il est nécessaire pour
# que `prisma migrate deploy` fonctionne en CI et en production).

# 6. Peupler la base avec des données de démonstration
npm run db:seed

# 7. Démarrer l'API en mode développement
npm run dev:api
```

L'API démarre sur `http://localhost:3000`. Un contrôleur de santé est disponible sur
`http://localhost:3000/health` (hors préfixe `/api`).

### Identifiants de démonstration (après seed)

| Rôle | Email | Mot de passe |
|---|---|---|
| Propriétaire | admin@dexora.ai | admin123456 |
| Agent | agent@dexora.ai | agent123456 |

## 🧪 Tests & CI/CD (phase 10)

**Tests unitaires** (`npm run test --workspace=@dexora/api`) : couvrent la logique métier la plus sensible plutôt que de viser un pourcentage de couverture arbitraire —
- `AuthService` : inscription, connexion, réinitialisation de mot de passe (mots de passe jamais exposés, tokens jamais renvoyés en clair dans les mauvais cas)
- `ProductsService` : statut calculé (Disponible/Rupture/Archivé), unicité SKU, scoping par entreprise
- `OrdersService` : validation de stock, calcul du total (prix promo prioritaire), génération du numéro de commande, **restauration du stock et des stats client à l'annulation**
- `CampaignsService` : anti-spam (un client déjà contacté il y a moins de 48h est sauté), personnalisation `{{name}}`

Tous mockent `PrismaService` — rapides, aucune base de données requise.

**Tests e2e** (`npm run test:e2e --workspace=@dexora/api`) : parcours complet inscription → connexion → accès à une route protégée, contre une vraie instance NestJS. Contrairement aux tests unitaires, ceux-ci nécessitent une vraie base PostgreSQL et Redis (voir le job `api-e2e` du CI).

⚠️ **Honnêteté sur ce qui a été vérifié** : je n'ai aucun accès réseau/base de données depuis l'environnement où ce code a été écrit. Les tests sont structurellement corrects (syntaxe Jest/NestJS valide, mocks cohérents avec les signatures réelles des services) mais **n'ont jamais été exécutés**. La première chose à faire après récupération du projet : `npm run test --workspace=@dexora/api` et corriger ce qui casse — il est probable qu'il y ait au moins un ou deux ajustements mineurs à faire.

**CI** (`.github/workflows/ci.yml`) : lint + build + tests unitaires pour les 3 apps, plus un job e2e qui démarre Postgres/Redis en services GitHub Actions.

**Publication d'images** (`.github/workflows/deploy.yml`) : build et push des 3 images Docker vers GitHub Container Registry à chaque push sur `main`. **Volontairement sans étape de déploiement final** (SSH vers un serveur, provider cloud...) — cela dépend d'un hébergeur que je ne connais pas. Le squelette à adapter est en commentaire dans le fichier ; l'activer prend quelques minutes une fois l'hébergement choisi et les secrets créés.

**Prérequis avant que la CI passe réellement** :
- Le dossier `apps/api/prisma/migrations/` doit exister et être commité (généré par `npm run db:migrate` en local la première fois — voir section Démarrage). Sans lui, `prisma migrate deploy` échoue en CI.
- `package-lock.json` (racine) doit être commité — généré par `npm install`, jamais produit ici faute d'accès réseau. La CI utilise `npm ci`, qui l'exige.

## 💳 Paiements Mobile Money & Wave

**Statut honnête : écrit conformément aux API publiques documentées de chaque provider, mais jamais testé contre un vrai compte sandbox.** Contrairement au reste de l'application, je n'ai aucun moyen de vérifier ces intégrations en conditions réelles — traitez ce module comme un point de départ solide à valider avec de vraies clés avant toute mise en production, pas comme une fonctionnalité éprouvée.

| Méthode | Route | Description |
|---|---|---|
| POST | `/orders/:orderId/payment/link` | `{ provider: MTN_MOMO\|ORANGE_MONEY\|WAVE }` — crée la session de paiement et envoie automatiquement le lien (ou le push MoMo) au client par WhatsApp |
| GET | `/orders/:orderId/payment/history` | Historique des tentatives de paiement pour cette commande |
| POST | `/payments/webhooks/{mtn-momo,orange-money,wave}` | Callbacks serveur-à-serveur (publics, signature vérifiée quand le provider le permet) |

**Différences importantes entre providers, assumées dans le code :**
- **MTN MoMo** n'a pas de lien de paiement web — c'est un push direct sur le téléphone du client (validation par code MoMo). `checkoutUrl` reste donc vide pour ce provider ; c'est normal, pas un bug.
- **Wave** est le seul des trois à signer ses webhooks par HMAC de façon standard (`Wave-Signature`, vérifié). MTN et Orange n'offrant pas de mécanisme équivalent documenté de façon fiable, leurs webhooks sont journalisés avec un avertissement plutôt que rejetés — à durcir si ces providers exposent un vrai mécanisme de signature en production.
- Chaque entreprise configure ses propres identifiants marchands (Réglages → Paiements Mobile Money) — SaaS multi-tenant, pas de clés partagées.

**Variables d'environnement** ajoutées : `MTN_MOMO_BASE_URL`, `ORANGE_MONEY_BASE_URL`, `WAVE_BASE_URL`, `WAVE_WEBHOOK_SECRET`, `PUBLIC_API_URL` (nécessaire pour construire les URLs de callback envoyées aux providers).

## 🧾 Facture PDF

Génération automatique dès qu'une commande passe au statut **Confirmée** (en best-effort — un échec de rendu PDF n'empêche jamais la confirmation). Générable aussi à la demande via `GET /orders/:id/invoice` (PDF streamé, généré à la volée si absent).

- Rendu via `pdfkit` (en-tête entreprise, coordonnées client, tableau d'articles, sous-total/livraison/remise/total)
- Stockage local sur disque (`apps/api/storage/invoices/`), avec volume Docker dédié (`api_storage`) pour survivre aux redémarrages de conteneur
- **Limite connue** : stockage local = ne fonctionne que pour un déploiement à une seule instance API. Pour une mise à l'échelle horizontale, ce stockage devrait migrer vers S3/Cloudinary (comme le reste des médias) — non fait ici pour rester dans le périmètre réel de ce sprint.

## 📱 Dashboard mobile & installable (PWA)

Le dashboard n'était pas utilisable sur téléphone jusqu'ici (sidebar fixe de 240px, tableaux à 5-6 colonnes). Corrigé de deux façons complémentaires :

**Responsive** :
- La sidebar devient un tiroir coulissant sur mobile (bouton hamburger dans la topbar), et reste fixe sur desktop (`md:` et plus) — un seul composant, pas deux implémentations séparées.
- Toutes les grilles à 2-3 colonnes (fiches, formulaires) repassent en une seule colonne en dessous du breakpoint `sm`/`lg`.
- Les tableaux (Produits, Commandes, Clients) ont désormais une vue carte dédiée sur mobile (`md:hidden`) en plus de la vue tableau desktop (`hidden md:block`) — un tableau à 6 colonnes est illisible sur un écran de 360px, pas de compromis possible ici.
- `h-screen` remplacé par `h-[100dvh]` sur le conteneur racine du layout : évite le bug classique où `100vh` déborde sous la barre d'adresse des navigateurs mobiles.

**Installable (PWA)** :
- `app/manifest.ts` — manifeste web app (nom, couleurs de thème, mode `standalone` qui masque la barre d'adresse une fois installé)
- Icônes générées dynamiquement via `next/og` (`/icon-192`, `/icon-512`, `apple-icon`, favicon) — pas de fichiers PNG statiques à maintenir
- Métadonnées `viewport`/`themeColor`/`appleWebApp` dans le layout racine

Un utilisateur peut donc ajouter le dashboard à l'écran d'accueil de son téléphone (Android : menu navigateur → "Installer l'application" ; iPhone : Partager → "Sur l'écran d'accueil") et l'utiliser en plein écran, sans barre de navigateur, comme une app native.

**Ce que ça n'est pas** : une vraie application native iOS/Android (React Native, accès aux notifications push natives, App Store/Play Store). C'est un choix délibéré — une PWA installable couvre le besoin réel ("gérer ma boutique depuis mon téléphone") sans dupliquer tout le frontend dans un framework mobile séparé. Si une présence sur les stores devient un besoin produit, ce serait un chantier à part entière, pas une extension de ce sprint.

## 🌐 Landing page (phase 9)

Site vitrine public (Next.js + Tailwind + Framer Motion), même système de tokens visuels que le dashboard pour une identité cohérente.

**Contenu :** hero avec démo animée (une conversation WhatsApp qui se transforme en commande structurée — la meilleure façon de montrer ce que fait le produit sans une seule capture d'écran), section problème, 4 étapes de fonctionnement, grille de 8 fonctionnalités, zones desservies, CTA final. Tous les boutons "Commencer gratuitement" pointent vers `${NEXT_PUBLIC_DASHBOARD_URL}/register`.

**Choix assumé** : pas de témoignages clients — en inventer serait fabriquer un faux avis attribué à quelqu'un qui n'existe pas. Pas de grille tarifaire non plus, le cahier des charges n'en spécifiait aucune et en inventer une engagerait le produit sur des chiffres arbitraires.

### Démarrer la landing page

```bash
cp apps/landing/.env.example apps/landing/.env.local
npm run dev --workspace=@dexora/landing
```

Ouvre `http://localhost:3002`.

## 🖥️ Dashboard Next.js (phase 8)

**Pages livrées, toutes branchées sur l'API réelle :**
- Authentification (login/register) + onboarding création d'entreprise
- Vue d'ensemble : statistiques + statut WhatsApp
- Catalogue : liste, recherche, création/édition en modale, archivage
- **Conversations** : inbox filtrable (statut/non-lus), fil de messages, réponse en direct, prise en charge/restitution à l'IA
- **Commandes** : liste filtrable par statut, détail avec progression de statut cliquable (annulation incluse)
- **Clients (CRM)** : liste segmentable (tag/recherche), fiche complète avec historique commandes/conversations, notes internes éditables
- **Campagnes** : cartes d'opportunités (relance en un clic depuis un segment suggéré), création avec aperçu d'audience en temps réel, envoi immédiat/planifié/annulation
- **Analytics** : sélecteur de période, top produits, alertes stock bas/retard, performance IA
- **Réglages** : informations entreprise (utilisées telles quelles par l'IA), connexion WhatsApp Business, prompt système IA + test en direct, gestion d'équipe (invitation, liste)

**Backlog explicite** : notifications temps réel (l'inbox se recharge sur navigation, pas de websocket/polling — à ajouter si l'usage le justifie), pagination au-delà de 50 lignes par page, mode sombre, page de création manuelle de commande côté dashboard (l'API `/orders` le supporte déjà, juste pas encore de formulaire dédié), A/B testing de campagnes (non implémenté côté API non plus — voir section campagnes).

### Démarrer le dashboard

```bash
cp apps/dashboard/.env.example apps/dashboard/.env.local
npm run dev:dashboard
```

Ouvre `http://localhost:3001`. Crée un compte, puis une entreprise — le catalogue et les statistiques s'activent immédiatement.

## 📣 API campagnes & relances (phase 7)

| Méthode | Route | Description |
|---|---|---|
| POST | `/campaigns` | `{ name, type, message, mediaUrl?, segment: {search?,tag?,minSpent?,inactiveSinceDays?}, scheduledAt? }` — sans `scheduledAt`, la campagne reste en brouillon |
| GET | `/campaigns` | Liste (avec segments ciblés) |
| GET | `/campaigns/opportunities` | Signaux de relance : conversations "Intéressé" sans commande depuis 24h, clients inactifs 90j, clients VIP |
| POST | `/campaigns/preview-audience` | Compte les clients correspondant à un filtre, sans rien envoyer |
| PATCH | `/campaigns/:id` | Modification (brouillon uniquement) |
| PATCH | `/campaigns/:id/cancel` | Annulation (sauf déjà envoyée) |
| POST | `/campaigns/:id/send-now` | Envoi immédiat |
| POST | `/campaigns/:id/schedule` | `{ scheduledAt }` — planifie via un job Bull différé (`campaigns-dispatch`) |

**Décisions de conception à connaître :**
- **Personnalisation** : `{{name}}` dans le message est remplacé par le nom du client (ou "cher client" si inconnu). Substitution simple par regex, pas de moteur de templates complet — suffisant pour le besoin exprimé.
- **Anti-spam** : un client ne reçoit pas plus d'une campagne toutes les 48h (`Customer.lastCampaignSentAt`), indépendamment du nombre de campagnes actives. Pas encore de limite globale "X messages par jour" configurable par entreprise — actuellement une constante dans le code.
- **"Panier abandonné"** n'a pas d'équivalent formel dans un flux WhatsApp conversationnel (pas de notion de panier) : on le fait correspondre à une conversation au statut `INTERESTED` restée sans commande. C'est un choix de modélisation assumé, pas une fonctionnalité manquante — documenté ici plutôt que caché.
- **Segmentation** : réutilise les mêmes filtres que `/customers` (tag/dépense min/inactivité). Pas de segments combinés par opérateurs booléens (ET/OU) — un seul jeu de critères par campagne.
- **A/B testing** mentionné dans le cahier des charges : non implémenté (nécessiterait une notion de variantes de message + répartition aléatoire du public, complexité que ce sprint n'a pas couverte).

## 📊 API analytics (phase 7)

| Méthode | Route | Description |
|---|---|---|
| GET | `/analytics/summary?period=today\|week\|month` | Nouvelles conversations, commandes, chiffre d'affaires, taux de conversion, top 5 produits, alertes (stock bas ≤5, commandes en retard >3j), performance IA (taux de succès `AILog`) |

Une seule route paramétrable plutôt que trois routes dédiées (vue quotidienne/hebdo/mensuelle du cahier des charges) — même logique, moins de code à maintenir.

## 📥 API conversations, commandes, CRM (phase 6)

**Conversations (inbox)** — `/conversations`

| Méthode | Route | Description |
|---|---|---|
| GET | `/conversations` | `?status=&unreadOnly=true&assignedToId=&search=&page=&limit=` |
| GET | `/conversations/:id` | Détail + historique complet des messages (marque comme lu) |
| PATCH | `/conversations/:id` | `{ status?, priority? }` |
| PATCH | `/conversations/:id/assign` | `{ agentId? }` — sans `agentId`, l'agent connecté se l'assigne ; assigner **désactive automatiquement l'IA** sur cette conversation |
| PATCH | `/conversations/:id/unassign` | Rend la main à l'IA |
| POST | `/conversations/:id/messages` | Réponse d'un agent, même file d'envoi que le reste |

**Commandes** — `/orders` (la logique de création est désormais partagée avec l'outil IA `create_order` — une seule source de vérité)

| Méthode | Route | Description |
|---|---|---|
| POST | `/orders` | Création manuelle (`customerId` ou `customerPhone`+`customerName`) |
| GET | `/orders` | `?status=&customerId=&page=&limit=` |
| GET | `/orders/:id` | Détail avec articles, client, factures |
| PATCH | `/orders/:id/status` | Gère les horodatages (`confirmedAt`, etc.) ; **CANCELLED restaure le stock et les stats client** |
| PATCH | `/orders/:id/assign` | `{ agentId }` |

**Clients (CRM)** — `/customers`

| Méthode | Route | Description |
|---|---|---|
| GET | `/customers` | Segmentation à la volée : `?tag=VIP&minSpent=50000&inactiveSinceDays=90&search=` |
| GET | `/customers/:id` | Fiche complète : 20 dernières commandes + 10 dernières conversations |
| PATCH | `/customers/:id` | Notes, tags, préférences |

**Backlog** : segments *sauvegardés* et réutilisables (par opposition aux filtres à la volée ci-dessus) — prévu avec le module `campaigns` de la phase suivante, qui en a besoin de toute façon.

## 🤖 API Assistant IA (phase 5)

| Méthode | Route | Accès | Description |
|---|---|---|---|
| GET | `/ai/config` | OWNER/MANAGER | Config actuelle (créée avec un prompt par défaut si absente) |
| PATCH | `/ai/config` | OWNER/MANAGER | `{ systemPrompt?, temperature?, maxTokens?, model?, isActive? }` |
| POST | `/ai/config/test` | OWNER/MANAGER | `{ message }` → prévisualise une réponse sans envoyer de vrai message WhatsApp (outil de recherche catalogue actif, pas de création de commande en mode test) |

**Fonctionnement de bout en bout :**
1. `WhatsappService` émet un événement `whatsapp.message.received` après chaque message client entrant (aucune dépendance directe whatsapp→ai, découplage par `@nestjs/event-emitter`).
2. `AiService` l'écoute, vérifie que l'IA est active pour l'entreprise et **qu'aucun agent humain n'a déjà pris la main** (`conversation.assignedToId`), puis construit le contexte : prompt système + politiques de l'entreprise (livraison/paiement/horaires, toujours à jour) + 12 derniers messages.
3. Appel OpenAI avec 3 outils (function calling) :
   - `search_products` — seule source de vérité pour prix/stock, jamais de réponse "de mémoire"
   - `create_order` — vérifie le stock, calcule le total, décrémente le stock, met à jour le CRM client, génère `DEXORA-YYYYMMDD-XXX`
   - `escalate_to_human` — passe la conversation en priorité HIGH, désactive `aiHandled`
4. La réponse finale part via `WhatsappService.sendAiReply` (même file Bull que les envois manuels).
5. Chaque échange est journalisé dans `AILog` (tokens, temps de réponse, succès/échec) — base du futur tableau "performance IA".

**Backlog** : support multilingue (fon, yoruba — mentionné dans le cahier des charges), qualification structurée des leads (budget/besoin/délai) au-delà du prompt libre, streaming des réponses.

## 🏢 API entreprise (débloquant, ajouté en phase 4)

| Méthode | Route | Accès | Description |
|---|---|---|---|
| POST | `/business` | OWNER sans entreprise | Crée l'entreprise et l'associe au compte |
| GET | `/business/me` | tout membre | Fiche entreprise |
| PATCH | `/business/me` | OWNER/MANAGER | Politique de livraison/paiement, horaires, connexion WhatsApp (`whatsappApiKey`, `whatsappPhoneNumberId`) |

Aucune action particulière requise après `POST /business` : `JwtAccessStrategy`
relit toujours l'utilisateur en base à chaque requête (`request.user.businessId`
reflète donc immédiatement l'entreprise créée, même avec l'access token émis
avant sa création).

## 📲 API WhatsApp (phase 4)

| Méthode | Route | Accès | Description |
|---|---|---|---|
| GET | `/whatsapp/webhook` | publique | Handshake de vérification Meta (`hub.challenge`) |
| POST | `/whatsapp/webhook` | publique, signature HMAC vérifiée | Réception des messages/statuts entrants |
| POST | `/whatsapp/send` | tout membre | Envoi manuel `{ to, content, mediaType?, mediaUrl? }`, mis en file via Bull/Redis |

**Fonctionnement :**
- Chaque message entrant crée/retrouve un `Customer` et une `Conversation` ouverte, puis enregistre un `Message`.
- Les envois sortants sont mis en file (`whatsapp-outbound`, limitée à 20 msg/s par défaut) plutôt qu'appelés en synchrone, pour respecter les limites de débit de l'API Meta et absorber les pics.
- La signature `X-Hub-Signature-256` du webhook est vérifiée avec `WHATSAPP_APP_SECRET` (avertissement en dev si non configuré, jamais en prod).
- Un même déploiement peut servir plusieurs entreprises : le webhook route chaque message vers la bonne entreprise via `whatsappPhoneNumberId`.

**Backlog (hors sprint actuel)** : sessions Baileys (auto-hébergé, alternative à l'API officielle), gestion fine des accusés de lecture/statuts de livraison entrants (`statuses[]` du webhook, actuellement ignoré), UI d'inbox (module `conversations`, phase suivante).

## 🛒 API catalogue produits (phase 3)

| Méthode | Route | Accès | Description |
|---|---|---|---|
| POST | `/products` | OWNER/MANAGER | Crée un produit |
| GET | `/products` | tout membre | Liste paginée : `?search=&category=&status=available|out_of_stock|archived|all&page=&limit=` |
| GET | `/products/:id` | tout membre | Détail (incrémente `viewCount`) |
| PATCH | `/products/:id` | OWNER/MANAGER | Mise à jour partielle |
| DELETE | `/products/:id` | OWNER/MANAGER | Archive (pas de suppression physique — un produit référencé dans une commande ne peut pas être détruit) |

Chaque produit retourne un champ `status` calculé (`Disponible` / `Rupture` / `Archivé`).

**Backlog (hors sprint actuel)** : import/export CSV, génération de lien de partage, upload d'images vers Cloudinary — prévus avec le module `whatsapp`/`storage` quand l'upload de médias sera nécessaire de toute façon.

## 🔑 API d'authentification (phase 2)

Toutes les routes sont préfixées par `/api/v1`. Le JWT est requis par défaut sur
toute l'API ; seules les routes ci-dessous marquées **publique** en sont exemptées.

| Méthode | Route | Accès | Description |
|---|---|---|---|
| POST | `/auth/register` | publique | Crée un compte Propriétaire (sans entreprise associée pour l'instant) |
| POST | `/auth/login` | publique | Retourne `{ user, accessToken, refreshToken }` |
| POST | `/auth/refresh` | refresh token (Bearer) | Fait tourner les tokens |
| POST | `/auth/logout` | access token | Invalide le refresh token stocké |
| POST | `/auth/forgot-password` | publique | Génère un lien de réinitialisation (journalisé en console tant que le SMTP n'est pas câblé) |
| POST | `/auth/reset-password` | publique | `{ token, newPassword }` |
| GET | `/users/me` | access token | Profil de l'utilisateur connecté |
| PATCH | `/users/me` | access token | Met à jour son propre profil (nom, téléphone, avatar) |
| GET | `/users/team` | OWNER/MANAGER | Liste les membres de l'entreprise |
| POST | `/users/team` | OWNER/MANAGER | Invite un membre (rôle MANAGER ou AGENT) |
| GET/PATCH | `/users/team/:id` | OWNER/MANAGER | Consulte/modifie un membre de l'équipe |

**Notes de conception :**
- Les access tokens (15 min par défaut) et refresh tokens (30 jours) sont signés séparément (`JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET`).
- Le refresh token est stocké hashé (bcrypt) côté serveur et tourne à chaque utilisation — un vol de refresh token ne permet donc pas une réutilisation indéfinie.
- `register` crée un utilisateur **sans entreprise** (`businessId: null`). La création/l'association d'une entreprise sera couverte par un futur module `business` ; jusque-là, un Propriétaire ne peut pas encore inviter d'équipe.
- L'authentification à deux facteurs (mentionnée comme optionnelle dans le cahier des charges) n'est pas encore implémentée.

## 🔐 Variables d'environnement essentielles

Voir `.env.example` pour la liste complète. Au minimum pour démarrer l'API :

```env
DATABASE_URL=postgresql://dexora:dexora123@localhost:5432/dexora?schema=public
REDIS_URL=redis://localhost:6379
JWT_ACCESS_SECRET=change-moi-32-caracteres-minimum
JWT_REFRESH_SECRET=change-moi-aussi-32-caracteres
```

## 📄 Licence

MIT — voir [LICENSE](./LICENSE).

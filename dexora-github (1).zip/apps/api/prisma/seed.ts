import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding de la base de données Dexora...');

  // 1. Business de démonstration
  const business = await prisma.business.create({
    data: {
      name: 'Dexora Demo Store',
      phone: '+22990000000',
      whatsappNumber: '+22990000000',
      description: 'Boutique de démonstration Dexora IA',
      address: 'Cotonou, Bénin',
      currency: 'FCFA',
      timezone: 'Africa/Porto-Novo',
      deliveryPolicy: 'Livraison à domicile sous 24h-48h à Cotonou et environs.',
      paymentPolicy: 'Paiement à la livraison ou via Mobile Money (MTN, Moov).',
      operatingHours: 'Lundi-Samedi : 8h-20h',
    },
  });
  console.log(`✅ Business créé : ${business.name} (${business.id})`);

  // 2. Utilisateur admin (propriétaire)
  const hashedPassword = await bcrypt.hash('admin123456', 10);
  const admin = await prisma.user.create({
    data: {
      email: 'admin@dexora.ai',
      password: hashedPassword,
      name: 'Admin Dexora',
      role: 'OWNER',
      phoneNumber: '+22990000001',
      businessId: business.id,
    },
  });
  console.log(`✅ Utilisateur admin créé : ${admin.email}`);

  // 3. Un agent
  const agentPassword = await bcrypt.hash('agent123456', 10);
  const agent = await prisma.user.create({
    data: {
      email: 'agent@dexora.ai',
      password: agentPassword,
      name: 'Agent Commercial',
      role: 'AGENT',
      phoneNumber: '+22990000003',
      businessId: business.id,
    },
  });
  console.log(`✅ Utilisateur agent créé : ${agent.email}`);

  // 4. Produits de démonstration
  const productsData = [
    {
      name: 'iPhone 13 Pro Max',
      description: 'Smartphone haut de gamme avec écran 6.7 pouces, 128GB, excellent appareil photo.',
      price: 450000,
      promotionPrice: 420000,
      stock: 5,
      sku: 'IP13PM-128',
      category: 'Téléphones',
      subCategory: 'Smartphones',
      images: ['https://via.placeholder.com/500x500'],
      tags: ['iPhone', 'Apple', 'Premium'],
      variants: { couleur: ['Noir', 'Bleu', 'Argent'], capacite: ['128GB', '256GB', '512GB'] },
    },
    {
      name: 'Samsung Galaxy S24',
      description: 'Smartphone avec écran 6.8 pouces, 256GB, charge rapide.',
      price: 380000,
      promotionPrice: 350000,
      stock: 8,
      sku: 'SGS24-256',
      category: 'Téléphones',
      subCategory: 'Smartphones',
      images: ['https://via.placeholder.com/500x500'],
      tags: ['Samsung', 'Android', 'Premium'],
      variants: { couleur: ['Noir', 'Violet', 'Vert'], capacite: ['256GB', '512GB'] },
    },
    {
      name: 'Casque Bluetooth Sony WH-1000XM5',
      description: 'Casque sans fil avec réduction de bruit active, autonomie 30h.',
      price: 120000,
      promotionPrice: 100000,
      stock: 12,
      sku: 'SONY-WH1000XM5',
      category: 'Audio',
      subCategory: 'Casques',
      images: ['https://via.placeholder.com/500x500'],
      tags: ['Sony', 'Audio', 'Bluetooth'],
      variants: { couleur: ['Noir', 'Blanc', 'Beige'] },
    },
    {
      name: 'Montre Connectée Apple Watch Ultra',
      description: 'Montre connectée avec GPS, boîtier 49mm, étanche.',
      price: 280000,
      stock: 3,
      sku: 'AWU-49',
      category: 'Accessoires',
      subCategory: 'Montres',
      images: ['https://via.placeholder.com/500x500'],
      tags: ['Apple', 'Watch', 'Fitness'],
      variants: null,
    },
    {
      name: 'Baskets Nike Air Max 270',
      description: 'Baskets confortables avec amorti Air Max.',
      price: 45000,
      promotionPrice: 39000,
      stock: 20,
      sku: 'NIKE-AM270',
      category: 'Vêtements',
      subCategory: 'Chaussures',
      images: ['https://via.placeholder.com/500x500'],
      tags: ['Nike', 'Sport', 'Baskets'],
      variants: { taille: ['39', '40', '41', '42', '43'], couleur: ['Noir', 'Blanc', 'Rouge'] },
    },
  ];

  for (const data of productsData) {
    const product = await prisma.product.create({ data: { ...data, businessId: business.id } });
    console.log(`✅ Produit créé : ${product.name}`);
  }

  // 5. Configuration de l'IA
  await prisma.aIConfig.create({
    data: {
      businessId: business.id,
      systemPrompt: `Tu es Dexora, un assistant commercial intelligent pour un commerçant africain.
Tu parles français de manière professionnelle mais amicale.
Tu connais parfaitement le catalogue, les prix, les stocks, les politiques de livraison et les horaires du commerçant.
Tu ne dois JAMAIS inventer de prix, de disponibilité ou d'informations.
Si tu ne sais pas, tu dis : "Je ne dispose pas de cette information. Je vais demander à mon responsable et vous répondre."
Tu peux créer des commandes, qualifier des leads, proposer des alternatives.
Tu es proactif : tu demandes des précisions si besoin.`,
      temperature: 0.7,
      maxTokens: 500,
      model: 'gpt-4-turbo-preview',
      isActive: true,
    },
  });
  console.log('✅ Configuration IA créée');

  // 6. Client de démonstration
  const customer = await prisma.customer.create({
    data: {
      phoneNumber: '+22990000002',
      name: 'Jean-Marc Houessou',
      email: 'jm.houessou@example.com',
      address: 'Akpakpa, Cotonou',
      tags: ['Nouveau', 'Intéressé'],
      businessId: business.id,
    },
  });
  console.log(`✅ Client de démo créé : ${customer.name}`);

  // 7. Conversation + message de démonstration
  const conversation = await prisma.conversation.create({
    data: {
      businessId: business.id,
      customerId: customer.id,
      status: 'INTERESTED',
      assignedToId: agent.id,
    },
  });

  await prisma.message.create({
    data: {
      conversationId: conversation.id,
      content: 'Bonjour, avez-vous l\'iPhone 13 Pro Max en stock ?',
      senderType: 'CUSTOMER',
      senderCustomerId: customer.id,
      isDelivered: true,
      isRead: true,
    },
  });

  console.log('✅ Conversation et message de démo créés');

  console.log('\n✅ Seeding terminé avec succès !');
  console.log('🔑 Identifiants de connexion :');
  console.log('   Propriétaire → admin@dexora.ai / admin123456');
  console.log('   Agent        → agent@dexora.ai / agent123456');
}

main()
  .catch((e) => {
    console.error('❌ Erreur lors du seeding :', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

import { SetMetadata } from '@nestjs/common';
import { UserRole } from '@prisma/client';

export const ROLES_KEY = 'roles';

/**
 * Restreint une route aux utilisateurs ayant l'un des rôles fournis.
 * Doit être utilisé conjointement avec RolesGuard.
 *
 * @example
 * @Roles(UserRole.OWNER, UserRole.MANAGER)
 * @Post()
 * createProduct() { ... }
 */
export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES_KEY, roles);

import { z } from 'zod';

export const envValidationSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.string().default('3000'),

  DATABASE_URL: z.string().url(),
  REDIS_URL: z.string().url(),

  JWT_ACCESS_SECRET: z.string().min(16, 'JWT_ACCESS_SECRET doit contenir au moins 16 caractères'),
  JWT_ACCESS_EXPIRES_IN: z.string().default('15m'),
  JWT_REFRESH_SECRET: z.string().min(16, 'JWT_REFRESH_SECRET doit contenir au moins 16 caractères'),
  JWT_REFRESH_EXPIRES_IN: z.string().default('30d'),

  CORS_ORIGIN: z.string().optional(),

  WHATSAPP_API_URL: z.string().url().optional(),
  WHATSAPP_ACCESS_TOKEN: z.string().optional(),
  WHATSAPP_VERIFY_TOKEN: z.string().optional(),
  WHATSAPP_APP_SECRET: z.string().optional(),
  WHATSAPP_PHONE_NUMBER_ID: z.string().optional(),

  OPENAI_API_KEY: z.string().optional(),
  OPENAI_MODEL: z.string().default('gpt-4-turbo-preview'),

  RATE_LIMIT_WINDOW_MS: z.string().default('900000'),
  RATE_LIMIT_MAX: z.string().default('100'),

  MTN_MOMO_API_KEY: z.string().optional(),
  MTN_MOMO_API_SECRET: z.string().optional(),
  MTN_MOMO_SUBSCRIPTION_KEY: z.string().optional(),
  MTN_MOMO_TARGET_ENVIRONMENT: z.string().default('sandbox'),
  MTN_MOMO_BASE_URL: z.string().url().default('https://sandbox.momodeveloper.mtn.com'),
  ORANGE_MONEY_API_KEY: z.string().optional(),
  ORANGE_MONEY_API_SECRET: z.string().optional(),
  ORANGE_MONEY_BASE_URL: z.string().url().default('https://api.orange.com/orange-money-webpay/dev/v1'),
  WAVE_API_KEY: z.string().optional(),
  WAVE_BASE_URL: z.string().url().default('https://api.wave.com/v1'),
  WAVE_WEBHOOK_SECRET: z.string().optional(),
  PUBLIC_API_URL: z.string().url().default('http://localhost:3000'),
});

export type EnvConfig = z.infer<typeof envValidationSchema>;

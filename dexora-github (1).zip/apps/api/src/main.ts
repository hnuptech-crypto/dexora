import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import helmet from 'helmet';
import { json, urlencoded } from 'express';
import { AppModule } from './app.module';

async function bootstrap() {
  // bodyParser désactivé pour être remonté manuellement ci-dessous : on a
  // besoin du corps brut (rawBody) pour vérifier la signature du webhook
  // WhatsApp (X-Hub-Signature-256), qui doit être calculée sur les octets
  // exacts envoyés par Meta, pas sur du JSON re-sérialisé.
  const app = await NestFactory.create(AppModule, { bufferLogs: true, bodyParser: false });

  const captureRawBody = (req: any, _res: any, buf: Buffer) => {
    req.rawBody = buf;
  };
  app.use(json({ verify: captureRawBody }));
  app.use(urlencoded({ extended: true, verify: captureRawBody }));

  const corsOrigins = (process.env.CORS_ORIGIN ?? '')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean);

  app.enableCors({
    origin: corsOrigins.length ? corsOrigins : true,
    credentials: true,
  });

  app.use(helmet());

  app.enableVersioning({ type: VersioningType.URI, defaultVersion: '1' });

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  app.setGlobalPrefix('api', { exclude: ['health'] });

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  await app.listen(port);
  // eslint-disable-next-line no-console
  console.log(`🚀 Dexora API démarrée sur http://localhost:${port}`);
}

bootstrap();

import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { UpdateAiConfigDto } from './dto/update-ai-config.dto';

const DEFAULT_SYSTEM_PROMPT = `Tu es Dexora, un assistant commercial intelligent pour un commerçant africain.
Tu parles français de manière professionnelle mais amicale.
Tu connais parfaitement le catalogue, les prix, les stocks, les politiques de livraison et les horaires du commerçant — utilise toujours l'outil de recherche produit, ne réponds jamais de mémoire sur un prix ou un stock.
Tu ne dois JAMAIS inventer de prix, de disponibilité ou d'informations.
Si tu ne sais pas, tu dis : "Je ne dispose pas de cette information. Je vais demander à mon responsable et vous répondre."
Tu peux créer des commandes une fois le client confirmé, qualifier des leads, proposer des alternatives.
Tu es proactif : tu demandes des précisions si besoin.`;

@Injectable()
export class AiConfigService {
  constructor(private readonly prisma: PrismaService) {}

  async getOrCreate(businessId: string | null) {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");

    const existing = await this.prisma.aIConfig.findUnique({ where: { businessId } });
    if (existing) return existing;

    return this.prisma.aIConfig.create({
      data: { businessId, systemPrompt: DEFAULT_SYSTEM_PROMPT },
    });
  }

  async update(businessId: string | null, dto: UpdateAiConfigDto) {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");

    await this.getOrCreate(businessId); // s'assure qu'une ligne existe déjà
    return this.prisma.aIConfig.update({ where: { businessId }, data: dto });
  }
}

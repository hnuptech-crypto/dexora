import { Body, Controller, Get, Patch, Post, UseGuards } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { AiConfigService } from './ai-config.service';
import { AiService } from './ai.service';
import { UpdateAiConfigDto } from './dto/update-ai-config.dto';
import { TestAiDto } from './dto/test-ai.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import { RolesGuard } from '../../common/guards/roles.guard';
import { AuthenticatedUser } from '../auth/types/authenticated-user.type';

@UseGuards(RolesGuard)
@Roles(UserRole.OWNER, UserRole.MANAGER)
@Controller({ path: 'ai/config', version: '1' })
export class AiController {
  constructor(
    private readonly aiConfigService: AiConfigService,
    private readonly aiService: AiService,
  ) {}

  @Get()
  getConfig(@CurrentUser() user: AuthenticatedUser) {
    return this.aiConfigService.getOrCreate(user.businessId);
  }

  @Patch()
  updateConfig(@CurrentUser() user: AuthenticatedUser, @Body() dto: UpdateAiConfigDto) {
    return this.aiConfigService.update(user.businessId, dto);
  }

  @Post('test')
  test(@CurrentUser() user: AuthenticatedUser, @Body() dto: TestAiDto) {
    if (!user.businessId) {
      return { reply: "Créez d'abord une entreprise (POST /business) avant de tester l'assistant." };
    }
    return this.aiService.testReply(user.businessId, dto.message);
  }
}

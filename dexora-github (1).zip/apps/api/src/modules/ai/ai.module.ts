import { Module } from '@nestjs/common';
import { WhatsappModule } from '../whatsapp/whatsapp.module';
import { OrdersModule } from '../orders/orders.module';
import { AiController } from './ai.controller';
import { AiService } from './ai.service';
import { AiConfigService } from './ai-config.service';
import { OpenAiClient } from './openai.client';
import { SearchProductsTool } from './tools/search-products.tool';
import { CreateOrderTool } from './tools/create-order.tool';
import { EscalateToHumanTool } from './tools/escalate-to-human.tool';
import { MessageReceivedListener } from './listeners/message-received.listener';

@Module({
  imports: [WhatsappModule, OrdersModule],
  controllers: [AiController],
  providers: [
    AiService,
    AiConfigService,
    OpenAiClient,
    SearchProductsTool,
    CreateOrderTool,
    EscalateToHumanTool,
    MessageReceivedListener,
  ],
  exports: [AiService],
})
export class AiModule {}

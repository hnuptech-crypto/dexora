import { Injectable, Logger } from '@nestjs/common';
import type { ChatCompletionMessageParam, ChatCompletionTool } from 'openai/resources/chat/completions';
import { PrismaService } from '../../prisma/prisma.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { OpenAiClient } from './openai.client';
import { SearchProductsTool, searchProductsToolSchema } from './tools/search-products.tool';
import { CreateOrderTool, createOrderToolSchema } from './tools/create-order.tool';
import { EscalateToHumanTool, escalateToHumanToolSchema } from './tools/escalate-to-human.tool';
import { WhatsappMessageReceivedEvent } from '../whatsapp/whatsapp.service';

const MAX_TOOL_ITERATIONS = 4;
const CONTEXT_MESSAGE_COUNT = 12;
const FALLBACK_REPLY =
  "Je ne dispose pas de cette information. Je vais demander à mon responsable et vous répondre.";

@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly openAiClient: OpenAiClient,
    private readonly whatsappService: WhatsappService,
    private readonly searchProductsTool: SearchProductsTool,
    private readonly createOrderTool: CreateOrderTool,
    private readonly escalateToHumanTool: EscalateToHumanTool,
  ) {}

  /** Point d'entrée déclenché par l'événement whatsapp.message.received. */
  async handleIncomingMessage(event: WhatsappMessageReceivedEvent) {
    const startedAt = Date.now();

    const [aiConfig, conversation] = await Promise.all([
      this.prisma.aIConfig.findUnique({ where: { businessId: event.businessId } }),
      this.prisma.conversation.findUnique({ where: { id: event.conversationId } }),
    ]);

    if (!aiConfig || !aiConfig.isActive) return; // Assistant non configuré/désactivé.
    if (!conversation) return;
    if (conversation.assignedToId) return; // Un agent humain a repris la main.

    const lastCustomerMessage = await this.prisma.message.findFirst({
      where: { conversationId: event.conversationId, senderType: 'CUSTOMER' },
      orderBy: { createdAt: 'desc' },
    });
    if (!lastCustomerMessage) return;

    const business = await this.prisma.business.findUnique({ where: { id: event.businessId } });
    if (!business) return;

    try {
      const reply = await this.generateReply(event.businessId, event.conversationId, aiConfig, business);

      await this.whatsappService.sendAiReply(
        event.businessId,
        event.conversationId,
        event.customerPhone,
        reply.text,
      );

      await this.prisma.$transaction([
        this.prisma.message.update({
          where: { id: lastCustomerMessage.id },
          data: { processedByAI: true },
        }),
        this.prisma.conversation.update({
          where: { id: event.conversationId },
          data: { aiHandled: true, unreadCount: 0 },
        }),
        this.prisma.aILog.create({
          data: {
            businessId: event.businessId,
            conversationId: event.conversationId,
            userMessage: lastCustomerMessage.content,
            aiResponse: reply.text,
            tokensUsed: reply.tokensUsed,
            responseTimeMs: Date.now() - startedAt,
            success: true,
          },
        }),
      ]);
    } catch (error) {
      this.logger.error(`Échec de génération de réponse IA : ${(error as Error).message}`);
      await this.prisma.aILog.create({
        data: {
          businessId: event.businessId,
          conversationId: event.conversationId,
          userMessage: lastCustomerMessage.content,
          aiResponse: '',
          success: false,
          errorMessage: (error as Error).message,
          responseTimeMs: Date.now() - startedAt,
        },
      });
    }
  }

  /**
   * Génère une réponse pour un test manuel depuis le dashboard (pas d'envoi
   * WhatsApp réel, pas d'outils de commande pour éviter les commandes
   * accidentelles — uniquement la recherche catalogue).
   */
  async testReply(businessId: string, message: string) {
    const [aiConfig, business] = await Promise.all([
      this.prisma.aIConfig.findUnique({ where: { businessId } }),
      this.prisma.business.findUnique({ where: { id: businessId } }),
    ]);

    if (!aiConfig) {
      return { reply: "Aucune configuration IA trouvée pour cette entreprise. Configurez-la d'abord via /ai/config." };
    }

    const systemPrompt = this.buildSystemPrompt(aiConfig.systemPrompt, business);
    const messages: ChatCompletionMessageParam[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: message },
    ];

    const tools: ChatCompletionTool[] = [searchProductsToolSchema];

    const completion = await this.openAiClient.createChatCompletion({
      model: aiConfig.model,
      temperature: aiConfig.temperature,
      maxTokens: aiConfig.maxTokens,
      messages,
      tools,
    });

    const choice = completion.choices[0];
    if (choice.message.tool_calls?.length) {
      const toolCall = choice.message.tool_calls[0];
      if (toolCall.function.name === 'search_products') {
        const args = JSON.parse(toolCall.function.arguments);
        const result = await this.searchProductsTool.execute(businessId, args);
        return { reply: JSON.stringify(result), note: 'Résultat brut de recherche (mode test).' };
      }
    }

    return { reply: choice.message.content ?? FALLBACK_REPLY };
  }

  private async generateReply(
    businessId: string,
    conversationId: string,
    aiConfig: { systemPrompt: string; temperature: number; maxTokens: number; model: string },
    business: { deliveryPolicy: string | null; paymentPolicy: string | null; operatingHours: string | null; currency: string },
  ): Promise<{ text: string; tokensUsed?: number }> {
    const conversation = await this.prisma.conversation.findUniqueOrThrow({
      where: { id: conversationId },
    });
    const customerId = conversation.customerId;

    const history = await this.prisma.message.findMany({
      where: { conversationId },
      orderBy: { createdAt: 'desc' },
      take: CONTEXT_MESSAGE_COUNT,
    });

    const systemPrompt = this.buildSystemPrompt(aiConfig.systemPrompt, business);

    const messages: ChatCompletionMessageParam[] = [
      { role: 'system', content: systemPrompt },
      ...history
        .reverse()
        .map((m): ChatCompletionMessageParam =>
          m.senderType === 'CUSTOMER'
            ? { role: 'user', content: m.content }
            : { role: 'assistant', content: m.content },
        ),
    ];

    const tools: ChatCompletionTool[] = [
      searchProductsToolSchema,
      createOrderToolSchema,
      escalateToHumanToolSchema,
    ];

    let totalTokens = 0;

    for (let iteration = 0; iteration < MAX_TOOL_ITERATIONS; iteration++) {
      const completion = await this.openAiClient.createChatCompletion({
        model: aiConfig.model,
        temperature: aiConfig.temperature,
        maxTokens: aiConfig.maxTokens,
        messages,
        tools,
      });

      totalTokens += completion.usage?.total_tokens ?? 0;
      const choice = completion.choices[0];

      if (!choice.message.tool_calls?.length) {
        return { text: choice.message.content ?? FALLBACK_REPLY, tokensUsed: totalTokens };
      }

      messages.push(choice.message);

      for (const toolCall of choice.message.tool_calls) {
        const result = await this.executeTool(
          toolCall.function.name,
          JSON.parse(toolCall.function.arguments || '{}'),
          { businessId, conversationId, customerId },
        );

        messages.push({
          role: 'tool',
          tool_call_id: toolCall.id,
          content: JSON.stringify(result),
        });
      }
    }

    return { text: FALLBACK_REPLY, tokensUsed: totalTokens };
  }

  private async executeTool(
    name: string,
    args: Record<string, any>,
    ctx: { businessId: string; conversationId: string; customerId: string },
  ) {
    switch (name) {
      case 'search_products':
        return this.searchProductsTool.execute(ctx.businessId, args as { query: string });
      case 'create_order':
        return this.createOrderTool.execute(ctx.businessId, ctx.customerId, ctx.conversationId, args as any);
      case 'escalate_to_human':
        return this.escalateToHumanTool.execute(ctx.conversationId, args as { reason: string });
      default:
        return { error: `Outil inconnu : ${name}` };
    }
  }

  private buildSystemPrompt(
    basePrompt: string,
    business: {
      deliveryPolicy?: string | null;
      paymentPolicy?: string | null;
      operatingHours?: string | null;
      currency?: string;
    } | null,
  ): string {
    if (!business) return basePrompt;

    const policyLines = [
      business.deliveryPolicy ? `Politique de livraison : ${business.deliveryPolicy}` : null,
      business.paymentPolicy ? `Modes de paiement : ${business.paymentPolicy}` : null,
      business.operatingHours ? `Horaires : ${business.operatingHours}` : null,
      business.currency ? `Devise : ${business.currency}` : null,
    ].filter(Boolean);

    if (policyLines.length === 0) return basePrompt;

    return `${basePrompt}\n\nInformations à jour sur le commerçant :\n${policyLines.join('\n')}`;
  }
}

import { IsString, MaxLength, MinLength } from 'class-validator';

export class TestAiDto {
  @IsString()
  @MinLength(1)
  @MaxLength(2000)
  message: string;
}

import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { AiService } from '../ai.service';
import {
  WHATSAPP_MESSAGE_RECEIVED_EVENT,
  WhatsappMessageReceivedEvent,
} from '../../whatsapp/whatsapp.service';

@Injectable()
export class MessageReceivedListener {
  constructor(private readonly aiService: AiService) {}

  @OnEvent(WHATSAPP_MESSAGE_RECEIVED_EVENT)
  async handle(event: WhatsappMessageReceivedEvent) {
    await this.aiService.handleIncomingMessage(event);
  }
}

import { Injectable } from '@nestjs/common';
import OpenAI from 'openai';
import type { ChatCompletionMessageParam, ChatCompletionTool } from 'openai/resources/chat/completions';

@Injectable()
export class OpenAiClient {
  private readonly client: OpenAI;

  constructor() {
    this.client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }

  async createChatCompletion(params: {
    model: string;
    temperature: number;
    maxTokens: number;
    messages: ChatCompletionMessageParam[];
    tools: ChatCompletionTool[];
  }) {
    return this.client.chat.completions.create({
      model: params.model,
      temperature: params.temperature,
      max_tokens: params.maxTokens,
      messages: params.messages,
      tools: params.tools,
      tool_choice: 'auto',
    });
  }
}

import { Injectable, Logger } from '@nestjs/common';
import type { ChatCompletionTool } from 'openai/resources/chat/completions';
import { OrdersService } from '../../orders/orders.service';

export const createOrderToolSchema: ChatCompletionTool = {
  type: 'function',
  function: {
    name: 'create_order',
    description:
      "Crée une commande une fois que le client a confirmé les produits, quantités et l'adresse de " +
      'livraison. Ne jamais appeler cet outil sans confirmation explicite du client.',
    parameters: {
      type: 'object',
      properties: {
        items: {
          type: 'array',
          description: 'Produits commandés (utiliser les IDs retournés par search_products).',
          items: {
            type: 'object',
            properties: {
              productId: { type: 'string' },
              quantity: { type: 'integer', minimum: 1 },
            },
            required: ['productId', 'quantity'],
          },
        },
        deliveryAddress: { type: 'string', description: 'Adresse de livraison communiquée par le client.' },
        notes: { type: 'string', description: 'Instructions spéciales éventuelles.' },
      },
      required: ['items'],
    },
  },
};

interface CreateOrderArgs {
  items: { productId: string; quantity: number }[];
  deliveryAddress?: string;
  notes?: string;
}

@Injectable()
export class CreateOrderTool {
  private readonly logger = new Logger(CreateOrderTool.name);

  constructor(private readonly ordersService: OrdersService) {}

  async execute(businessId: string, customerId: string, conversationId: string, args: CreateOrderArgs) {
    try {
      const order = await this.ordersService.createOrder({
        businessId,
        customerId,
        conversationId,
        items: args.items,
        deliveryAddress: args.deliveryAddress,
        notes: args.notes,
      });

      return {
        success: true,
        orderNumber: order.orderNumber,
        total: order.total,
        itemCount: order.items.length,
      };
    } catch (error) {
      // Erreurs métier (stock insuffisant, produit inconnu, ...) renvoyées
      // au modèle sous forme de résultat d'outil, pas d'exception — l'IA
      // doit pouvoir en tenir compte dans sa réponse au client.
      this.logger.warn(`create_order refusé : ${(error as Error).message}`);
      return { success: false, error: (error as Error).message };
    }
  }
}

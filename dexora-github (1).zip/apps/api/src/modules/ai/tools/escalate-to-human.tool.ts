import { Injectable } from '@nestjs/common';
import type { ChatCompletionTool } from 'openai/resources/chat/completions';
import { PrismaService } from '../../../prisma/prisma.service';

export const escalateToHumanToolSchema: ChatCompletionTool = {
  type: 'function',
  function: {
    name: 'escalate_to_human',
    description:
      "Transmet la conversation à un agent humain : à utiliser quand le client demande explicitement " +
      "à parler à quelqu'un, quand la demande dépasse les informations disponibles (prix/stock/politique " +
      'inconnus), ou en cas de réclamation/litige.',
    parameters: {
      type: 'object',
      properties: {
        reason: { type: 'string', description: "Raison de l'escalade, pour informer l'agent." },
      },
      required: ['reason'],
    },
  },
};

@Injectable()
export class EscalateToHumanTool {
  constructor(private readonly prisma: PrismaService) {}

  async execute(conversationId: string, args: { reason: string }) {
    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: {
        priority: 'HIGH',
        aiHandled: false,
        summary: `Transmis par l'IA : ${args.reason}`,
      },
    });

    return { success: true, message: 'Conversation transmise à un agent.' };
  }
}

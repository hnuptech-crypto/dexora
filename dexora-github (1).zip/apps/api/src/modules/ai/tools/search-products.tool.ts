import { Injectable } from '@nestjs/common';
import type { ChatCompletionTool } from 'openai/resources/chat/completions';
import { PrismaService } from '../../../prisma/prisma.service';

export const searchProductsToolSchema: ChatCompletionTool = {
  type: 'function',
  function: {
    name: 'search_products',
    description:
      "Recherche des produits dans le catalogue réel du commerçant (nom, catégorie, tags). " +
      "À utiliser SYSTÉMATIQUEMENT avant d'annoncer un prix, une disponibilité ou une caractéristique " +
      "produit — ne jamais répondre de mémoire.",
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Terme de recherche (ex: "iphone", "baskets nike")' },
      },
      required: ['query'],
    },
  },
};

@Injectable()
export class SearchProductsTool {
  constructor(private readonly prisma: PrismaService) {}

  async execute(businessId: string, args: { query: string }) {
    const products = await this.prisma.product.findMany({
      where: {
        businessId,
        isArchived: false,
        OR: [
          { name: { contains: args.query, mode: 'insensitive' } },
          { category: { contains: args.query, mode: 'insensitive' } },
          { subCategory: { contains: args.query, mode: 'insensitive' } },
          { tags: { has: args.query } },
        ],
      },
      take: 5,
      orderBy: { orderCount: 'desc' },
    });

    if (products.length === 0) {
      return { found: false, products: [] };
    }

    return {
      found: true,
      products: products.map((p) => ({
        id: p.id,
        name: p.name,
        price: p.price,
        promotionPrice: p.promotionPrice,
        stock: p.stock,
        inStock: p.stock > 0 && p.isAvailable,
        category: p.category,
        variants: p.variants,
      })),
    };
  }
}

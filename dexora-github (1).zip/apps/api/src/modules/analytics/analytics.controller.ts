import { Controller, Get, Query } from '@nestjs/common';
import { AnalyticsService, AnalyticsPeriod } from './analytics.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../auth/types/authenticated-user.type';

@Controller({ path: 'analytics', version: '1' })
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

  @Get('summary')
  getSummary(@CurrentUser() user: AuthenticatedUser, @Query('period') period?: AnalyticsPeriod) {
    return this.analyticsService.getSummary(user.businessId, period ?? 'today');
  }
}

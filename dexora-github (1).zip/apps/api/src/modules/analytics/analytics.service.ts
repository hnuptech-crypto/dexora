import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

export type AnalyticsPeriod = 'today' | 'week' | 'month';

const LOW_STOCK_THRESHOLD = 5;
const LATE_ORDER_DAYS = 3;

@Injectable()
export class AnalyticsService {
  constructor(private readonly prisma: PrismaService) {}

  async getSummary(businessId: string | null, period: AnalyticsPeriod = 'today') {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");

    const since = this.periodStart(period);

    const [
      newConversations,
      newOrders,
      revenueAgg,
      topProductRows,
      lowStockProducts,
      lateOrders,
      aiLogs,
    ] = await Promise.all([
      this.prisma.conversation.count({ where: { businessId, createdAt: { gte: since } } }),
      this.prisma.order.count({ where: { businessId, createdAt: { gte: since } } }),
      this.prisma.order.aggregate({
        where: { businessId, createdAt: { gte: since }, status: { not: 'CANCELLED' } },
        _sum: { total: true },
      }),
      this.prisma.orderItem.groupBy({
        by: ['productId', 'productName'],
        where: { order: { businessId, createdAt: { gte: since } } },
        _sum: { quantity: true, totalPrice: true },
        orderBy: { _sum: { quantity: 'desc' } },
        take: 5,
      }),
      this.prisma.product.findMany({
        where: { businessId, isArchived: false, stock: { lte: LOW_STOCK_THRESHOLD } },
        orderBy: { stock: 'asc' },
        take: 10,
        select: { id: true, name: true, stock: true },
      }),
      this.prisma.order.count({
        where: {
          businessId,
          status: { notIn: ['DELIVERED', 'CANCELLED'] },
          createdAt: { lt: new Date(Date.now() - LATE_ORDER_DAYS * 24 * 60 * 60 * 1000) },
        },
      }),
      this.prisma.aILog.findMany({ where: { businessId, createdAt: { gte: since } }, select: { success: true } }),
    ]);

    const revenue = revenueAgg._sum.total ?? 0;
    const conversionRate = newConversations > 0 ? newOrders / newConversations : 0;
    const aiResolutionRate = aiLogs.length > 0 ? aiLogs.filter((l) => l.success).length / aiLogs.length : null;

    return {
      period,
      since: since.toISOString(),
      newConversations,
      newOrders,
      revenue,
      conversionRate: Math.round(conversionRate * 1000) / 1000,
      topProducts: topProductRows.map((row) => ({
        productId: row.productId,
        name: row.productName,
        quantitySold: row._sum.quantity ?? 0,
        revenue: row._sum.totalPrice ?? 0,
      })),
      alerts: {
        lowStock: lowStockProducts,
        lateOrders,
      },
      aiPerformance: {
        totalInteractions: aiLogs.length,
        resolutionRate: aiResolutionRate,
      },
    };
  }

  private periodStart(period: AnalyticsPeriod): Date {
    const now = new Date();
    if (period === 'today') return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (period === 'week') return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    return new Date(now.getFullYear(), now.getMonth(), 1); // month
  }
}

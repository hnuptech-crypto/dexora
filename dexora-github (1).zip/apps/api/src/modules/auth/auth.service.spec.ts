import { Test, TestingModule } from '@nestjs/testing';
import { JwtService } from '@nestjs/jwt';
import { ConflictException, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import { AuthService } from './auth.service';
import { PrismaService } from '../../prisma/prisma.service';

describe('AuthService', () => {
  let service: AuthService;
  let prisma: {
    user: {
      findUnique: jest.Mock;
      create: jest.Mock;
      update: jest.Mock;
      findMany: jest.Mock;
    };
  };

  const baseUser = {
    id: 'user_1',
    email: 'merchant@dexora.test',
    name: 'Merchant Test',
    role: 'OWNER',
    businessId: null,
    phoneNumber: null,
    avatar: null,
    isActive: true,
    lastLoginAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    refreshTokenHash: null,
    passwordResetTokenHash: null,
    passwordResetExpiresAt: null,
  };

  beforeEach(async () => {
    prisma = {
      user: {
        findUnique: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        findMany: jest.fn(),
      },
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: PrismaService, useValue: prisma },
        {
          provide: JwtService,
          useValue: { signAsync: jest.fn().mockResolvedValue('signed.jwt.token') },
        },
      ],
    }).compile();

    service = module.get(AuthService);
  });

  describe('register', () => {
    it("refuse l'inscription si l'email existe déjà", async () => {
      prisma.user.findUnique.mockResolvedValue(baseUser);

      await expect(
        service.register({ email: baseUser.email, password: 'motdepasse123', name: 'X' }),
      ).rejects.toThrow(ConflictException);
    });

    it('crée un utilisateur avec un mot de passe hashé et retourne des tokens', async () => {
      prisma.user.findUnique.mockResolvedValue(null);
      const hashedPassword = await bcrypt.hash('motdepasse123', 10);
      prisma.user.create.mockResolvedValue({ ...baseUser, password: hashedPassword });
      prisma.user.update.mockResolvedValue({});

      const result = await service.register({
        email: baseUser.email,
        password: 'motdepasse123',
        name: baseUser.name,
      });

      expect(result.accessToken).toBe('signed.jwt.token');
      expect(result.refreshToken).toBe('signed.jwt.token');
      expect(result.user).not.toHaveProperty('password');
      expect(result.user).not.toHaveProperty('refreshTokenHash');
      expect(prisma.user.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ role: 'OWNER' }) }),
      );
    });
  });

  describe('login', () => {
    it("rejette un email inconnu", async () => {
      prisma.user.findUnique.mockResolvedValue(null);
      await expect(service.login({ email: 'inconnu@dexora.test', password: 'x' })).rejects.toThrow(
        UnauthorizedException,
      );
    });

    it('rejette un mauvais mot de passe', async () => {
      const hashedPassword = await bcrypt.hash('bonmotdepasse', 10);
      prisma.user.findUnique.mockResolvedValue({ ...baseUser, password: hashedPassword });

      await expect(
        service.login({ email: baseUser.email, password: 'mauvaismotdepasse' }),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('rejette un compte désactivé', async () => {
      prisma.user.findUnique.mockResolvedValue({ ...baseUser, isActive: false });
      await expect(service.login({ email: baseUser.email, password: 'peu importe' })).rejects.toThrow(
        UnauthorizedException,
      );
    });

    it('retourne des tokens pour des identifiants valides', async () => {
      const hashedPassword = await bcrypt.hash('motdepasse123', 10);
      prisma.user.findUnique.mockResolvedValue({ ...baseUser, password: hashedPassword });
      prisma.user.update.mockResolvedValue({});

      const result = await service.login({ email: baseUser.email, password: 'motdepasse123' });

      expect(result.accessToken).toBe('signed.jwt.token');
      expect(result.user.email).toBe(baseUser.email);
    });
  });

  describe('resetPassword', () => {
    it('rejette un token qui ne correspond à aucun utilisateur', async () => {
      prisma.user.findMany.mockResolvedValue([]);
      await expect(service.resetPassword('token-invalide', 'nouveaumotdepasse')).rejects.toThrow(
        UnauthorizedException,
      );
    });

    it('accepte un token valide et invalide les sessions existantes', async () => {
      const tokenHash = await bcrypt.hash('bon-token', 10);
      prisma.user.findMany.mockResolvedValue([{ ...baseUser, passwordResetTokenHash: tokenHash }]);
      prisma.user.update.mockResolvedValue({});

      const result = await service.resetPassword('bon-token', 'nouveaumotdepasse123');

      expect(result.success).toBe(true);
      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ refreshTokenHash: null, passwordResetTokenHash: null }),
        }),
      );
    });
  });
});

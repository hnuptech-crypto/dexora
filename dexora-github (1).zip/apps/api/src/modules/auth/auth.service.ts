import {
  ConflictException,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import * as crypto from 'crypto';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { JwtPayload } from './types/jwt-payload.type';

const PASSWORD_SALT_ROUNDS = 10;
const RESET_TOKEN_TTL_MS = 60 * 60 * 1000; // 1 heure

interface TokenPair {
  accessToken: string;
  refreshToken: string;
}

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
  ) {}

  async register(dto: RegisterDto) {
    const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existing) {
      throw new ConflictException('Un compte existe déjà avec cette adresse email.');
    }

    const hashedPassword = await bcrypt.hash(dto.password, PASSWORD_SALT_ROUNDS);

    const user = await this.prisma.user.create({
      data: {
        email: dto.email,
        password: hashedPassword,
        name: dto.name,
        phoneNumber: dto.phoneNumber,
        role: UserRole.OWNER,
      },
    });

    const tokens = await this.issueTokenPair(user.id, user.email, user.role, user.businessId);
    await this.storeRefreshTokenHash(user.id, tokens.refreshToken);

    return { user: this.sanitizeUser(user), ...tokens };
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (!user || !user.isActive) {
      throw new UnauthorizedException('Identifiants incorrects.');
    }

    const passwordMatches = await bcrypt.compare(dto.password, user.password);
    if (!passwordMatches) {
      throw new UnauthorizedException('Identifiants incorrects.');
    }

    const tokens = await this.issueTokenPair(user.id, user.email, user.role, user.businessId);
    await this.storeRefreshTokenHash(user.id, tokens.refreshToken);
    await this.prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    return { user: this.sanitizeUser(user), ...tokens };
  }

  async refresh(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.isActive) {
      throw new UnauthorizedException('Session invalide, veuillez vous reconnecter.');
    }

    const tokens = await this.issueTokenPair(user.id, user.email, user.role, user.businessId);
    await this.storeRefreshTokenHash(user.id, tokens.refreshToken);

    return tokens;
  }

  async logout(userId: string) {
    await this.prisma.user.update({
      where: { id: userId },
      data: { refreshTokenHash: null },
    });
    return { success: true };
  }

  async forgotPassword(email: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });

    // Réponse identique que le compte existe ou non : on n'expose jamais
    // l'existence d'un email dans le système.
    if (!user) {
      this.logger.log(`Demande de réinitialisation pour un email inconnu : ${email}`);
      return { success: true };
    }

    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = await bcrypt.hash(rawToken, PASSWORD_SALT_ROUNDS);

    await this.prisma.user.update({
      where: { id: user.id },
      data: {
        passwordResetTokenHash: tokenHash,
        passwordResetExpiresAt: new Date(Date.now() + RESET_TOKEN_TTL_MS),
      },
    });

    // NOTE : l'envoi d'email transactionnel (SMTP) sera câblé dans une phase
    // ultérieure. En attendant, le lien est journalisé pour permettre les
    // tests manuels en développement.
    this.logger.log(
      `Lien de réinitialisation pour ${email} : /reset-password?token=${rawToken} (valide 1h)`,
    );

    return { success: true };
  }

  async resetPassword(token: string, newPassword: string) {
    const candidates = await this.prisma.user.findMany({
      where: {
        passwordResetTokenHash: { not: null },
        passwordResetExpiresAt: { gt: new Date() },
      },
    });

    let matchedUser = null;
    for (const candidate of candidates) {
      const isMatch = await bcrypt.compare(token, candidate.passwordResetTokenHash as string);
      if (isMatch) {
        matchedUser = candidate;
        break;
      }
    }

    if (!matchedUser) {
      throw new UnauthorizedException('Lien de réinitialisation invalide ou expiré.');
    }

    const hashedPassword = await bcrypt.hash(newPassword, PASSWORD_SALT_ROUNDS);

    await this.prisma.user.update({
      where: { id: matchedUser.id },
      data: {
        password: hashedPassword,
        passwordResetTokenHash: null,
        passwordResetExpiresAt: null,
        refreshTokenHash: null, // invalide toutes les sessions existantes
      },
    });

    return { success: true };
  }

  private async issueTokenPair(
    userId: string,
    email: string,
    role: UserRole,
    businessId: string | null,
  ): Promise<TokenPair> {
    const payload: JwtPayload = { sub: userId, email, role, businessId };

    const accessToken = await this.jwtService.signAsync(payload, {
      secret: process.env.JWT_ACCESS_SECRET,
      expiresIn: process.env.JWT_ACCESS_EXPIRES_IN ?? '15m',
    });

    const refreshToken = await this.jwtService.signAsync(payload, {
      secret: process.env.JWT_REFRESH_SECRET,
      expiresIn: process.env.JWT_REFRESH_EXPIRES_IN ?? '30d',
    });

    return { accessToken, refreshToken };
  }

  private async storeRefreshTokenHash(userId: string, refreshToken: string) {
    const refreshTokenHash = await bcrypt.hash(refreshToken, PASSWORD_SALT_ROUNDS);
    await this.prisma.user.update({ where: { id: userId }, data: { refreshTokenHash } });
  }

  private sanitizeUser<T extends { password: string; refreshTokenHash: string | null; passwordResetTokenHash: string | null }>(
    user: T,
  ) {
    const { password, refreshTokenHash, passwordResetTokenHash, ...safe } = user;
    return safe;
  }
}

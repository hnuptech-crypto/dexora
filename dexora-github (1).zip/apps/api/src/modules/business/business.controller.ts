import { Body, Controller, Get, Patch, Post, UseGuards } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { BusinessService } from './business.service';
import { CreateBusinessDto } from './dto/create-business.dto';
import { UpdateBusinessDto } from './dto/update-business.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import { RolesGuard } from '../../common/guards/roles.guard';
import { AuthenticatedUser } from '../auth/types/authenticated-user.type';

@Controller({ path: 'business', version: '1' })
export class BusinessController {
  constructor(private readonly businessService: BusinessService) {}

  @UseGuards(RolesGuard)
  @Roles(UserRole.OWNER)
  @Post()
  create(@CurrentUser() user: AuthenticatedUser, @Body() dto: CreateBusinessDto) {
    return this.businessService.create(user.userId, user.businessId, dto);
  }

  @Get('me')
  getCurrent(@CurrentUser() user: AuthenticatedUser) {
    return this.businessService.getCurrent(user.businessId);
  }

  @UseGuards(RolesGuard)
  @Roles(UserRole.OWNER, UserRole.MANAGER)
  @Patch('me')
  update(@CurrentUser() user: AuthenticatedUser, @Body() dto: UpdateBusinessDto) {
    return this.businessService.update(user.businessId, dto);
  }
}

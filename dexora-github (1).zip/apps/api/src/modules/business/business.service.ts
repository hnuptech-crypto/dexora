import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateBusinessDto } from './dto/create-business.dto';
import { UpdateBusinessDto } from './dto/update-business.dto';

@Injectable()
export class BusinessService {
  constructor(private readonly prisma: PrismaService) {}

  /** Un utilisateur OWNER sans entreprise peut en créer une, et une seule. */
  async create(userId: string, currentBusinessId: string | null, dto: CreateBusinessDto) {
    if (currentBusinessId) {
      throw new BadRequestException('Cet utilisateur est déjà rattaché à une entreprise.');
    }

    const existing = await this.prisma.business.findUnique({
      where: { whatsappNumber: dto.whatsappNumber },
    });
    if (existing) {
      throw new ConflictException('Ce numéro WhatsApp est déjà utilisé par une autre entreprise.');
    }

    const business = await this.prisma.business.create({
      data: {
        name: dto.name,
        phone: dto.phone,
        whatsappNumber: dto.whatsappNumber,
        address: dto.address,
        description: dto.description,
      },
    });

    await this.prisma.user.update({ where: { id: userId }, data: { businessId: business.id } });

    return business;
  }

  async getCurrent(businessId: string | null) {
    if (!businessId) throw new NotFoundException("Aucune entreprise associée à ce compte.");
    const business = await this.prisma.business.findUnique({ where: { id: businessId } });
    if (!business) throw new NotFoundException('Entreprise introuvable.');
    return business;
  }

  async update(businessId: string | null, dto: UpdateBusinessDto) {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");
    return this.prisma.business.update({ where: { id: businessId }, data: dto });
  }
}

import { IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class UpdateBusinessDto {
  @IsOptional() @IsString() @MinLength(2) @MaxLength(150) name?: string;
  @IsOptional() @IsString() @MaxLength(300) address?: string;
  @IsOptional() @IsString() @MaxLength(1000) description?: string;
  @IsOptional() @IsString() @MaxLength(500) deliveryPolicy?: string;
  @IsOptional() @IsString() @MaxLength(500) paymentPolicy?: string;
  @IsOptional() @IsString() @MaxLength(200) operatingHours?: string;
  @IsOptional() @IsString() @MaxLength(10) currency?: string;
  @IsOptional() @IsString() @MaxLength(50) timezone?: string;

  // Connexion WhatsApp Business API
  @IsOptional() @IsString() @MaxLength(300) whatsappApiKey?: string;
  @IsOptional() @IsString() @MaxLength(100) whatsappPhoneNumberId?: string;

  // Passerelles de paiement (une configuration par entreprise)
  @IsOptional() @IsString() @MaxLength(100) mtnMomoApiUserId?: string;
  @IsOptional() @IsString() @MaxLength(300) mtnMomoApiKey?: string;
  @IsOptional() @IsString() @MaxLength(300) mtnMomoSubscriptionKey?: string;
  @IsOptional() @IsString() @MaxLength(300) orangeMoneyMerchantKey?: string;
  @IsOptional() @IsString() @MaxLength(300) orangeMoneyApiKey?: string;
  @IsOptional() @IsString() @MaxLength(300) waveApiKey?: string;
}

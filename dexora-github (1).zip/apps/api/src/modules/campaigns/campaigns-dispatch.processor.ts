import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';
import { CampaignsService, CAMPAIGNS_DISPATCH_QUEUE } from './campaigns.service';

@Processor(CAMPAIGNS_DISPATCH_QUEUE)
export class CampaignsDispatchProcessor {
  private readonly logger = new Logger(CampaignsDispatchProcessor.name);

  constructor(private readonly campaignsService: CampaignsService) {}

  @Process()
  async handleDispatch(job: Job<{ campaignId: string }>) {
    this.logger.log(`Déclenchement de la campagne ${job.data.campaignId}`);
    await this.campaignsService.executeSend(job.data.campaignId);
  }
}

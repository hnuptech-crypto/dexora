import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { CampaignsService } from './campaigns.service';
import { CreateCampaignDto } from './dto/create-campaign.dto';
import { UpdateCampaignDto } from './dto/update-campaign.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/roles.decorator';
import { RolesGuard } from '../../common/guards/roles.guard';
import { AuthenticatedUser } from '../auth/types/authenticated-user.type';

@UseGuards(RolesGuard)
@Roles(UserRole.OWNER, UserRole.MANAGER)
@Controller({ path: 'campaigns', version: '1' })
export class CampaignsController {
  constructor(private readonly campaignsService: CampaignsService) {}

  @Post()
  create(@CurrentUser() user: AuthenticatedUser, @Body() dto: CreateCampaignDto) {
    return this.campaignsService.create(user.businessId, dto);
  }

  @Get()
  findAll(@CurrentUser() user: AuthenticatedUser) {
    return this.campaignsService.findAll(user.businessId);
  }

  @Get('opportunities')
  getOpportunities(@CurrentUser() user: AuthenticatedUser) {
    return this.campaignsService.getOpportunities(user.businessId);
  }

  @Post('preview-audience')
  previewAudience(
    @CurrentUser() user: AuthenticatedUser,
    @Body() filter: { search?: string; tag?: string; minSpent?: number; inactiveSinceDays?: number },
  ) {
    return this.campaignsService.previewAudience(user.businessId, filter);
  }

  @Get(':id')
  findOne(@CurrentUser() user: AuthenticatedUser, @Param('id') id: string) {
    return this.campaignsService.findOne(id, user.businessId);
  }

  @Patch(':id')
  update(
    @CurrentUser() user: AuthenticatedUser,
    @Param('id') id: string,
    @Body() dto: UpdateCampaignDto,
  ) {
    return this.campaignsService.update(id, user.businessId, dto);
  }

  @Patch(':id/cancel')
  cancel(@CurrentUser() user: AuthenticatedUser, @Param('id') id: string) {
    return this.campaignsService.cancel(id, user.businessId);
  }

  @Post(':id/send-now')
  sendNow(@CurrentUser() user: AuthenticatedUser, @Param('id') id: string) {
    return this.campaignsService.sendNow(id, user.businessId);
  }

  @Post(':id/schedule')
  schedule(
    @CurrentUser() user: AuthenticatedUser,
    @Param('id') id: string,
    @Body('scheduledAt') scheduledAt: string,
  ) {
    return this.campaignsService.schedule(id, user.businessId, scheduledAt);
  }
}

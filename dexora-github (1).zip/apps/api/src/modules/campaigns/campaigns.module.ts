import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { WhatsappModule } from '../whatsapp/whatsapp.module';
import { CustomersModule } from '../customers/customers.module';
import { CampaignsService, CAMPAIGNS_DISPATCH_QUEUE } from './campaigns.service';
import { CampaignsController } from './campaigns.controller';
import { CampaignsDispatchProcessor } from './campaigns-dispatch.processor';

@Module({
  imports: [WhatsappModule, CustomersModule, BullModule.registerQueue({ name: CAMPAIGNS_DISPATCH_QUEUE })],
  controllers: [CampaignsController],
  providers: [CampaignsService, CampaignsDispatchProcessor],
  exports: [CampaignsService],
})
export class CampaignsModule {}

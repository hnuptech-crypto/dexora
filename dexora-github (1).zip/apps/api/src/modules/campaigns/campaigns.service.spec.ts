import { Test, TestingModule } from '@nestjs/testing';
import { getQueueToken } from '@nestjs/bull';
import { CampaignsService, CAMPAIGNS_DISPATCH_QUEUE } from './campaigns.service';
import { PrismaService } from '../../prisma/prisma.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { CustomersService } from '../customers/customers.service';

describe('CampaignsService', () => {
  let service: CampaignsService;
  let prisma: any;
  let whatsappService: { sendMessage: jest.Mock };
  let customersService: { resolveSegment: jest.Mock; countSegment: jest.Mock };

  const campaign = {
    id: 'camp_1',
    businessId: 'biz_1',
    status: 'SCHEDULED',
    message: 'Bonjour {{name}}, promo spéciale !',
    mediaUrl: null,
    targetSegments: [{ filter: { tag: 'VIP' } }],
  };

  beforeEach(async () => {
    prisma = {
      campaign: { findUnique: jest.fn(), update: jest.fn() },
      customer: { update: jest.fn() },
    };
    whatsappService = { sendMessage: jest.fn().mockResolvedValue({}) };
    customersService = { resolveSegment: jest.fn(), countSegment: jest.fn() };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CampaignsService,
        { provide: PrismaService, useValue: prisma },
        { provide: WhatsappService, useValue: whatsappService },
        { provide: CustomersService, useValue: customersService },
        { provide: getQueueToken(CAMPAIGNS_DISPATCH_QUEUE), useValue: { add: jest.fn() } },
      ],
    }).compile();

    service = module.get(CampaignsService);
  });

  describe('executeSend — anti-spam', () => {
    it('saute les clients contactés par une campagne il y a moins de 48h', async () => {
      prisma.campaign.findUnique.mockResolvedValue(campaign);
      prisma.campaign.update.mockResolvedValue(campaign);
      prisma.customer.update.mockResolvedValue({});

      const recentlyContacted = {
        id: 'cust_recent',
        name: 'Client Récent',
        phoneNumber: '+22990000001',
        lastCampaignSentAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // il y a 2h
      };
      const neverContacted = {
        id: 'cust_ok',
        name: 'Client OK',
        phoneNumber: '+22990000002',
        lastCampaignSentAt: null,
      };

      customersService.resolveSegment.mockResolvedValue([recentlyContacted, neverContacted]);

      await service.executeSend('camp_1');

      expect(whatsappService.sendMessage).toHaveBeenCalledTimes(1);
      expect(whatsappService.sendMessage).toHaveBeenCalledWith(
        'biz_1',
        expect.objectContaining({ to: '+22990000002' }),
      );
    });

    it('personnalise le message avec {{name}}', async () => {
      prisma.campaign.findUnique.mockResolvedValue(campaign);
      prisma.campaign.update.mockResolvedValue(campaign);
      prisma.customer.update.mockResolvedValue({});
      customersService.resolveSegment.mockResolvedValue([
        { id: 'cust_1', name: 'Aïssatou', phoneNumber: '+22990000003', lastCampaignSentAt: null },
      ]);

      await service.executeSend('camp_1');

      expect(whatsappService.sendMessage).toHaveBeenCalledWith(
        'biz_1',
        expect.objectContaining({ content: 'Bonjour Aïssatou, promo spéciale !' }),
      );
    });

    it('ne fait rien si la campagne est annulée', async () => {
      prisma.campaign.findUnique.mockResolvedValue({ ...campaign, status: 'CANCELLED' });

      await service.executeSend('camp_1');

      expect(whatsappService.sendMessage).not.toHaveBeenCalled();
    });
  });
});

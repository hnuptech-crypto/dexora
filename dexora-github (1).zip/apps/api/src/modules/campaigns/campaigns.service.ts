import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { CampaignStatus } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { CustomersService, SegmentFilter } from '../customers/customers.service';
import { CreateCampaignDto } from './dto/create-campaign.dto';
import { UpdateCampaignDto } from './dto/update-campaign.dto';

export const CAMPAIGNS_DISPATCH_QUEUE = 'campaigns-dispatch';

/** Anti-spam : un client ne reçoit pas plus d'une campagne par intervalle. */
const MIN_HOURS_BETWEEN_CAMPAIGNS = 48;

@Injectable()
export class CampaignsService {
  private readonly logger = new Logger(CampaignsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly whatsappService: WhatsappService,
    private readonly customersService: CustomersService,
    @InjectQueue(CAMPAIGNS_DISPATCH_QUEUE) private readonly dispatchQueue: Queue<{ campaignId: string }>,
  ) {}

  async create(businessId: string | null, dto: CreateCampaignDto) {
    this.assertHasBusiness(businessId);

    const status: CampaignStatus = dto.scheduledAt ? 'SCHEDULED' : 'DRAFT';

    const campaign = await this.prisma.campaign.create({
      data: {
        businessId: businessId as string,
        name: dto.name,
        type: dto.type,
        message: dto.message,
        mediaUrl: dto.mediaUrl,
        scheduledAt: dto.scheduledAt ? new Date(dto.scheduledAt) : undefined,
        status,
        targetSegments: {
          create: { segmentName: 'Cible principale', filter: dto.segment as object },
        },
      },
      include: { targetSegments: true },
    });

    if (dto.scheduledAt) {
      await this.enqueueDispatch(campaign.id, new Date(dto.scheduledAt));
    }

    return campaign;
  }

  async findAll(businessId: string | null) {
    this.assertHasBusiness(businessId);
    return this.prisma.campaign.findMany({
      where: { businessId: businessId as string },
      include: { targetSegments: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string, businessId: string | null) {
    const campaign = await this.prisma.campaign.findUnique({
      where: { id },
      include: { targetSegments: true },
    });
    if (!campaign || campaign.businessId !== businessId) {
      throw new NotFoundException('Campagne introuvable.');
    }
    return campaign;
  }

  async update(id: string, businessId: string | null, dto: UpdateCampaignDto) {
    const campaign = await this.findOne(id, businessId);
    if (campaign.status !== 'DRAFT') {
      throw new BadRequestException('Seule une campagne en brouillon peut être modifiée.');
    }

    return this.prisma.campaign.update({
      where: { id },
      data: {
        name: dto.name,
        type: dto.type,
        message: dto.message,
        mediaUrl: dto.mediaUrl,
        ...(dto.segment
          ? { targetSegments: { deleteMany: {}, create: { segmentName: 'Cible principale', filter: dto.segment as object } } }
          : {}),
      },
    });
  }

  async cancel(id: string, businessId: string | null) {
    const campaign = await this.findOne(id, businessId);
    if (campaign.status === 'SENT' || campaign.status === 'SENDING') {
      throw new BadRequestException('Impossible d\'annuler une campagne déjà envoyée.');
    }
    return this.prisma.campaign.update({ where: { id }, data: { status: 'CANCELLED' } });
  }

  /** Aperçu du nombre de clients ciblés, sans envoyer quoi que ce soit. */
  async previewAudience(businessId: string | null, filter: SegmentFilter) {
    this.assertHasBusiness(businessId);
    const count = await this.customersService.countSegment(businessId as string, filter);
    return { count };
  }

  /** Envoi immédiat (bouton "Envoyer maintenant" côté dashboard). */
  async sendNow(id: string, businessId: string | null) {
    const campaign = await this.findOne(id, businessId);
    if (campaign.status === 'SENT' || campaign.status === 'SENDING') {
      throw new BadRequestException('Cette campagne a déjà été envoyée.');
    }
    return this.executeSend(campaign.id);
  }

  async schedule(id: string, businessId: string | null, scheduledAt: string) {
    const campaign = await this.findOne(id, businessId);
    if (campaign.status !== 'DRAFT') {
      throw new BadRequestException('Seule une campagne en brouillon peut être planifiée.');
    }

    const date = new Date(scheduledAt);
    await this.prisma.campaign.update({ where: { id }, data: { status: 'SCHEDULED', scheduledAt: date } });
    await this.enqueueDispatch(id, date);
    return this.findOne(id, businessId);
  }

  /** Appelé par le processor de la queue au moment planifié, ou directement par sendNow(). */
  async executeSend(campaignId: string) {
    const campaign = await this.prisma.campaign.findUnique({
      where: { id: campaignId },
      include: { targetSegments: true },
    });
    if (!campaign || campaign.status === 'CANCELLED') return;

    await this.prisma.campaign.update({ where: { id: campaignId }, data: { status: 'SENDING' } });

    const filter = (campaign.targetSegments[0]?.filter ?? {}) as SegmentFilter;
    const audience = await this.customersService.resolveSegment(campaign.businessId, filter);

    const antiSpamThreshold = new Date(Date.now() - MIN_HOURS_BETWEEN_CAMPAIGNS * 60 * 60 * 1000);
    let sentCount = 0;

    for (const customer of audience) {
      if (customer.lastCampaignSentAt && customer.lastCampaignSentAt > antiSpamThreshold) {
        continue; // Anti-spam : déjà contacté récemment par une campagne.
      }

      const personalizedMessage = campaign.message.replace(
        /\{\{\s*name\s*\}\}/gi,
        customer.name ?? 'cher client',
      );

      try {
        await this.whatsappService.sendMessage(campaign.businessId, {
          to: customer.phoneNumber,
          content: personalizedMessage,
          mediaUrl: campaign.mediaUrl ?? undefined,
        });
        await this.prisma.customer.update({
          where: { id: customer.id },
          data: { lastCampaignSentAt: new Date() },
        });
        sentCount++;
      } catch (error) {
        this.logger.warn(`Échec d'envoi campagne à ${customer.phoneNumber} : ${(error as Error).message}`);
      }
    }

    return this.prisma.campaign.update({
      where: { id: campaignId },
      data: { status: 'SENT', sentAt: new Date(), sentCount: { increment: sentCount } },
    });
  }

  /**
   * Signaux d'opportunité pour les relances (section "détection" du cahier
   * des charges). Le concept de "panier abandonné" n'existe pas formellement
   * dans un flux WhatsApp conversationnel : on le fait correspondre à une
   * conversation "Intéressé" restée sans commande — voir README.
   */
  async getOpportunities(businessId: string | null) {
    this.assertHasBusiness(businessId);
    const id = businessId as string;

    const [interestedNoOrder, inactive90Days, vipCustomers] = await Promise.all([
      this.prisma.conversation.count({
        where: {
          businessId: id,
          status: 'INTERESTED',
          lastMessageAt: { lt: new Date(Date.now() - 24 * 60 * 60 * 1000) },
        },
      }),
      this.customersService.countSegment(id, { inactiveSinceDays: 90 }),
      this.customersService.countSegment(id, { tag: 'VIP' }),
    ]);

    return {
      interestedNoOrder: {
        label: 'Conversations "Intéressé" sans commande depuis 24h',
        count: interestedNoOrder,
        // Non ciblable directement en campagne (signal au niveau conversation,
        // pas client) — sert d'indicateur pour une relance manuelle depuis l'inbox.
        suggestedFilter: null,
      },
      inactive90Days: {
        label: 'Clients inactifs depuis 90 jours',
        count: inactive90Days,
        suggestedFilter: { inactiveSinceDays: 90 } as SegmentFilter,
      },
      vipCustomers: {
        label: 'Clients VIP',
        count: vipCustomers,
        suggestedFilter: { tag: 'VIP' } as SegmentFilter,
      },
    };
  }

  private async enqueueDispatch(campaignId: string, sendAt: Date) {
    const delay = Math.max(0, sendAt.getTime() - Date.now());
    await this.dispatchQueue.add({ campaignId }, { delay });
  }

  private assertHasBusiness(businessId: string | null): asserts businessId is string {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");
  }
}

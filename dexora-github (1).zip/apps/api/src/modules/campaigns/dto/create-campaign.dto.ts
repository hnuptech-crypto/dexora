import { IsDateString, IsEnum, IsNumber, IsOptional, IsString, Min, MinLength, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { CampaignType } from '@prisma/client';

class SegmentFilterDto {
  @IsOptional() @IsString() search?: string;
  @IsOptional() @IsString() tag?: string;
  @IsOptional() @IsNumber() @Min(0) minSpent?: number;
  @IsOptional() @IsNumber() @Min(1) inactiveSinceDays?: number;
}

export class CreateCampaignDto {
  @IsString()
  @MinLength(2)
  name: string;

  @IsEnum(CampaignType)
  type: CampaignType;

  @IsString()
  @MinLength(2)
  message: string;

  @IsOptional()
  @IsString()
  mediaUrl?: string;

  /** Filtre de ciblage — voir CustomersService.resolveSegment(). */
  @ValidateNested()
  @Type(() => SegmentFilterDto)
  segment: SegmentFilterDto;

  /** Si fourni, la campagne est planifiée plutôt qu'enregistrée en brouillon. */
  @IsOptional()
  @IsDateString()
  scheduledAt?: string;
}


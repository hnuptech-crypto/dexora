import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ConversationsService } from './conversations.service';
import { UpdateConversationDto } from './dto/update-conversation.dto';
import { QueryConversationDto } from './dto/query-conversation.dto';
import { SendConversationMessageDto } from './dto/send-conversation-message.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../auth/types/authenticated-user.type';

@Controller({ path: 'conversations', version: '1' })
export class ConversationsController {
  constructor(private readonly conversationsService: ConversationsService) {}

  @Get()
  findAll(@CurrentUser() user: AuthenticatedUser, @Query() query: QueryConversationDto) {
    return this.conversationsService.findAll(user.businessId, query);
  }

  @Get(':id')
  findOne(@CurrentUser() user: AuthenticatedUser, @Param('id') id: string) {
    return this.conversationsService.findOne(id, user.businessId);
  }

  @Patch(':id')
  update(
    @CurrentUser() user: AuthenticatedUser,
    @Param('id') id: string,
    @Body() dto: UpdateConversationDto,
  ) {
    return this.conversationsService.update(id, user.businessId, dto);
  }

  @Patch(':id/assign')
  assign(
    @CurrentUser() user: AuthenticatedUser,
    @Param('id') id: string,
    @Body('agentId') agentId?: string,
  ) {
    return this.conversationsService.assign(id, user.businessId, agentId ?? user.userId);
  }

  @Patch(':id/unassign')
  unassign(@CurrentUser() user: AuthenticatedUser, @Param('id') id: string) {
    return this.conversationsService.unassign(id, user.businessId);
  }

  @Post(':id/messages')
  sendMessage(
    @CurrentUser() user: AuthenticatedUser,
    @Param('id') id: string,
    @Body() dto: SendConversationMessageDto,
  ) {
    return this.conversationsService.sendMessage(id, user.businessId, dto);
  }
}

import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { UpdateConversationDto } from './dto/update-conversation.dto';
import { QueryConversationDto } from './dto/query-conversation.dto';
import { SendConversationMessageDto } from './dto/send-conversation-message.dto';

@Injectable()
export class ConversationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly whatsappService: WhatsappService,
  ) {}

  async findAll(businessId: string | null, query: QueryConversationDto) {
    this.assertHasBusiness(businessId);
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;

    const where: Prisma.ConversationWhereInput = { businessId: businessId as string };
    if (query.status) where.status = query.status;
    if (query.unreadOnly === 'true') where.unreadCount = { gt: 0 };
    if (query.assignedToId) where.assignedToId = query.assignedToId;
    if (query.search) {
      where.customer = {
        OR: [
          { name: { contains: query.search, mode: 'insensitive' } },
          { phoneNumber: { contains: query.search } },
        ],
      };
    }

    const [items, total] = await this.prisma.$transaction([
      this.prisma.conversation.findMany({
        where,
        include: {
          customer: true,
          assignedTo: { select: { id: true, name: true, email: true } },
          messages: { orderBy: { createdAt: 'desc' }, take: 1 },
        },
        orderBy: { lastMessageAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.conversation.count({ where }),
    ]);

    return { items, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOne(id: string, businessId: string | null) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id },
      include: {
        customer: true,
        assignedTo: { select: { id: true, name: true, email: true } },
        messages: { orderBy: { createdAt: 'asc' } },
        orders: true,
      },
    });
    if (!conversation || conversation.businessId !== businessId) {
      throw new NotFoundException('Conversation introuvable.');
    }

    if (conversation.unreadCount > 0) {
      await this.prisma.conversation.update({ where: { id }, data: { unreadCount: 0 } });
      conversation.unreadCount = 0;
    }

    return conversation;
  }

  async update(id: string, businessId: string | null, dto: UpdateConversationDto) {
    const conversation = await this.prisma.conversation.findUnique({ where: { id } });
    if (!conversation || conversation.businessId !== businessId) {
      throw new NotFoundException('Conversation introuvable.');
    }
    return this.prisma.conversation.update({ where: { id }, data: dto });
  }

  /**
   * Assigne la conversation à un agent (ou au demandeur si agentId est omis
   * — "je prends cette conversation"). Désactive automatiquement les
   * réponses de l'IA sur cette conversation (voir AiService).
   */
  async assign(id: string, businessId: string | null, agentId: string) {
    const conversation = await this.prisma.conversation.findUnique({ where: { id } });
    if (!conversation || conversation.businessId !== businessId) {
      throw new NotFoundException('Conversation introuvable.');
    }

    const agent = await this.prisma.user.findUnique({ where: { id: agentId } });
    if (!agent || agent.businessId !== businessId) {
      throw new BadRequestException("Cet agent n'appartient pas à votre entreprise.");
    }

    return this.prisma.conversation.update({ where: { id }, data: { assignedToId: agentId } });
  }

  async unassign(id: string, businessId: string | null) {
    const conversation = await this.prisma.conversation.findUnique({ where: { id } });
    if (!conversation || conversation.businessId !== businessId) {
      throw new NotFoundException('Conversation introuvable.');
    }
    return this.prisma.conversation.update({ where: { id }, data: { assignedToId: null } });
  }

  /** Réponse d'un agent depuis l'inbox — passe par la même file d'envoi que le reste. */
  async sendMessage(id: string, businessId: string | null, dto: SendConversationMessageDto) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id },
      include: { customer: true },
    });
    if (!conversation || conversation.businessId !== businessId) {
      throw new NotFoundException('Conversation introuvable.');
    }

    return this.whatsappService.sendMessage(businessId, {
      to: conversation.customer.phoneNumber,
      content: dto.content,
      mediaUrl: dto.mediaUrl,
    });
  }

  private assertHasBusiness(businessId: string | null): asserts businessId is string {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");
  }
}

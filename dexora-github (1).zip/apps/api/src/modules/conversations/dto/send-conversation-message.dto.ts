import { IsOptional, IsString, MaxLength } from 'class-validator';

export class SendConversationMessageDto {
  @IsString()
  @MaxLength(4096)
  content: string;

  @IsOptional()
  @IsString()
  mediaUrl?: string;
}

import { IsEnum, IsOptional } from 'class-validator';
import { ConversationStatus, Priority } from '@prisma/client';

export class UpdateConversationDto {
  @IsOptional()
  @IsEnum(ConversationStatus)
  status?: ConversationStatus;

  @IsOptional()
  @IsEnum(Priority)
  priority?: Priority;
}

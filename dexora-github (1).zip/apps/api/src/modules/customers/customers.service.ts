import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { QueryCustomerDto } from './dto/query-customer.dto';

export interface SegmentFilter {
  search?: string;
  tag?: string;
  minSpent?: number;
  inactiveSinceDays?: number;
}

@Injectable()
export class CustomersService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(businessId: string | null, query: QueryCustomerDto) {
    this.assertHasBusiness(businessId);
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;
    const where = this.buildWhere(businessId, query);

    const [items, total] = await this.prisma.$transaction([
      this.prisma.customer.findMany({
        where,
        orderBy: { lastInteractionAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.customer.count({ where }),
    ]);

    return { items, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOne(id: string, businessId: string | null) {
    const customer = await this.prisma.customer.findUnique({
      where: { id },
      include: {
        orders: { orderBy: { createdAt: 'desc' }, take: 20 },
        conversations: { orderBy: { lastMessageAt: 'desc' }, take: 10 },
      },
    });
    if (!customer || customer.businessId !== businessId) {
      throw new NotFoundException('Client introuvable.');
    }
    return customer;
  }

  async update(id: string, businessId: string | null, dto: UpdateCustomerDto) {
    const customer = await this.prisma.customer.findUnique({ where: { id } });
    if (!customer || customer.businessId !== businessId) {
      throw new NotFoundException('Client introuvable.');
    }
    return this.prisma.customer.update({ where: { id }, data: dto });
  }

  /**
   * Résout un segment (utilisé pour cibler une campagne) en liste de clients.
   * Contrairement à findAll(), pas de pagination — la file d'envoi de la
   * campagne a besoin de la liste complète.
   */
  async resolveSegment(businessId: string, filter: SegmentFilter) {
    const where = this.buildWhere(businessId, filter);
    return this.prisma.customer.findMany({ where });
  }

  async countSegment(businessId: string, filter: SegmentFilter) {
    const where = this.buildWhere(businessId, filter);
    return this.prisma.customer.count({ where });
  }

  private buildWhere(businessId: string, filter: SegmentFilter): Prisma.CustomerWhereInput {
    const where: Prisma.CustomerWhereInput = { businessId };

    if (filter.search) {
      where.OR = [
        { name: { contains: filter.search, mode: 'insensitive' } },
        { phoneNumber: { contains: filter.search } },
      ];
    }
    if (filter.tag) where.tags = { has: filter.tag };
    if (filter.minSpent !== undefined) where.totalSpent = { gte: filter.minSpent };
    if (filter.inactiveSinceDays !== undefined) {
      const threshold = new Date(Date.now() - filter.inactiveSinceDays * 24 * 60 * 60 * 1000);
      where.lastInteractionAt = { lt: threshold };
    }

    return where;
  }

  private assertHasBusiness(businessId: string | null): asserts businessId is string {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");
  }
}

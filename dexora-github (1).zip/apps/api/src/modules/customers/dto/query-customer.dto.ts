import { Type } from 'class-transformer';
import { IsInt, IsOptional, IsString, Max, Min } from 'class-validator';

export class QueryCustomerDto {
  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @IsString()
  tag?: string;

  /** Segment dynamique : clients sans interaction depuis N jours. */
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  inactiveSinceDays?: number;

  /** Segment dynamique : clients ayant dépensé au moins ce montant. */
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  minSpent?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number = 1;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  limit?: number = 20;
}

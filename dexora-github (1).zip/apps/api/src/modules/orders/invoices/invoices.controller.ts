import { Controller, Get, Param, Res } from '@nestjs/common';
import { Response } from 'express';
import { InvoicesService } from './invoices.service';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../../auth/types/authenticated-user.type';

@Controller({ path: 'orders/:orderId/invoice', version: '1' })
export class InvoicesController {
  constructor(private readonly invoicesService: InvoicesService) {}

  @Get()
  async download(
    @CurrentUser() user: AuthenticatedUser,
    @Param('orderId') orderId: string,
    @Res() res: Response,
  ) {
    const { filePath, number } = await this.invoicesService.getFile(orderId, user.businessId);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${number}.pdf"`);
    res.sendFile(filePath);
  }
}

import { Injectable, NotFoundException } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import PDFDocument from 'pdfkit';
import { PrismaService } from '../../../prisma/prisma.service';

const STORAGE_DIR = path.join(process.cwd(), 'storage', 'invoices');

interface InvoiceOrderData {
  orderNumber: string;
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  items: { productName: string; quantity: number; unitPrice: number; totalPrice: number }[];
  customer: { name: string | null; phoneNumber: string; address: string | null };
  business: { name: string; phone: string; address: string | null; currency: string };
}

@Injectable()
export class InvoicesService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Génère (ou régénère) la facture PDF d'une commande et l'enregistre sur
   * le disque local. Pour une mise à l'échelle multi-instance, ce stockage
   * local devrait être remplacé par S3/Cloudinary — acceptable pour une
   * seule instance API, documenté comme limite connue dans le README.
   */
  async generate(orderId: string, businessId: string | null) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true, customer: true, business: true },
    });
    if (!order || order.businessId !== businessId) {
      throw new NotFoundException('Commande introuvable.');
    }

    const invoiceNumber = `FACT-${order.orderNumber.replace('DEXORA-', '')}`;

    fs.mkdirSync(STORAGE_DIR, { recursive: true });
    const filePath = path.join(STORAGE_DIR, `${invoiceNumber}.pdf`);

    await this.renderPdf(filePath, order, invoiceNumber);

    const invoice = await this.prisma.invoice.upsert({
      where: { number: invoiceNumber },
      update: { pdfUrl: `/api/v1/orders/${order.id}/invoice`, generatedAt: new Date() },
      create: {
        number: invoiceNumber,
        pdfUrl: `/api/v1/orders/${order.id}/invoice`,
        orderId: order.id,
      },
    });

    return { invoice, filePath };
  }

  /** Retourne le fichier PDF, en le générant s'il n'existe pas encore. */
  async getFile(orderId: string, businessId: string | null) {
    const order = await this.prisma.order.findUnique({ where: { id: orderId } });
    if (!order || order.businessId !== businessId) {
      throw new NotFoundException('Commande introuvable.');
    }

    const existing = await this.prisma.invoice.findFirst({
      where: { orderId },
      orderBy: { generatedAt: 'desc' },
    });

    const invoiceNumber = existing?.number ?? `FACT-${order.orderNumber.replace('DEXORA-', '')}`;
    const filePath = path.join(STORAGE_DIR, `${invoiceNumber}.pdf`);

    if (!existing || !fs.existsSync(filePath)) {
      const generated = await this.generate(orderId, businessId);
      return { filePath: generated.filePath, number: generated.invoice.number };
    }

    return { filePath, number: invoiceNumber };
  }

  private async renderPdf(
    filePath: string,
    order: InvoiceOrderData,
    invoiceNumber: string,
  ) {
    return new Promise<void>((resolve, reject) => {
      const doc = new PDFDocument({ size: 'A4', margin: 50 });
      const stream = fs.createWriteStream(filePath);
      doc.pipe(stream);

      // En-tête
      doc.fontSize(20).font('Helvetica-Bold').text(order.business.name, 50, 50);
      doc.fontSize(10).font('Helvetica').fillColor('#5B5872');
      if (order.business.address) doc.text(order.business.address);
      doc.text(order.business.phone);

      doc
        .fontSize(24)
        .font('Helvetica-Bold')
        .fillColor('#2D2A5C')
        .text('FACTURE', 50, 50, { align: 'right' });
      doc
        .fontSize(10)
        .font('Helvetica')
        .fillColor('#1C1B29')
        .text(invoiceNumber, { align: 'right' })
        .text(new Date().toLocaleDateString('fr-FR'), { align: 'right' });

      doc.moveDown(2);
      doc.strokeColor('#E4DFD3').moveTo(50, doc.y).lineTo(545, doc.y).stroke();
      doc.moveDown();

      // Client
      doc.fontSize(11).font('Helvetica-Bold').fillColor('#1C1B29').text('Facturé à');
      doc.font('Helvetica').fontSize(10).fillColor('#5B5872');
      doc.text(order.customer.name ?? 'Client');
      doc.text(order.customer.phoneNumber);
      if (order.customer.address) doc.text(order.customer.address);

      doc.moveDown(2);

      // Tableau des articles
      const tableTop = doc.y;
      doc.font('Helvetica-Bold').fontSize(10).fillColor('#1C1B29');
      doc.text('Article', 50, tableTop);
      doc.text('Qté', 320, tableTop, { width: 50, align: 'right' });
      doc.text('Prix unit.', 380, tableTop, { width: 80, align: 'right' });
      doc.text('Total', 465, tableTop, { width: 80, align: 'right' });
      doc.moveTo(50, tableTop + 15).lineTo(545, tableTop + 15).strokeColor('#E4DFD3').stroke();

      let y = tableTop + 25;
      doc.font('Helvetica').fontSize(10).fillColor('#1C1B29');
      for (const item of order.items) {
        doc.text(item.productName, 50, y, { width: 260 });
        doc.text(String(item.quantity), 320, y, { width: 50, align: 'right' });
        doc.text(item.unitPrice.toLocaleString('fr-FR'), 380, y, { width: 80, align: 'right' });
        doc.text(item.totalPrice.toLocaleString('fr-FR'), 465, y, { width: 80, align: 'right' });
        y += 22;
      }

      doc.moveTo(50, y + 5).lineTo(545, y + 5).strokeColor('#E4DFD3').stroke();
      y += 20;

      const totals: [string, number][] = [
        ['Sous-total', order.subtotal],
        ['Livraison', order.deliveryFee],
        ['Remise', -order.discount],
      ];
      for (const [label, value] of totals) {
        doc.font('Helvetica').fontSize(10).fillColor('#5B5872');
        doc.text(label, 380, y, { width: 80, align: 'right' });
        doc.text(`${value.toLocaleString('fr-FR')} ${order.business.currency}`, 465, y, { width: 80, align: 'right' });
        y += 18;
      }

      doc.font('Helvetica-Bold').fontSize(12).fillColor('#2D2A5C');
      doc.text('Total', 380, y, { width: 80, align: 'right' });
      doc.text(`${order.total.toLocaleString('fr-FR')} ${order.business.currency}`, 465, y, { width: 80, align: 'right' });

      doc
        .fontSize(8)
        .font('Helvetica')
        .fillColor('#8B87A0')
        .text('Généré automatiquement par Dexora IA.', 50, 780, { align: 'center', width: 495 });

      doc.end();
      stream.on('finish', resolve);
      stream.on('error', reject);
    });
  }
}

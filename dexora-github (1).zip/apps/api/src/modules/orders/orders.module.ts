import { Module } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { OrdersController } from './orders.controller';
import { InvoicesService } from './invoices/invoices.service';
import { InvoicesController } from './invoices/invoices.controller';

@Module({
  controllers: [OrdersController, InvoicesController],
  providers: [OrdersService, InvoicesService],
  exports: [OrdersService, InvoicesService],
})
export class OrdersModule {}

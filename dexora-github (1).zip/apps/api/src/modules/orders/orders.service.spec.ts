import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { PrismaService } from '../../prisma/prisma.service';

describe('OrdersService', () => {
  let service: OrdersService;
  let prisma: any;

  const product = (overrides: Partial<any> = {}) => ({
    id: 'prod_1',
    businessId: 'biz_1',
    name: 'iPhone 13',
    price: 450000,
    promotionPrice: null,
    stock: 5,
    ...overrides,
  });

  beforeEach(async () => {
    prisma = {
      product: { findMany: jest.fn(), update: jest.fn() },
      customer: { findUnique: jest.fn(), upsert: jest.fn(), update: jest.fn() },
      order: { create: jest.fn(), findMany: jest.fn(), count: jest.fn(), findUnique: jest.fn(), update: jest.fn() },
      conversation: { update: jest.fn() },
      $transaction: jest.fn(async (arg: any) => {
        if (typeof arg === 'function') return arg(prisma);
        return Promise.all(arg);
      }),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [OrdersService, { provide: PrismaService, useValue: prisma }],
    }).compile();

    service = module.get(OrdersService);
  });

  describe('createOrder', () => {
    it("refuse si l'entreprise est absente", async () => {
      await expect(
        service.createOrder({ businessId: '', items: [{ productId: 'prod_1', quantity: 1 }] }),
      ).rejects.toThrow(ForbiddenException);
    });

    it('refuse une commande sans articles', async () => {
      await expect(service.createOrder({ businessId: 'biz_1', items: [] })).rejects.toThrow(
        BadRequestException,
      );
    });

    it("refuse si un produit n'appartient pas à l'entreprise", async () => {
      prisma.customer.findUnique.mockResolvedValue({ id: 'cust_1', businessId: 'biz_1' });
      prisma.product.findMany.mockResolvedValue([]); // aucun produit trouvé

      await expect(
        service.createOrder({
          businessId: 'biz_1',
          customerId: 'cust_1',
          items: [{ productId: 'prod_inconnu', quantity: 1 }],
        }),
      ).rejects.toThrow(BadRequestException);
    });

    it('refuse si le stock est insuffisant', async () => {
      prisma.customer.findUnique.mockResolvedValue({ id: 'cust_1', businessId: 'biz_1' });
      prisma.product.findMany.mockResolvedValue([product({ stock: 1 })]);

      await expect(
        service.createOrder({
          businessId: 'biz_1',
          customerId: 'cust_1',
          items: [{ productId: 'prod_1', quantity: 5 }],
        }),
      ).rejects.toThrow(BadRequestException);
    });

    it('calcule le total en utilisant le prix promotionnel quand il existe', async () => {
      prisma.customer.findUnique.mockResolvedValue({ id: 'cust_1', businessId: 'biz_1' });
      prisma.product.findMany.mockResolvedValue([product({ promotionPrice: 400000 })]);
      prisma.order.count.mockResolvedValue(0);
      prisma.order.create.mockImplementation(({ data }: any) =>
        Promise.resolve({ ...data, id: 'order_1', items: data.items.create }),
      );
      prisma.customer.update.mockResolvedValue({});
      prisma.product.update.mockResolvedValue({});

      const order = await service.createOrder({
        businessId: 'biz_1',
        customerId: 'cust_1',
        items: [{ productId: 'prod_1', quantity: 2 }],
      });

      expect(order.subtotal).toBe(800000); // 2 x 400 000 (prix promo, pas le prix normal)
      expect(order.total).toBe(800000);
    });

    it('génère un numéro de commande au format DEXORA-YYYYMMDD-XXX', async () => {
      prisma.customer.findUnique.mockResolvedValue({ id: 'cust_1', businessId: 'biz_1' });
      prisma.product.findMany.mockResolvedValue([product()]);
      prisma.order.count.mockResolvedValue(3); // 3 commandes déjà aujourd'hui
      prisma.order.create.mockImplementation(({ data }: any) => Promise.resolve({ ...data, id: 'order_1' }));
      prisma.customer.update.mockResolvedValue({});
      prisma.product.update.mockResolvedValue({});

      const order = await service.createOrder({
        businessId: 'biz_1',
        customerId: 'cust_1',
        items: [{ productId: 'prod_1', quantity: 1 }],
      });

      expect(order.orderNumber).toMatch(/^DEXORA-\d{8}-004$/);
    });

    it('crée un client au vol si customerPhone est fourni sans customerId', async () => {
      prisma.customer.upsert.mockResolvedValue({ id: 'cust_nouveau', businessId: 'biz_1' });
      prisma.product.findMany.mockResolvedValue([product()]);
      prisma.order.count.mockResolvedValue(0);
      prisma.order.create.mockImplementation(({ data }: any) => Promise.resolve({ ...data, id: 'order_1' }));
      prisma.customer.update.mockResolvedValue({});
      prisma.product.update.mockResolvedValue({});

      await service.createOrder({
        businessId: 'biz_1',
        customerPhone: '+22990000000',
        customerName: 'Nouveau client',
        items: [{ productId: 'prod_1', quantity: 1 }],
      });

      expect(prisma.customer.upsert).toHaveBeenCalledWith(
        expect.objectContaining({ where: { phoneNumber: '+22990000000' } }),
      );
    });
  });

  describe('updateStatus', () => {
    it("lève une NotFoundException si la commande n'appartient pas à l'entreprise", async () => {
      prisma.order.findUnique.mockResolvedValue({ id: 'order_1', businessId: 'autre_entreprise', items: [] });
      await expect(service.updateStatus('order_1', 'biz_1', 'CONFIRMED')).rejects.toThrow(NotFoundException);
    });

    it("restaure le stock et les statistiques client lors d'une annulation", async () => {
      const existingOrder = {
        id: 'order_1',
        businessId: 'biz_1',
        status: 'NEW',
        total: 450000,
        customerId: 'cust_1',
        items: [{ productId: 'prod_1', quantity: 2 }],
      };
      prisma.order.findUnique.mockResolvedValue(existingOrder);
      prisma.product.update.mockResolvedValue({});
      prisma.customer.update.mockResolvedValue({});
      prisma.order.update.mockResolvedValue({ ...existingOrder, status: 'CANCELLED' });

      await service.updateStatus('order_1', 'biz_1', 'CANCELLED');

      expect(prisma.product.update).toHaveBeenCalledWith({
        where: { id: 'prod_1' },
        data: { stock: { increment: 2 } },
      });
      expect(prisma.customer.update).toHaveBeenCalledWith({
        where: { id: 'cust_1' },
        data: { totalOrders: { decrement: 1 }, totalSpent: { decrement: 450000 } },
      });
    });
  });
});

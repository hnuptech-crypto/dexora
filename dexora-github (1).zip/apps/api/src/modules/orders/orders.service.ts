import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { OrderStatus } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { QueryOrderDto } from './dto/query-order.dto';
import { InvoicesService } from './invoices/invoices.service';

export interface CreateOrderParams {
  businessId: string;
  customerId?: string;
  customerPhone?: string;
  customerName?: string;
  conversationId?: string;
  items: { productId: string; quantity: number }[];
  deliveryAddress?: string;
  deliveryZone?: string;
  notes?: string;
  paymentMethod?: CreateOrderDto['paymentMethod'];
}

const ACTIVE_ORDER_STATUSES: OrderStatus[] = ['CONFIRMED', 'PREPARING', 'DELIVERING', 'DELIVERED'];

@Injectable()
export class OrdersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly invoicesService: InvoicesService,
  ) {}

  /**
   * Création de commande, utilisée à la fois par OrdersController (agent
   * humain) et par CreateOrderTool (assistant IA) — une seule source de
   * vérité pour la validation de stock, le calcul du total et les effets
   * de bord (décrément stock, mise à jour CRM client, numérotation).
   */
  async createOrder(params: CreateOrderParams) {
    if (!params.businessId) {
      throw new ForbiddenException("Aucune entreprise associée à ce compte.");
    }
    if (!params.items?.length) {
      throw new BadRequestException('La commande doit contenir au moins un produit.');
    }

    const customerId = await this.resolveCustomerId(params);

    const productIds = params.items.map((i) => i.productId);
    const products = await this.prisma.product.findMany({
      where: { id: { in: productIds }, businessId: params.businessId },
    });

    const missing = productIds.filter((id) => !products.find((p) => p.id === id));
    if (missing.length) {
      throw new BadRequestException(`Produit(s) introuvable(s) dans le catalogue : ${missing.join(', ')}`);
    }

    for (const item of params.items) {
      const product = products.find((p) => p.id === item.productId)!;
      if (product.stock < item.quantity) {
        throw new BadRequestException(
          `Stock insuffisant pour "${product.name}" (disponible : ${product.stock}).`,
        );
      }
    }

    const subtotal = params.items.reduce((sum, item) => {
      const product = products.find((p) => p.id === item.productId)!;
      const unitPrice = product.promotionPrice ?? product.price;
      return sum + unitPrice * item.quantity;
    }, 0);

    const orderNumber = await this.generateOrderNumber(params.businessId);

    return this.prisma.$transaction(async (tx) => {
      const order = await tx.order.create({
        data: {
          orderNumber,
          businessId: params.businessId,
          customerId,
          conversationId: params.conversationId,
          subtotal,
          total: subtotal,
          deliveryAddress: params.deliveryAddress,
          deliveryZone: params.deliveryZone,
          specialInstructions: params.notes,
          paymentMethod: params.paymentMethod,
          items: {
            create: params.items.map((item) => {
              const product = products.find((p) => p.id === item.productId)!;
              const unitPrice = product.promotionPrice ?? product.price;
              return {
                productId: product.id,
                productName: product.name,
                quantity: item.quantity,
                unitPrice,
                totalPrice: unitPrice * item.quantity,
              };
            }),
          },
        },
        include: { items: true, customer: true },
      });

      for (const item of params.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stock: { decrement: item.quantity }, orderCount: { increment: 1 } },
        });
      }

      await tx.customer.update({
        where: { id: customerId },
        data: { totalOrders: { increment: 1 }, totalSpent: { increment: subtotal }, lastPurchaseAt: new Date() },
      });

      if (params.conversationId) {
        await tx.conversation.update({ where: { id: params.conversationId }, data: { status: 'ORDER' } });
      }

      return order;
    });
  }

  async findAll(businessId: string | null, query: QueryOrderDto) {
    this.assertHasBusiness(businessId);
    const page = query.page ?? 1;
    const limit = query.limit ?? 20;

    const where = {
      businessId: businessId as string,
      ...(query.status ? { status: query.status } : {}),
      ...(query.customerId ? { customerId: query.customerId } : {}),
    };

    const [items, total] = await this.prisma.$transaction([
      this.prisma.order.findMany({
        where,
        include: { customer: true, items: true },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.order.count({ where }),
    ]);

    return { items, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOne(id: string, businessId: string | null) {
    const order = await this.prisma.order.findUnique({
      where: { id },
      include: { items: true, customer: true, assignedTo: true, invoices: true },
    });
    if (!order || order.businessId !== businessId) throw new NotFoundException('Commande introuvable.');
    return order;
  }

  async updateStatus(id: string, businessId: string | null, status: OrderStatus) {
    const order = await this.prisma.order.findUnique({ where: { id }, include: { items: true } });
    if (!order || order.businessId !== businessId) throw new NotFoundException('Commande introuvable.');

    const timestampField: Record<string, string | undefined> = {
      CONFIRMED: 'confirmedAt',
      PREPARING: 'preparedAt',
      DELIVERED: 'deliveredAt',
      CANCELLED: 'cancelledAt',
    };
    const field = timestampField[status];

    if (status === 'CANCELLED' && order.status !== 'CANCELLED') {
      // Restaure le stock et les statistiques client d'une commande annulée.
      await this.prisma.$transaction(async (tx) => {
        for (const item of order.items) {
          await tx.product.update({
            where: { id: item.productId },
            data: { stock: { increment: item.quantity } },
          });
        }
        await tx.customer.update({
          where: { id: order.customerId },
          data: { totalOrders: { decrement: 1 }, totalSpent: { decrement: order.total } },
        });
        await tx.order.update({
          where: { id },
          data: { status, cancelledAt: new Date() },
        });
      });
      return this.findOne(id, businessId);
    }

    const updated = await this.prisma.order.update({
      where: { id },
      data: { status, ...(field ? { [field]: new Date() } : {}) },
    });

    if (status === 'CONFIRMED') {
      // Génération automatique de la facture — best-effort, ne doit jamais
      // faire échouer la confirmation de commande si le rendu PDF échoue.
      this.invoicesService.generate(id, businessId).catch(() => {
        /* déjà journalisé côté InvoicesService le cas échéant */
      });
    }

    return updated;
  }

  async assignToAgent(id: string, businessId: string | null, agentId: string) {
    const order = await this.prisma.order.findUnique({ where: { id } });
    if (!order || order.businessId !== businessId) throw new NotFoundException('Commande introuvable.');

    const agent = await this.prisma.user.findUnique({ where: { id: agentId } });
    if (!agent || agent.businessId !== businessId) {
      throw new BadRequestException("Cet agent n'appartient pas à votre entreprise.");
    }

    return this.prisma.order.update({ where: { id }, data: { assignedToId: agentId } });
  }

  private async resolveCustomerId(params: CreateOrderParams): Promise<string> {
    if (params.customerId) {
      const customer = await this.prisma.customer.findUnique({ where: { id: params.customerId } });
      if (!customer || customer.businessId !== params.businessId) {
        throw new NotFoundException('Client introuvable.');
      }
      return customer.id;
    }

    if (params.customerPhone) {
      const customer = await this.prisma.customer.upsert({
        where: { phoneNumber: params.customerPhone },
        update: params.customerName ? { name: params.customerName } : {},
        create: { phoneNumber: params.customerPhone, name: params.customerName, businessId: params.businessId },
      });
      return customer.id;
    }

    throw new BadRequestException('customerId ou customerPhone est requis.');
  }

  private async generateOrderNumber(businessId: string): Promise<string> {
    const now = new Date();
    const datePart = now.toISOString().slice(0, 10).replace(/-/g, '');
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const countToday = await this.prisma.order.count({
      where: { businessId, createdAt: { gte: startOfDay } },
    });

    return `DEXORA-${datePart}-${String(countToday + 1).padStart(3, '0')}`;
  }

  private assertHasBusiness(businessId: string | null): asserts businessId is string {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");
  }
}

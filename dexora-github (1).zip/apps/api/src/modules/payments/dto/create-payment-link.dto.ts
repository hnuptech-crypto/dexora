import { IsEnum } from 'class-validator';
import { PaymentProvider } from '@prisma/client';

export class CreatePaymentLinkDto {
  @IsEnum(PaymentProvider)
  provider: PaymentProvider;
}

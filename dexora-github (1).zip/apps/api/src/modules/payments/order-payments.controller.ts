import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { PaymentsService } from './payments.service';
import { CreatePaymentLinkDto } from './dto/create-payment-link.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../auth/types/authenticated-user.type';

@Controller({ path: 'orders/:orderId/payment', version: '1' })
export class OrderPaymentsController {
  constructor(private readonly paymentsService: PaymentsService) {}

  @Post('link')
  createLink(
    @CurrentUser() user: AuthenticatedUser,
    @Param('orderId') orderId: string,
    @Body() dto: CreatePaymentLinkDto,
  ) {
    return this.paymentsService.createPaymentLink(orderId, user.businessId, dto.provider);
  }

  @Get('history')
  history(@CurrentUser() user: AuthenticatedUser, @Param('orderId') orderId: string) {
    return this.paymentsService.findForOrder(orderId, user.businessId);
  }
}

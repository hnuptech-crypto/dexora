import { Business, Order } from '@prisma/client';

export interface CheckoutResult {
  /** Référence attribuée par le provider — utilisée pour retrouver le paiement lors du webhook. */
  providerReference: string;
  /** Lien à envoyer au client (par WhatsApp) pour finaliser le paiement. */
  checkoutUrl: string;
}

export interface WebhookParseResult {
  providerReference: string;
  status: 'SUCCESSFUL' | 'FAILED' | 'PENDING';
}

/**
 * Contrat commun à MTN MoMo, Orange Money et Wave. Chaque implémentation
 * encapsule les spécificités d'authentification et de format de chaque API —
 * le reste de l'application (PaymentsService) ne connaît que cette interface.
 */
export interface PaymentProviderClient {
  /** Crée une session de paiement pour une commande et renvoie le lien de paiement. */
  createCheckout(business: Business, order: Order): Promise<CheckoutResult>;

  /**
   * Vérifie l'authenticité d'un webhook entrant (signature HMAC, secret partagé,
   * ou équivalent selon le provider). Retourne false si la vérification échoue
   * ou si le provider ne fournit aucun mécanisme de signature (auquel cas
   * PaymentsService journalise un avertissement plutôt que de faire confiance
   * aveuglément à la charge utile).
   */
  verifyWebhookSignature(rawBody: Buffer, headers: Record<string, string | undefined>): boolean;

  /** Extrait le statut et la référence du paiement depuis la charge utile du webhook. */
  parseWebhookEvent(payload: Record<string, unknown>): WebhookParseResult;
}

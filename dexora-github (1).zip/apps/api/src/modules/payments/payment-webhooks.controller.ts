import { Body, Controller, Get, Headers, Post, Req, Res } from '@nestjs/common';
import { Request, Response } from 'express';
import { PaymentsService } from './payments.service';
import { Public } from '../../common/decorators/public.decorator';

@Public()
@Controller({ path: 'payments/webhooks', version: '1' })
export class PaymentWebhooksController {
  constructor(private readonly paymentsService: PaymentsService) {}

  @Post('mtn-momo')
  async mtnMomo(@Req() req: Request, @Body() payload: Record<string, unknown>) {
    return this.paymentsService.handleWebhook('MTN_MOMO', req.rawBody ?? Buffer.from(''), req.headers as any, payload);
  }

  @Post('orange-money')
  async orangeMoney(@Req() req: Request, @Body() payload: Record<string, unknown>) {
    return this.paymentsService.handleWebhook('ORANGE_MONEY', req.rawBody ?? Buffer.from(''), req.headers as any, payload);
  }

  /** Redirection navigateur après paiement Orange (pas un webhook serveur-à-serveur). */
  @Get('orange-money/return')
  orangeMoneyReturn(@Res() res: Response) {
    res.status(200).send('Paiement reçu, merci. Vous pouvez fermer cette page.');
  }

  @Get('orange-money/cancel')
  orangeMoneyCancel(@Res() res: Response) {
    res.status(200).send('Paiement annulé.');
  }

  @Post('wave')
  async wave(
    @Req() req: Request,
    @Headers() headers: Record<string, string | undefined>,
    @Body() payload: Record<string, unknown>,
  ) {
    return this.paymentsService.handleWebhook('WAVE', req.rawBody ?? Buffer.from(''), headers, payload);
  }

  @Get('wave/success')
  waveSuccess(@Res() res: Response) {
    res.status(200).send('Paiement Wave confirmé, merci. Vous pouvez fermer cette page.');
  }

  @Get('wave/error')
  waveError(@Res() res: Response) {
    res.status(200).send('Le paiement Wave a échoué ou a été annulé.');
  }
}

import { Module } from '@nestjs/common';
import { WhatsappModule } from '../whatsapp/whatsapp.module';
import { PaymentsService } from './payments.service';
import { OrderPaymentsController } from './order-payments.controller';
import { PaymentWebhooksController } from './payment-webhooks.controller';
import { MtnMomoProvider } from './providers/mtn-momo.provider';
import { OrangeMoneyProvider } from './providers/orange-money.provider';
import { WaveProvider } from './providers/wave.provider';

@Module({
  imports: [WhatsappModule],
  controllers: [OrderPaymentsController, PaymentWebhooksController],
  providers: [PaymentsService, MtnMomoProvider, OrangeMoneyProvider, WaveProvider],
  exports: [PaymentsService],
})
export class PaymentsModule {}

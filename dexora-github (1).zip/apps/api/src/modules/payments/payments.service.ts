import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PaymentProvider } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { MtnMomoProvider } from './providers/mtn-momo.provider';
import { OrangeMoneyProvider } from './providers/orange-money.provider';
import { WaveProvider } from './providers/wave.provider';
import { PaymentProviderClient } from './payment-provider.interface';

@Injectable()
export class PaymentsService {
  private readonly logger = new Logger(PaymentsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly whatsappService: WhatsappService,
    private readonly mtnMomo: MtnMomoProvider,
    private readonly orangeMoney: OrangeMoneyProvider,
    private readonly wave: WaveProvider,
  ) {}

  private getProvider(provider: PaymentProvider): PaymentProviderClient {
    switch (provider) {
      case 'MTN_MOMO':
        return this.mtnMomo;
      case 'ORANGE_MONEY':
        return this.orangeMoney;
      case 'WAVE':
        return this.wave;
    }
  }

  /**
   * Crée un lien (ou déclenche un push MoMo) de paiement pour une commande,
   * et l'envoie automatiquement au client par WhatsApp — le commerçant n'a
   * rien à recopier manuellement.
   */
  async createPaymentLink(orderId: string, businessId: string | null, provider: PaymentProvider) {
    if (!businessId) throw new ForbiddenException("Aucune entreprise associée à ce compte.");

    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: { customer: true },
    });
    if (!order || order.businessId !== businessId) throw new NotFoundException('Commande introuvable.');
    if (order.paymentStatus === 'PAID') {
      throw new BadRequestException('Cette commande est déjà payée.');
    }

    const business = await this.prisma.business.findUniqueOrThrow({ where: { id: businessId } });
    const client = this.getProvider(provider);

    const result = await client.createCheckout(business, order);

    const payment = await this.prisma.payment.create({
      data: {
        orderId: order.id,
        provider,
        providerReference: result.providerReference || null,
        checkoutUrl: result.checkoutUrl || null,
        amount: order.total,
        currency: 'XOF',
        status: 'PENDING',
      },
    });

    if (result.checkoutUrl) {
      await this.whatsappService.sendMessage(businessId, {
        to: order.customer.phoneNumber,
        content: `Voici votre lien de paiement pour la commande ${order.orderNumber} : ${result.checkoutUrl}`,
      });
    } else {
      // Cas MTN MoMo : pas de lien, le client reçoit directement une notification sur son téléphone.
      await this.whatsappService.sendMessage(businessId, {
        to: order.customer.phoneNumber,
        content: `Une demande de paiement Mobile Money de ${order.total.toLocaleString()} FCFA vient de vous être envoyée pour la commande ${order.orderNumber}. Merci de valider avec votre code MoMo.`,
      });
    }

    return payment;
  }

  /** Traite un webhook entrant, quel que soit le provider. */
  async handleWebhook(
    provider: PaymentProvider,
    rawBody: Buffer,
    headers: Record<string, string | undefined>,
    payload: Record<string, unknown>,
  ) {
    const client = this.getProvider(provider);

    const isValid = client.verifyWebhookSignature(rawBody, headers);
    if (!isValid) {
      this.logger.warn(`Signature de webhook ${provider} invalide — événement ignoré.`);
      return { received: false };
    }

    const event = client.parseWebhookEvent(payload);
    if (!event.providerReference) {
      this.logger.warn(`Webhook ${provider} reçu sans référence exploitable.`);
      return { received: false };
    }

    const payment = await this.prisma.payment.findFirst({
      where: { provider, providerReference: event.providerReference },
    });

    if (!payment) {
      this.logger.warn(`Aucun paiement ${provider} trouvé pour la référence ${event.providerReference}.`);
      return { received: false };
    }

    await this.prisma.payment.update({
      where: { id: payment.id },
      data: { status: event.status, rawWebhookPayload: payload as object },
    });

    if (event.status === 'SUCCESSFUL') {
      await this.prisma.order.update({ where: { id: payment.orderId }, data: { paymentStatus: 'PAID' } });
    } else if (event.status === 'FAILED') {
      await this.prisma.order.update({ where: { id: payment.orderId }, data: { paymentStatus: 'FAILED' } });
    }

    return { received: true };
  }

  async findForOrder(orderId: string, businessId: string | null) {
    const order = await this.prisma.order.findUnique({ where: { id: orderId } });
    if (!order || order.businessId !== businessId) throw new NotFoundException('Commande introuvable.');
    return this.prisma.payment.findMany({ where: { orderId }, orderBy: { createdAt: 'desc' } });
  }
}

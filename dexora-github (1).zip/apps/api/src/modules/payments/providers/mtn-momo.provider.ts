import { Injectable, Logger } from '@nestjs/common';
import * as crypto from 'crypto';
import { Business, Order } from '@prisma/client';
import { CheckoutResult, PaymentProviderClient, WebhookParseResult } from '../payment-provider.interface';

/**
 * MTN Mobile Money — Collections API.
 *
 * ⚠️ IMPORTANT : contrairement à Wave ou Orange Money, MTN MoMo ne fournit pas
 * de lien de paiement web. Le flux "Request to Pay" envoie une notification
 * push directement sur le téléphone du client (validation par code USSD/PIN
 * MoMo) — il n'y a donc pas de checkoutUrl à proprement parler. `checkoutUrl`
 * est laissé vide ; c'est le X-Reference-Id qui sert à interroger le statut.
 *
 * Cette implémentation suit la structure documentée publiquement de l'API
 * MTN MoMo Collections (endpoints /collection/token/ puis /collection/v1_0/
 * requesttopay). Elle n'a pas pu être testée contre un vrai compte sandbox
 * MTN — à valider avec de vraies clés avant mise en production.
 */
@Injectable()
export class MtnMomoProvider implements PaymentProviderClient {
  private readonly logger = new Logger(MtnMomoProvider.name);
  private readonly baseUrl = process.env.MTN_MOMO_BASE_URL ?? 'https://sandbox.momodeveloper.mtn.com';

  async createCheckout(business: Business, order: Order & { customer?: { phoneNumber: string } }): Promise<CheckoutResult> {
    if (!business.mtnMomoApiUserId || !business.mtnMomoApiKey || !business.mtnMomoSubscriptionKey) {
      throw new Error("Connexion MTN MoMo non configurée pour cette entreprise.");
    }
    if (!order.customer?.phoneNumber) {
      throw new Error('Numéro de téléphone du client introuvable pour le paiement MoMo.');
    }

    const accessToken = await this.getAccessToken(business);
    const referenceId = crypto.randomUUID();
    const msisdn = order.customer.phoneNumber.replace(/^\+/, '');

    const response = await fetch(`${this.baseUrl}/collection/v1_0/requesttopay`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'X-Reference-Id': referenceId,
        'X-Target-Environment': business.mtnMomoTargetEnvironment ?? 'sandbox',
        'Ocp-Apim-Subscription-Key': business.mtnMomoSubscriptionKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: String(Math.round(order.total)),
        currency: 'XOF',
        externalId: order.orderNumber,
        payer: { partyIdType: 'MSISDN', partyId: msisdn },
        payerMessage: `Paiement commande ${order.orderNumber}`,
        payeeNote: `Dexora — ${business.name}`,
      }),
    });

    if (response.status !== 202) {
      const body = await response.text().catch(() => '');
      this.logger.error(`MTN MoMo requesttopay a échoué (${response.status}): ${body}`);
      throw new Error("Échec de la demande de paiement MTN MoMo.");
    }

    return {
      providerReference: referenceId,
      // Pas de lien web — le client reçoit directement une notification MoMo sur son téléphone.
      checkoutUrl: '',
    };
  }

  /**
   * MTN MoMo n'envoie pas de webhook signé de la même façon que Wave/Orange
   * dans le flux Collections standard : le statut se récupère plutôt par
   * polling GET /collection/v1_0/requesttopay/{referenceId}. Si un callback
   * URL est tout de même configuré côté MTN, aucune signature standard n'est
   * garantie — on journalise un avertissement plutôt que de faire confiance
   * aveuglément à la charge utile.
   */
  verifyWebhookSignature(): boolean {
    this.logger.warn(
      'MTN MoMo ne fournit pas de signature de webhook standard — vérifier le statut via polling est recommandé.',
    );
    return true;
  }

  parseWebhookEvent(payload: Record<string, unknown>): WebhookParseResult {
    const status = String(payload.status ?? '').toUpperCase();
    return {
      providerReference: String(payload.referenceId ?? payload.externalId ?? ''),
      status: status === 'SUCCESSFUL' ? 'SUCCESSFUL' : status === 'FAILED' ? 'FAILED' : 'PENDING',
    };
  }

  /** Vérifie le statut d'un paiement par polling — à utiliser en complément du webhook. */
  async checkStatus(business: Business, referenceId: string): Promise<WebhookParseResult> {
    const accessToken = await this.getAccessToken(business);
    const response = await fetch(`${this.baseUrl}/collection/v1_0/requesttopay/${referenceId}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'X-Target-Environment': business.mtnMomoTargetEnvironment ?? 'sandbox',
        'Ocp-Apim-Subscription-Key': business.mtnMomoSubscriptionKey as string,
      },
    });
    const data = await response.json().catch(() => ({}));
    return this.parseWebhookEvent({ ...data, referenceId });
  }

  private async getAccessToken(business: Business): Promise<string> {
    const credentials = Buffer.from(`${business.mtnMomoApiUserId}:${business.mtnMomoApiKey}`).toString('base64');
    const response = await fetch(`${this.baseUrl}/collection/token/`, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${credentials}`,
        'Ocp-Apim-Subscription-Key': business.mtnMomoSubscriptionKey as string,
      },
    });
    if (!response.ok) throw new Error("Impossible d'obtenir un token d'accès MTN MoMo.");
    const data = await response.json();
    return data.access_token;
  }
}

import { Injectable, Logger } from '@nestjs/common';
import { Business, Order } from '@prisma/client';
import { CheckoutResult, PaymentProviderClient, WebhookParseResult } from '../payment-provider.interface';

/**
 * Orange Money — Web Payment API.
 *
 * Suit la structure documentée publiquement de l'API Orange Money Web Payment
 * (OAuth2 client_credentials puis POST /webpayment). Non testée contre un
 * vrai compte marchand Orange — à valider avec de vraies clés avant mise en
 * production.
 *
 * Simplification assumée : Orange ne signe pas ses notifications webhook par
 * HMAC. La vérification recommandée par leur documentation consiste à
 * comparer le `notif_token` reçu au moment de la création du paiement avec
 * celui renvoyé dans la notification. On encode donc `payToken` et
 * `notifToken` ensemble dans `providerReference` (JSON), plutôt que
 * d'ajouter une colonne dédiée pour ce cas particulier à un seul provider.
 */
@Injectable()
export class OrangeMoneyProvider implements PaymentProviderClient {
  private readonly logger = new Logger(OrangeMoneyProvider.name);
  private readonly baseUrl = process.env.ORANGE_MONEY_BASE_URL ?? 'https://api.orange.com/orange-money-webpay/dev/v1';
  private readonly publicApiUrl = process.env.PUBLIC_API_URL ?? 'http://localhost:3000';

  async createCheckout(business: Business, order: Order): Promise<CheckoutResult> {
    if (!business.orangeMoneyMerchantKey || !business.orangeMoneyApiKey) {
      throw new Error('Connexion Orange Money non configurée pour cette entreprise.');
    }

    const accessToken = await this.getAccessToken(business.orangeMoneyApiKey);

    const response = await fetch(`${this.baseUrl}/webpayment`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        merchant_key: business.orangeMoneyMerchantKey,
        currency: 'XOF',
        order_id: order.orderNumber,
        amount: Math.round(order.total),
        return_url: `${this.publicApiUrl}/api/v1/payments/webhooks/orange-money/return`,
        cancel_url: `${this.publicApiUrl}/api/v1/payments/webhooks/orange-money/cancel`,
        notif_url: `${this.publicApiUrl}/api/v1/payments/webhooks/orange-money`,
        lang: 'fr',
        reference: `Dexora ${order.orderNumber}`,
      }),
    });

    if (!response.ok) {
      const body = await response.text().catch(() => '');
      this.logger.error(`Orange Money webpayment a échoué (${response.status}): ${body}`);
      throw new Error('Échec de la création du paiement Orange Money.');
    }

    const data = await response.json();

    return {
      providerReference: JSON.stringify({ payToken: data.pay_token, notifToken: data.notif_token }),
      checkoutUrl: data.payment_url,
    };
  }

  verifyWebhookSignature(): boolean {
    // Vérifié via parseWebhookEvent en comparant notif_token — voir la note en tête de fichier.
    return true;
  }

  parseWebhookEvent(payload: Record<string, unknown>): WebhookParseResult {
    const status = String(payload.status ?? '').toUpperCase();
    return {
      providerReference: JSON.stringify({ payToken: payload.pay_token, notifToken: payload.notif_token }),
      status: status === 'SUCCESS' ? 'SUCCESSFUL' : status === 'FAILED' ? 'FAILED' : 'PENDING',
    };
  }

  private async getAccessToken(apiKey: string): Promise<string> {
    const response = await fetch('https://api.orange.com/oauth/v3/token', {
      method: 'POST',
      headers: {
        Authorization: `Basic ${apiKey}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'grant_type=client_credentials',
    });
    if (!response.ok) throw new Error("Impossible d'obtenir un token d'accès Orange Money.");
    const data = await response.json();
    return data.access_token;
  }
}

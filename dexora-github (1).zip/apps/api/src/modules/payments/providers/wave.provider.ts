import { Injectable, Logger } from '@nestjs/common';
import * as crypto from 'crypto';
import { Business, Order } from '@prisma/client';
import { CheckoutResult, PaymentProviderClient, WebhookParseResult } from '../payment-provider.interface';

/**
 * Wave — Checkout API.
 *
 * Suit la structure documentée publiquement de l'API Wave Checkout (POST
 * /v1/checkout/sessions, redirection vers wave_launch_url, webhook signé via
 * l'en-tête Wave-Signature). C'est le provider le plus proche d'un standard
 * moderne (à la Stripe) des trois. Non testée contre un vrai compte marchand
 * Wave — le format exact de l'en-tête de signature est à reconfirmer auprès
 * de la documentation Wave actuelle avant mise en production.
 */
@Injectable()
export class WaveProvider implements PaymentProviderClient {
  private readonly logger = new Logger(WaveProvider.name);
  private readonly baseUrl = process.env.WAVE_BASE_URL ?? 'https://api.wave.com/v1';
  private readonly publicApiUrl = process.env.PUBLIC_API_URL ?? 'http://localhost:3000';

  async createCheckout(business: Business, order: Order): Promise<CheckoutResult> {
    if (!business.waveApiKey) {
      throw new Error('Connexion Wave non configurée pour cette entreprise.');
    }

    const response = await fetch(`${this.baseUrl}/checkout/sessions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${business.waveApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: String(Math.round(order.total)),
        currency: 'XOF',
        client_reference: order.orderNumber,
        success_url: `${this.publicApiUrl}/api/v1/payments/webhooks/wave/success`,
        error_url: `${this.publicApiUrl}/api/v1/payments/webhooks/wave/error`,
      }),
    });

    if (!response.ok) {
      const body = await response.text().catch(() => '');
      this.logger.error(`Wave checkout session a échoué (${response.status}): ${body}`);
      throw new Error('Échec de la création de la session de paiement Wave.');
    }

    const data = await response.json();

    return { providerReference: data.id, checkoutUrl: data.wave_launch_url };
  }

  verifyWebhookSignature(rawBody: Buffer, headers: Record<string, string | undefined>): boolean {
    const secret = process.env.WAVE_WEBHOOK_SECRET;
    const signatureHeader = headers['wave-signature'];

    if (!secret) {
      this.logger.warn('WAVE_WEBHOOK_SECRET non configuré — signature du webhook Wave non vérifiée (dev uniquement).');
      return true;
    }
    if (!signatureHeader) return false;

    // Format attendu (à la Stripe) : "t=<timestamp>,v1=<signature_hex>"
    const parts = Object.fromEntries(
      signatureHeader.split(',').map((p) => p.split('=') as [string, string]),
    );
    if (!parts.t || !parts.v1) return false;

    const expected = crypto
      .createHmac('sha256', secret)
      .update(`${parts.t}.${rawBody.toString()}`)
      .digest('hex');

    const expectedBuf = Buffer.from(expected);
    const actualBuf = Buffer.from(parts.v1);
    return expectedBuf.length === actualBuf.length && crypto.timingSafeEqual(expectedBuf, actualBuf);
  }

  parseWebhookEvent(payload: Record<string, unknown>): WebhookParseResult {
    const data = (payload.data ?? payload) as Record<string, unknown>;
    const status = String(data.payment_status ?? data.checkout_status ?? '').toLowerCase();
    return {
      providerReference: String(data.id ?? ''),
      status: status === 'succeeded' || status === 'complete' ? 'SUCCESSFUL' : status === 'failed' ? 'FAILED' : 'PENDING',
    };
  }
}

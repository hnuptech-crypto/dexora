import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { ProductsService } from './products.service';
import { PrismaService } from '../../prisma/prisma.service';

describe('ProductsService', () => {
  let service: ProductsService;
  let prisma: {
    product: {
      findUnique: jest.Mock;
      create: jest.Mock;
      findMany: jest.Mock;
      count: jest.Mock;
      update: jest.Mock;
    };
    $transaction: jest.Mock;
  };

  const baseProduct = {
    id: 'prod_1',
    businessId: 'biz_1',
    name: 'iPhone 13',
    stock: 5,
    isAvailable: true,
    isArchived: false,
    price: 450000,
    promotionPrice: null,
    sku: 'IP13',
  };

  beforeEach(async () => {
    prisma = {
      product: {
        findUnique: jest.fn(),
        create: jest.fn(),
        findMany: jest.fn(),
        count: jest.fn(),
        update: jest.fn(),
      },
      $transaction: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [ProductsService, { provide: PrismaService, useValue: prisma }],
    }).compile();

    service = module.get(ProductsService);
  });

  describe('create', () => {
    it("refuse la création si l'utilisateur n'a pas d'entreprise", async () => {
      await expect(
        service.create(null, { name: 'X', price: 100, category: 'Test' }),
      ).rejects.toThrow(ForbiddenException);
    });

    it('refuse un SKU déjà utilisé', async () => {
      prisma.product.findUnique.mockResolvedValue(baseProduct);

      await expect(
        service.create('biz_1', { name: 'X', price: 100, category: 'Test', sku: 'IP13' }),
      ).rejects.toThrow(BadRequestException);
    });

    it('crée le produit avec un statut "Disponible" calculé', async () => {
      prisma.product.findUnique.mockResolvedValue(null);
      prisma.product.create.mockResolvedValue(baseProduct);

      const result = await service.create('biz_1', { name: 'iPhone 13', price: 450000, category: 'Téléphones' });

      expect(result.status).toBe('Disponible');
    });
  });

  describe('statut calculé (withComputedStatus)', () => {
    it('retourne "Rupture" si le stock est à 0', async () => {
      prisma.product.findUnique.mockResolvedValue({ ...baseProduct, stock: 0 });
      prisma.product.update.mockResolvedValue({ ...baseProduct, stock: 0 });

      const result = await service.findOne('prod_1', 'biz_1');
      expect(result.status).toBe('Rupture');
    });

    it('retourne "Archivé" même si le stock est disponible', async () => {
      prisma.product.findUnique.mockResolvedValue({ ...baseProduct, isArchived: true });
      prisma.product.update.mockResolvedValue({ ...baseProduct, isArchived: true });

      const result = await service.findOne('prod_1', 'biz_1');
      expect(result.status).toBe('Archivé');
    });
  });

  describe('findOne', () => {
    it("lève une NotFoundException si le produit n'appartient pas à l'entreprise courante", async () => {
      prisma.product.findUnique.mockResolvedValue({ ...baseProduct, businessId: 'autre_entreprise' });

      await expect(service.findOne('prod_1', 'biz_1')).rejects.toThrow(NotFoundException);
    });
  });

  describe('archive', () => {
    it('marque le produit comme archivé et indisponible', async () => {
      prisma.product.findUnique.mockResolvedValue(baseProduct);
      prisma.product.update.mockResolvedValue({ ...baseProduct, isArchived: true, isAvailable: false });

      const result = await service.archive('prod_1', 'biz_1');

      expect(prisma.product.update).toHaveBeenCalledWith({
        where: { id: 'prod_1' },
        data: { isArchived: true, isAvailable: false },
      });
      expect(result.status).toBe('Archivé');
    });
  });
});

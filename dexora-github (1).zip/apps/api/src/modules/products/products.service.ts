import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { QueryProductDto } from './dto/query-product.dto';

@Injectable()
export class ProductsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(businessId: string | null, dto: CreateProductDto) {
    this.assertHasBusiness(businessId);

    if (dto.sku) {
      const existing = await this.prisma.product.findUnique({ where: { sku: dto.sku } });
      if (existing) throw new BadRequestException(`Le SKU "${dto.sku}" est déjà utilisé.`);
    }

    const product = await this.prisma.product.create({
      data: {
        businessId: businessId as string,
        name: dto.name,
        description: dto.description,
        price: dto.price,
        promotionPrice: dto.promotionPrice,
        stock: dto.stock ?? 0,
        sku: dto.sku,
        category: dto.category,
        subCategory: dto.subCategory,
        images: dto.images ?? [],
        tags: dto.tags ?? [],
        variants: dto.variants,
        weight: dto.weight,
        dimensions: dto.dimensions,
      },
    });

    return this.withComputedStatus(product);
  }

  async findAll(businessId: string | null, query: QueryProductDto) {
    this.assertHasBusiness(businessId);

    const page = query.page ?? 1;
    const limit = query.limit ?? 20;

    const where: Prisma.ProductWhereInput = { businessId: businessId as string };

    if (query.category) where.category = query.category;

    if (query.status === 'archived') where.isArchived = true;
    else if (query.status === 'out_of_stock') where.stock = 0;
    else if (query.status === 'available' || !query.status) where.isArchived = false;
    // 'all' : aucun filtre de statut supplémentaire

    if (query.search) {
      where.OR = [
        { name: { contains: query.search, mode: 'insensitive' } },
        { sku: { contains: query.search, mode: 'insensitive' } },
        { tags: { has: query.search } },
      ];
    }

    const [items, total] = await this.prisma.$transaction([
      this.prisma.product.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.product.count({ where }),
    ]);

    return {
      items: items.map((p) => this.withComputedStatus(p)),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOne(id: string, businessId: string | null) {
    const product = await this.prisma.product.findUnique({ where: { id } });
    if (!product || product.businessId !== businessId) {
      throw new NotFoundException('Produit introuvable.');
    }
    // Chaque consultation compte comme une "vue" — utile pour le futur module analytics.
    await this.prisma.product.update({ where: { id }, data: { viewCount: { increment: 1 } } });
    return this.withComputedStatus(product);
  }

  async update(id: string, businessId: string | null, dto: UpdateProductDto) {
    const product = await this.prisma.product.findUnique({ where: { id } });
    if (!product || product.businessId !== businessId) {
      throw new NotFoundException('Produit introuvable.');
    }

    if (dto.sku && dto.sku !== product.sku) {
      const existing = await this.prisma.product.findUnique({ where: { sku: dto.sku } });
      if (existing) throw new BadRequestException(`Le SKU "${dto.sku}" est déjà utilisé.`);
    }

    const updated = await this.prisma.product.update({ where: { id }, data: dto });
    return this.withComputedStatus(updated);
  }

  /**
   * Archivage logique. Un produit référencé dans des commandes ne peut pas
   * être supprimé physiquement (contrainte onDelete: Restrict côté OrderItem) ;
   * on l'archive donc plutôt que de le détruire.
   */
  async archive(id: string, businessId: string | null) {
    const product = await this.prisma.product.findUnique({ where: { id } });
    if (!product || product.businessId !== businessId) {
      throw new NotFoundException('Produit introuvable.');
    }

    const archived = await this.prisma.product.update({
      where: { id },
      data: { isArchived: true, isAvailable: false },
    });
    return this.withComputedStatus(archived);
  }

  private assertHasBusiness(businessId: string | null): asserts businessId is string {
    if (!businessId) {
      throw new ForbiddenException(
        "Vous devez d'abord créer ou rejoindre une entreprise pour gérer un catalogue.",
      );
    }
  }

  private withComputedStatus<T extends { isArchived: boolean; isAvailable: boolean; stock: number }>(
    product: T,
  ) {
    let status: 'Disponible' | 'Rupture' | 'Archivé';
    if (product.isArchived) status = 'Archivé';
    else if (product.stock <= 0 || !product.isAvailable) status = 'Rupture';
    else status = 'Disponible';

    return { ...product, status };
  }
}

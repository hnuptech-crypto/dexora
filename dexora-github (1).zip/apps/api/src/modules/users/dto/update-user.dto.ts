import { IsBoolean, IsEnum, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { UserRole } from '@prisma/client';

export class UpdateUserDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  @MaxLength(100)
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(20)
  phoneNumber?: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  avatar?: string;

  // Les deux champs suivants ne sont pris en compte que sur les routes de
  // gestion d'équipe (OWNER/MANAGER), jamais sur la mise à jour de son
  // propre profil — voir UsersController.
  @IsOptional()
  @IsEnum(UserRole, { message: 'Rôle invalide.' })
  role?: UserRole;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

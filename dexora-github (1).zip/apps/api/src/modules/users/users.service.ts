import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import { UserRole } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

const PASSWORD_SALT_ROUNDS = 10;

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  async getProfile(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('Utilisateur introuvable.');
    return this.sanitize(user);
  }

  async updateProfile(userId: string, dto: UpdateUserDto) {
    // Un utilisateur ne peut modifier ni son rôle, ni son statut actif via
    // cette route ; ces champs sont ignorés s'ils sont fournis.
    const { role, isActive, ...allowed } = dto;
    const user = await this.prisma.user.update({ where: { id: userId }, data: allowed });
    return this.sanitize(user);
  }

  async inviteTeamMember(inviterId: string, inviterRole: UserRole, businessId: string | null, dto: CreateUserDto) {
    this.assertCanManageTeam(inviterRole);

    if (!businessId) {
      throw new BadRequestException(
        "Vous devez d'abord créer ou rejoindre une entreprise avant d'inviter des membres.",
      );
    }

    if (dto.role === UserRole.OWNER) {
      throw new ForbiddenException("Impossible d'attribuer le rôle Propriétaire par invitation.");
    }

    const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existing) {
      throw new ConflictException('Un compte existe déjà avec cette adresse email.');
    }

    const hashedPassword = await bcrypt.hash(dto.password, PASSWORD_SALT_ROUNDS);

    const user = await this.prisma.user.create({
      data: {
        email: dto.email,
        password: hashedPassword,
        name: dto.name,
        phoneNumber: dto.phoneNumber,
        role: dto.role,
        businessId,
      },
    });

    return this.sanitize(user);
  }

  async findAllForBusiness(businessId: string | null) {
    if (!businessId) return [];
    const users = await this.prisma.user.findMany({
      where: { businessId },
      orderBy: { createdAt: 'asc' },
    });
    return users.map((u) => this.sanitize(u));
  }

  async findOneInBusiness(id: string, businessId: string | null) {
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user || user.businessId !== businessId) {
      throw new NotFoundException('Utilisateur introuvable.');
    }
    return this.sanitize(user);
  }

  async updateTeamMember(
    id: string,
    inviterRole: UserRole,
    businessId: string | null,
    dto: UpdateUserDto,
  ) {
    this.assertCanManageTeam(inviterRole);

    const target = await this.prisma.user.findUnique({ where: { id } });
    if (!target || target.businessId !== businessId) {
      throw new NotFoundException('Utilisateur introuvable.');
    }
    if (target.role === UserRole.OWNER) {
      throw new ForbiddenException('Le rôle du Propriétaire ne peut pas être modifié ici.');
    }
    if (dto.role === UserRole.OWNER) {
      throw new ForbiddenException('Impossible de promouvoir un membre au rôle Propriétaire.');
    }

    const updated = await this.prisma.user.update({ where: { id }, data: dto });
    return this.sanitize(updated);
  }

  private assertCanManageTeam(role: UserRole) {
    if (role !== UserRole.OWNER && role !== UserRole.MANAGER) {
      throw new ForbiddenException(
        "Seuls le Propriétaire et les Managers peuvent gérer l'équipe.",
      );
    }
  }

  private sanitize<
    T extends {
      password: string;
      refreshTokenHash: string | null;
      passwordResetTokenHash: string | null;
    },
  >(user: T) {
    const { password, refreshTokenHash, passwordResetTokenHash, ...safe } = user;
    return safe;
  }
}

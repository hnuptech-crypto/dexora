import { IsEnum, IsOptional, IsString, MaxLength, Matches } from 'class-validator';
import { MediaType } from '@prisma/client';

export class SendMessageDto {
  @IsString()
  @Matches(/^\+?[0-9]{8,15}$/, { message: 'Numéro WhatsApp invalide (format international).' })
  to: string;

  @IsOptional()
  @IsString()
  @MaxLength(4096)
  content?: string;

  @IsOptional()
  @IsEnum(MediaType)
  mediaType?: MediaType;

  @IsOptional()
  @IsString()
  mediaUrl?: string;
}

import { CanActivate, ExecutionContext, ForbiddenException, Injectable, Logger } from '@nestjs/common';
import * as crypto from 'crypto';

/**
 * Vérifie l'en-tête X-Hub-Signature-256 envoyé par Meta sur chaque appel
 * webhook, calculé en HMAC-SHA256 du corps brut avec l'App Secret.
 * Empêche qu'un tiers non autorisé n'envoie de faux événements à ce endpoint.
 *
 * Si WHATSAPP_APP_SECRET n'est pas configuré (environnement de dev sans
 * intégration Meta réelle), la vérification est ignorée avec un avertissement.
 */
@Injectable()
export class WhatsappSignatureGuard implements CanActivate {
  private readonly logger = new Logger(WhatsappSignatureGuard.name);

  canActivate(context: ExecutionContext): boolean {
    const appSecret = process.env.WHATSAPP_APP_SECRET;
    if (!appSecret) {
      this.logger.warn(
        'WHATSAPP_APP_SECRET non configuré — signature du webhook non vérifiée (dev uniquement).',
      );
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const signatureHeader: string | undefined = request.headers['x-hub-signature-256'];
    const rawBody: Buffer | undefined = request.rawBody;

    if (!signatureHeader || !rawBody) {
      throw new ForbiddenException('Signature webhook manquante.');
    }

    const expectedSignature =
      'sha256=' + crypto.createHmac('sha256', appSecret).update(rawBody).digest('hex');

    const signatureBuf = Buffer.from(signatureHeader);
    const expectedBuf = Buffer.from(expectedSignature);
    const isValid =
      signatureBuf.length === expectedBuf.length &&
      crypto.timingSafeEqual(signatureBuf, expectedBuf);

    if (!isValid) {
      throw new ForbiddenException('Signature webhook invalide.');
    }

    return true;
  }
}

import { Injectable, Logger } from '@nestjs/common';

export interface SendTextMessageParams {
  phoneNumberId: string;
  accessToken: string;
  to: string;
  body: string;
}

export interface SendMediaMessageParams {
  phoneNumberId: string;
  accessToken: string;
  to: string;
  mediaType: 'image' | 'document' | 'audio' | 'video';
  mediaUrl: string;
  caption?: string;
}

@Injectable()
export class WhatsappGraphApiClient {
  private readonly logger = new Logger(WhatsappGraphApiClient.name);
  private readonly baseUrl = process.env.WHATSAPP_API_URL ?? 'https://graph.facebook.com/v19.0';

  async sendTextMessage({ phoneNumberId, accessToken, to, body }: SendTextMessageParams) {
    return this.post(phoneNumberId, accessToken, {
      messaging_product: 'whatsapp',
      to,
      type: 'text',
      text: { body },
    });
  }

  async sendMediaMessage({
    phoneNumberId,
    accessToken,
    to,
    mediaType,
    mediaUrl,
    caption,
  }: SendMediaMessageParams) {
    return this.post(phoneNumberId, accessToken, {
      messaging_product: 'whatsapp',
      to,
      type: mediaType,
      [mediaType]: { link: mediaUrl, caption },
    });
  }

  private async post(phoneNumberId: string, accessToken: string, body: Record<string, unknown>) {
    const url = `${this.baseUrl}/${phoneNumberId}/messages`;

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      this.logger.error(`Échec d'envoi WhatsApp (${response.status}): ${JSON.stringify(data)}`);
      throw new Error(`Échec de l'envoi du message WhatsApp (statut ${response.status}).`);
    }

    return data as { messages?: { id: string }[] };
  }
}

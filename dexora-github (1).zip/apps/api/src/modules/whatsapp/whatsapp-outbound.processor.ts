import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';
import { PrismaService } from '../../prisma/prisma.service';
import { WhatsappGraphApiClient } from './whatsapp-graph-api.client';
import { OutboundJobData, WHATSAPP_OUTBOUND_QUEUE } from './whatsapp.service';

@Processor(WHATSAPP_OUTBOUND_QUEUE)
export class WhatsappOutboundProcessor {
  private readonly logger = new Logger(WhatsappOutboundProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly graphApi: WhatsappGraphApiClient,
  ) {}

  @Process()
  async handleOutboundMessage(job: Job<OutboundJobData>) {
    const { businessId, messageId, to, content, mediaType, mediaUrl } = job.data;

    const business = await this.prisma.business.findUnique({ where: { id: businessId } });
    if (!business?.whatsappApiKey || !business.whatsappPhoneNumberId) {
      throw new Error("Configuration WhatsApp manquante pour cette entreprise.");
    }

    if (mediaType && mediaUrl) {
      await this.graphApi.sendMediaMessage({
        phoneNumberId: business.whatsappPhoneNumberId,
        accessToken: business.whatsappApiKey,
        to,
        mediaType: mediaType.toLowerCase() as 'image' | 'document' | 'audio' | 'video',
        mediaUrl,
        caption: content,
      });
    } else {
      await this.graphApi.sendTextMessage({
        phoneNumberId: business.whatsappPhoneNumberId,
        accessToken: business.whatsappApiKey,
        to,
        body: content ?? '',
      });
    }

    await this.prisma.message.update({ where: { id: messageId }, data: { isDelivered: true } });
    this.logger.log(`Message ${messageId} envoyé avec succès à ${to}.`);
  }
}

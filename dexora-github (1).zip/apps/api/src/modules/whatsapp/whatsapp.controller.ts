import { Body, Controller, Get, Post, Query, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { WhatsappService } from './whatsapp.service';
import { SendMessageDto } from './dto/send-message.dto';
import { Public } from '../../common/decorators/public.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AuthenticatedUser } from '../auth/types/authenticated-user.type';
import { WhatsappSignatureGuard } from './guards/whatsapp-signature.guard';
import { WhatsAppWebhookPayload } from './types/whatsapp-webhook.types';

@Controller({ path: 'whatsapp', version: '1' })
export class WhatsappController {
  constructor(private readonly whatsappService: WhatsappService) {}

  /** Meta appelle ce endpoint en GET une seule fois, lors de la config du webhook. */
  @Public()
  @Get('webhook')
  verifyWebhook(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') verifyToken: string,
    @Query('hub.challenge') challenge: string,
    @Res() res: Response,
  ) {
    const result = this.whatsappService.verifyWebhook(mode, verifyToken, challenge);
    res.status(200).send(result);
  }

  /** Meta POST ici à chaque message/statut entrant. Doit répondre 200 vite. */
  @Public()
  @UseGuards(WhatsappSignatureGuard)
  @Post('webhook')
  async receiveWebhook(@Body() payload: WhatsAppWebhookPayload, @Res() res: Response) {
    // Réponse immédiate à Meta avant traitement pour éviter les re-livraisons ;
    // le traitement reste volontairement synchrone et léger pour cette phase
    // (une vraie mise à l'échelle déchargerait ceci sur une queue dédiée).
    res.status(200).send('EVENT_RECEIVED');
    await this.whatsappService.handleIncomingWebhook(payload);
  }

  @Post('send')
  sendMessage(@CurrentUser() user: AuthenticatedUser, @Body() dto: SendMessageDto) {
    return this.whatsappService.sendMessage(user.businessId, dto);
  }
}

import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { WhatsappController } from './whatsapp.controller';
import { WhatsappService, WHATSAPP_OUTBOUND_QUEUE } from './whatsapp.service';
import { WhatsappGraphApiClient } from './whatsapp-graph-api.client';
import { WhatsappOutboundProcessor } from './whatsapp-outbound.processor';

@Module({
  imports: [
    BullModule.registerQueue({
      name: WHATSAPP_OUTBOUND_QUEUE,
      // Limite de débit prudente par défaut ; à ajuster selon le palier
      // d'API WhatsApp Business réellement souscrit (80 msg/s max en pointe).
      limiter: { max: 20, duration: 1000 },
    }),
  ],
  controllers: [WhatsappController],
  providers: [WhatsappService, WhatsappGraphApiClient, WhatsappOutboundProcessor],
  exports: [WhatsappService],
})
export class WhatsappModule {}

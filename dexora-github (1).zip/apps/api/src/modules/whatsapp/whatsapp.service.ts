import { ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Queue } from 'bull';
import { MediaType, SenderType } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { SendMessageDto } from './dto/send-message.dto';
import { WhatsAppInboundMessage, WhatsAppWebhookPayload } from './types/whatsapp-webhook.types';

export const WHATSAPP_MESSAGE_RECEIVED_EVENT = 'whatsapp.message.received';

export interface WhatsappMessageReceivedEvent {
  businessId: string;
  conversationId: string;
  customerId: string;
  customerPhone: string;
}

export const WHATSAPP_OUTBOUND_QUEUE = 'whatsapp-outbound';

export interface OutboundJobData {
  businessId: string;
  messageId: string;
  to: string;
  content?: string;
  mediaType?: MediaType;
  mediaUrl?: string;
}

@Injectable()
export class WhatsappService {
  private readonly logger = new Logger(WhatsappService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly eventEmitter: EventEmitter2,
    @InjectQueue(WHATSAPP_OUTBOUND_QUEUE) private readonly outboundQueue: Queue<OutboundJobData>,
  ) {}

  /** Étape de vérification initiale exigée par Meta lors de la config du webhook. */
  verifyWebhook(mode: string, verifyToken: string, challenge: string): string {
    const expectedToken = process.env.WHATSAPP_VERIFY_TOKEN;
    if (mode === 'subscribe' && expectedToken && verifyToken === expectedToken) {
      return challenge;
    }
    throw new ForbiddenException('Jeton de vérification invalide.');
  }

  /**
   * Ingère un payload webhook Meta : crée/retrouve le client et la
   * conversation, puis enregistre chaque message entrant.
   * Répond toujours vite (Meta réessaie sinon) — pas de traitement lourd ici.
   */
  async handleIncomingWebhook(payload: WhatsAppWebhookPayload) {
    if (payload.object !== 'whatsapp_business_account') return;

    for (const entry of payload.entry ?? []) {
      for (const change of entry.changes ?? []) {
        if (change.field !== 'messages' || !change.value.messages?.length) continue;

        const { phone_number_id } = change.value.metadata;
        const business = await this.prisma.business.findUnique({
          where: { whatsappPhoneNumberId: phone_number_id },
        });

        if (!business) {
          this.logger.warn(`Webhook reçu pour un phone_number_id inconnu : ${phone_number_id}`);
          continue;
        }

        const contactName = change.value.contacts?.[0]?.profile?.name;

        for (const message of change.value.messages) {
          await this.ingestMessage(business.id, message, contactName);
        }
      }
    }
  }

  private async ingestMessage(businessId: string, message: WhatsAppInboundMessage, contactName?: string) {
    const phoneNumber = `+${message.from}`;

    const customer = await this.prisma.customer.upsert({
      where: { phoneNumber },
      update: contactName ? { name: contactName } : {},
      create: { phoneNumber, name: contactName, businessId },
    });

    // Réutilise la conversation ouverte la plus récente, sinon en crée une nouvelle.
    let conversation = await this.prisma.conversation.findFirst({
      where: { customerId: customer.id, status: { notIn: ['RESOLVED', 'ARCHIVED'] } },
      orderBy: { lastMessageAt: 'desc' },
    });

    if (!conversation) {
      conversation = await this.prisma.conversation.create({
        data: { businessId, customerId: customer.id, status: 'NEW' },
      });
    }

    const { content, mediaType } = this.extractContent(message);

    await this.prisma.$transaction([
      this.prisma.message.create({
        data: {
          conversationId: conversation.id,
          content,
          senderType: SenderType.CUSTOMER,
          senderCustomerId: customer.id,
          mediaType,
          isDelivered: true,
          isRead: false,
        },
      }),
      this.prisma.conversation.update({
        where: { id: conversation.id },
        data: { unreadCount: { increment: 1 } },
      }),
    ]);

    // Découplage volontaire : WhatsappService ne connaît pas AiService (pour
    // éviter une dépendance circulaire whatsapp <-> ai). L'assistant IA,
    // s'il est activé pour cette entreprise, écoute cet événement et répond
    // de son côté via WhatsappService.sendAiReply().
    this.eventEmitter.emit(WHATSAPP_MESSAGE_RECEIVED_EVENT, {
      businessId,
      conversationId: conversation.id,
      customerId: customer.id,
      customerPhone: phoneNumber,
    } satisfies WhatsappMessageReceivedEvent);
  }

  private extractContent(message: WhatsAppInboundMessage): { content: string; mediaType?: MediaType } {
    switch (message.type) {
      case 'text':
        return { content: message.text?.body ?? '' };
      case 'image':
        return { content: message.image?.caption ?? '[Image]', mediaType: MediaType.IMAGE };
      case 'document':
        return { content: message.document?.caption ?? '[Document]', mediaType: MediaType.DOCUMENT };
      case 'audio':
        return { content: '[Message vocal]', mediaType: MediaType.AUDIO };
      case 'video':
        return { content: message.video?.caption ?? '[Vidéo]', mediaType: MediaType.VIDEO };
      default:
        return { content: `[Message non supporté : ${message.type}]` };
    }
  }

  /**
   * Envoi manuel (agent depuis le dashboard). Enregistre le message
   * immédiatement (statut non livré) puis délègue l'appel réseau réel
   * à la queue, qui respecte les limites de débit de l'API Meta.
   */
  async sendMessage(businessId: string | null, dto: SendMessageDto) {
    if (!businessId) {
      throw new ForbiddenException("Vous devez d'abord créer ou rejoindre une entreprise.");
    }

    const business = await this.prisma.business.findUnique({ where: { id: businessId } });
    if (!business) throw new NotFoundException('Entreprise introuvable.');
    if (!business.whatsappApiKey || !business.whatsappPhoneNumberId) {
      throw new ForbiddenException("La connexion WhatsApp Business n'est pas encore configurée.");
    }

    const customer = await this.prisma.customer.upsert({
      where: { phoneNumber: dto.to },
      update: {},
      create: { phoneNumber: dto.to, businessId },
    });

    let conversation = await this.prisma.conversation.findFirst({
      where: { customerId: customer.id, status: { notIn: ['RESOLVED', 'ARCHIVED'] } },
      orderBy: { lastMessageAt: 'desc' },
    });
    if (!conversation) {
      conversation = await this.prisma.conversation.create({
        data: { businessId, customerId: customer.id, status: 'NEW' },
      });
    }

    const message = await this.prisma.message.create({
      data: {
        conversationId: conversation.id,
        content: dto.content ?? '',
        senderType: SenderType.USER,
        mediaType: dto.mediaType,
        mediaUrl: dto.mediaUrl,
        isDelivered: false,
      },
    });

    await this.enqueueOutbound({
      businessId,
      messageId: message.id,
      to: dto.to,
      content: dto.content,
      mediaType: dto.mediaType,
      mediaUrl: dto.mediaUrl,
    });

    return { queued: true, messageId: message.id };
  }

  /**
   * Envoi d'une réponse générée par l'assistant IA. Distinct de sendMessage()
   * (qui gère la validation/upsert client pour un envoi initié par un agent) :
   * ici la conversation existe déjà puisqu'on répond à un message entrant.
   */
  async sendAiReply(businessId: string, conversationId: string, to: string, content: string) {
    const business = await this.prisma.business.findUnique({ where: { id: businessId } });
    if (!business?.whatsappApiKey || !business.whatsappPhoneNumberId) {
      throw new ForbiddenException("La connexion WhatsApp Business n'est pas encore configurée.");
    }

    const message = await this.prisma.message.create({
      data: {
        conversationId,
        content,
        senderType: SenderType.AI,
        isAutomated: true,
        isDelivered: false,
      },
    });

    await this.enqueueOutbound({ businessId, messageId: message.id, to, content });

    return message;
  }

  private async enqueueOutbound(data: OutboundJobData) {
    await this.outboundQueue.add(data, {
      attempts: 3,
      backoff: { type: 'exponential', delay: 2000 },
    });
  }
}

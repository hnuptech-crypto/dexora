import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';

/**
 * Test e2e — nécessite une vraie base PostgreSQL et une instance Redis
 * accessibles via DATABASE_URL / REDIS_URL (voir docker-compose.yml).
 * Contrairement aux tests unitaires, rien n'est mocké ici : c'est
 * volontaire, un e2e sert justement à vérifier l'intégration réelle.
 *
 * Non exécuté dans cette session (pas d'accès réseau/DB depuis l'environnement
 * de génération de code) — structuré pour tourner tel quel dans le workflow
 * CI (voir .github/workflows/ci.yml), qui démarre Postgres/Redis en services.
 */
describe('Dexora API (e2e)', () => {
  let app: INestApplication;
  const uniqueEmail = `e2e-${Date.now()}@dexora.test`;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    app.setGlobalPrefix('api', { exclude: ['health'] });
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('/health (GET) renvoie un statut ok', () => {
    return request(app.getHttpServer())
      .get('/health')
      .expect(200)
      .expect((res) => {
        expect(res.body.status).toBeDefined();
      });
  });

  it("refuse l'accès à une route protégée sans token", () => {
    return request(app.getHttpServer()).get('/api/v1/users/me').expect(401);
  });

  it('parcours complet : inscription → connexion → profil protégé', async () => {
    const registerRes = await request(app.getHttpServer())
      .post('/api/v1/auth/register')
      .send({ email: uniqueEmail, password: 'motdepasse123', name: 'Test E2E' })
      .expect(201);

    expect(registerRes.body.accessToken).toBeDefined();
    expect(registerRes.body.user.email).toBe(uniqueEmail);
    expect(registerRes.body.user.password).toBeUndefined(); // jamais exposé

    const loginRes = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: uniqueEmail, password: 'motdepasse123' })
      .expect(200);

    const { accessToken } = loginRes.body;

    await request(app.getHttpServer())
      .get('/api/v1/users/me')
      .set('Authorization', `Bearer ${accessToken}`)
      .expect(200)
      .expect((res) => {
        expect(res.body.email).toBe(uniqueEmail);
      });
  });

  it('rejette une connexion avec un mauvais mot de passe', () => {
    return request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: uniqueEmail, password: 'mauvais-mot-de-passe' })
      .expect(401);
  });
});

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-paper px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <span className="font-display text-2xl font-semibold text-brand">Dexora IA</span>
          <p className="mt-1 text-sm text-ink-soft">
            L&rsquo;intelligence commerciale au service de votre WhatsApp.
          </p>
        </div>
        <div className="rounded-lg border border-border bg-white/70 p-6 shadow-soft">{children}</div>
      </div>
    </div>
  );
}

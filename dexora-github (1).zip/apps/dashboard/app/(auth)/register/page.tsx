'use client';

import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/lib/auth-context';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function RegisterPage() {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '', phoneNumber: '' });
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const update = (field: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    try {
      await register(form);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Inscription impossible.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <h1 className="mb-1 text-lg font-semibold">Créer votre compte</h1>
      <p className="mb-6 text-sm text-ink-soft">
        Vous configurerez votre entreprise et votre connexion WhatsApp juste après.
      </p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <Input label="Nom complet" name="name" required value={form.name} onChange={update('name')} />
        <Input
          label="Adresse email"
          type="email"
          name="email"
          autoComplete="email"
          required
          value={form.email}
          onChange={update('email')}
        />
        <Input
          label="Mot de passe"
          type="password"
          name="password"
          autoComplete="new-password"
          required
          minLength={8}
          value={form.password}
          onChange={update('password')}
        />
        <Input
          label="Téléphone (optionnel)"
          name="phoneNumber"
          placeholder="+229 00 00 00 00"
          value={form.phoneNumber}
          onChange={update('phoneNumber')}
        />

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" isLoading={isLoading} className="mt-2 w-full">
          Créer mon compte
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-ink-soft">
        Déjà un compte ?{' '}
        <Link href="/login" className="font-medium text-brand hover:underline">
          Se connecter
        </Link>
      </p>
    </>
  );
}

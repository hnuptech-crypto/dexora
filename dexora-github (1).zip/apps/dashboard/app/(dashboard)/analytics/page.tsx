'use client';

import { useEffect, useState } from 'react';
import { TrendingUp, MessageSquare, ShoppingBag, Percent, AlertTriangle, Bot } from 'lucide-react';
import { apiFetch } from '@/lib/api-client';
import { Card, CardBody, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatCurrency } from '@/lib/format';
import type { AnalyticsSummary } from '@/lib/types';

const periods: { value: AnalyticsSummary['period']; label: string }[] = [
  { value: 'today', label: "Aujourd'hui" },
  { value: 'week', label: '7 derniers jours' },
  { value: 'month', label: 'Ce mois-ci' },
];

export default function AnalyticsPage() {
  const [period, setPeriod] = useState<AnalyticsSummary['period']>('today');
  const [data, setData] = useState<AnalyticsSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    apiFetch<AnalyticsSummary>(`/analytics/summary?period=${period}`)
      .then(setData)
      .finally(() => setIsLoading(false));
  }, [period]);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Analytics</h1>
          <p className="text-sm text-ink-soft">Performance commerciale et efficacité de l&rsquo;assistant IA.</p>
        </div>
        <div className="flex gap-2">
          {periods.map((p) => (
            <button
              key={p.value}
              onClick={() => setPeriod(p.value)}
              className={`rounded px-3 py-1.5 text-sm font-medium transition-colors ${
                period === p.value ? 'bg-brand text-paper' : 'bg-paper-dim text-ink-soft hover:bg-border/60'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {isLoading || !data ? (
        <p className="text-sm text-ink-soft">Chargement…</p>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <StatCard icon={MessageSquare} label="Conversations" value={data.newConversations} />
            <StatCard icon={ShoppingBag} label="Commandes" value={data.newOrders} />
            <StatCard icon={TrendingUp} label="Chiffre d'affaires" value={formatCurrency(data.revenue)} />
            <StatCard
              icon={Percent}
              label="Taux de conversion"
              value={`${Math.round(data.conversionRate * 100)}%`}
            />
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <h2 className="font-semibold">Top produits</h2>
              </CardHeader>
              <CardBody className="divide-y divide-border p-0">
                {data.topProducts.length === 0 && (
                  <p className="px-5 py-4 text-sm text-ink-faint">Aucune vente sur cette période.</p>
                )}
                {data.topProducts.map((p, i) => (
                  <div key={p.productId} className="flex items-center justify-between px-5 py-3">
                    <div className="flex items-center gap-3">
                      <span className="font-display text-sm font-semibold text-ink-faint">#{i + 1}</span>
                      <span className="text-sm font-medium text-ink">{p.name}</span>
                    </div>
                    <div className="text-right text-sm">
                      <p className="font-medium">{formatCurrency(p.revenue)}</p>
                      <p className="text-xs text-ink-faint">{p.quantitySold} vendus</p>
                    </div>
                  </div>
                ))}
              </CardBody>
            </Card>

            <div className="flex flex-col gap-6">
              <Card>
                <CardHeader className="flex items-center gap-2">
                  <Bot className="h-4 w-4 text-brand" />
                  <h2 className="font-semibold">Performance IA</h2>
                </CardHeader>
                <CardBody>
                  <p className="font-display text-2xl font-semibold">
                    {data.aiPerformance.resolutionRate !== null
                      ? `${Math.round(data.aiPerformance.resolutionRate * 100)}%`
                      : '—'}
                  </p>
                  <p className="text-sm text-ink-soft">
                    Taux de succès sur {data.aiPerformance.totalInteractions} interaction
                    {data.aiPerformance.totalInteractions > 1 ? 's' : ''}
                  </p>
                </CardBody>
              </Card>

              <Card>
                <CardHeader className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-danger" />
                  <h2 className="font-semibold">Alertes</h2>
                </CardHeader>
                <CardBody className="flex flex-col gap-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-ink-soft">Commandes en retard</span>
                    <Badge tone={data.alerts.lateOrders > 0 ? 'danger' : 'neutral'}>
                      {data.alerts.lateOrders}
                    </Badge>
                  </div>
                  <div>
                    <p className="mb-1.5 text-sm text-ink-soft">Stock bas</p>
                    {data.alerts.lowStock.length === 0 && (
                      <p className="text-xs text-ink-faint">Aucun produit en stock critique.</p>
                    )}
                    <div className="flex flex-col gap-1">
                      {data.alerts.lowStock.map((p) => (
                        <div key={p.id} className="flex items-center justify-between text-xs">
                          <span className="text-ink">{p.name}</span>
                          <span className="font-mono text-danger">{p.stock}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardBody>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof TrendingUp;
  label: string;
  value: string | number;
}) {
  return (
    <Card>
      <CardBody className="flex items-center gap-3">
        <div className="rounded-lg bg-accent-soft p-2.5 text-accent-dark">
          <Icon className="h-4 w-4" />
        </div>
        <div>
          <p className="font-display text-lg font-semibold text-ink">{value}</p>
          <p className="text-xs text-ink-soft">{label}</p>
        </div>
      </CardBody>
    </Card>
  );
}

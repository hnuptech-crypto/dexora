'use client';

import { FormEvent, Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ArrowLeft, Users } from 'lucide-react';
import { apiFetch, ApiError } from '@/lib/api-client';
import { Card, CardBody, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import type { CampaignType } from '@/lib/types';

const typeLabels: Record<CampaignType, string> = {
  PROMOTION: 'Promotion',
  REMINDER: 'Rappel',
  ANNOUNCEMENT: 'Annonce',
  FOLLOWUP: 'Relance',
};

export default function NewCampaignPage() {
  return (
    <Suspense fallback={<p className="text-sm text-ink-soft">Chargement…</p>}>
      <NewCampaignForm />
    </Suspense>
  );
}

function NewCampaignForm() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [form, setForm] = useState({
    name: '',
    type: 'FOLLOWUP' as CampaignType,
    message: '',
    scheduledAt: '',
  });
  const [segment, setSegment] = useState({
    tag: searchParams.get('tag') ?? '',
    minSpent: searchParams.get('minSpent') ?? '',
    inactiveSinceDays: searchParams.get('inactiveSinceDays') ?? '',
    search: searchParams.get('search') ?? '',
  });
  const [audienceCount, setAudienceCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const buildSegmentPayload = () => ({
    tag: segment.tag || undefined,
    minSpent: segment.minSpent ? Number(segment.minSpent) : undefined,
    inactiveSinceDays: segment.inactiveSinceDays ? Number(segment.inactiveSinceDays) : undefined,
    search: segment.search || undefined,
  });

  useEffect(() => {
    const timeout = setTimeout(() => {
      apiFetch<{ count: number }>('/campaigns/preview-audience', {
        method: 'POST',
        body: JSON.stringify(buildSegmentPayload()),
      })
        .then((res) => setAudienceCount(res.count))
        .catch(() => setAudienceCount(null));
    }, 300);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [segment]);

  const handleSubmit = async (e: FormEvent, action: 'draft' | 'schedule' | 'send') => {
    e.preventDefault();
    setError(null);
    setIsSaving(true);
    try {
      const created = await apiFetch<{ id: string }>('/campaigns', {
        method: 'POST',
        body: JSON.stringify({
          name: form.name,
          type: form.type,
          message: form.message,
          segment: buildSegmentPayload(),
          scheduledAt: action === 'schedule' && form.scheduledAt ? new Date(form.scheduledAt).toISOString() : undefined,
        }),
      });

      if (action === 'send') {
        await apiFetch(`/campaigns/${created.id}/send-now`, { method: 'POST' });
      }

      router.push('/campaigns');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Création impossible.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <div className="flex items-center gap-3">
        <button onClick={() => router.push('/campaigns')} className="text-ink-soft hover:text-ink">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-xl font-semibold">Nouvelle campagne</h1>
      </div>

      <Card>
        <CardHeader>
          <h2 className="font-semibold">Message</h2>
        </CardHeader>
        <CardBody className="flex flex-col gap-4">
          <Input
            label="Nom (interne)"
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-ink-soft">Type</label>
            <select
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value as CampaignType })}
              className="rounded border border-border bg-paper px-3 py-2 text-sm focus:border-brand focus:outline-none"
            >
              {Object.entries(typeLabels).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-ink-soft">
              Message — utilisez <code className="rounded bg-paper-dim px-1 font-mono">{'{{name}}'}</code> pour
              personnaliser avec le nom du client
            </label>
            <textarea
              rows={4}
              required
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Bonjour {{name}}, on a une offre spéciale rien que pour vous…"
              className="rounded border border-border bg-paper px-3 py-2 text-sm focus:border-brand focus:outline-none"
            />
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader>
          <h2 className="font-semibold">Ciblage</h2>
          <p className="text-sm text-ink-soft">Les mêmes filtres que la page Clients.</p>
        </CardHeader>
        <CardBody className="flex flex-col gap-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input
              label="Tag"
              placeholder="VIP, Régulier…"
              value={segment.tag}
              onChange={(e) => setSegment({ ...segment, tag: e.target.value })}
            />
            <Input
              label="Dépense minimum (FCFA)"
              type="number"
              value={segment.minSpent}
              onChange={(e) => setSegment({ ...segment, minSpent: e.target.value })}
            />
            <Input
              label="Inactif depuis (jours)"
              type="number"
              value={segment.inactiveSinceDays}
              onChange={(e) => setSegment({ ...segment, inactiveSinceDays: e.target.value })}
            />
            <Input
              label="Recherche (nom/numéro)"
              value={segment.search}
              onChange={(e) => setSegment({ ...segment, search: e.target.value })}
            />
          </div>

          <div className="flex items-center gap-2 rounded bg-paper-dim px-3 py-2 text-sm text-ink-soft">
            <Users className="h-4 w-4" />
            {audienceCount === null ? 'Calcul…' : `${audienceCount} client${audienceCount > 1 ? 's' : ''} ciblé${audienceCount > 1 ? 's' : ''}`}
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader>
          <h2 className="font-semibold">Envoi</h2>
        </CardHeader>
        <CardBody className="flex flex-col gap-4">
          <Input
            label="Planifier pour plus tard (optionnel)"
            type="datetime-local"
            value={form.scheduledAt}
            onChange={(e) => setForm({ ...form, scheduledAt: e.target.value })}
          />

          {error && <p className="text-sm text-danger">{error}</p>}

          <div className="flex gap-2">
            <Button
              variant="secondary"
              isLoading={isSaving}
              onClick={(e) => handleSubmit(e as unknown as FormEvent, 'draft')}
            >
              Enregistrer en brouillon
            </Button>
            {form.scheduledAt && (
              <Button isLoading={isSaving} onClick={(e) => handleSubmit(e as unknown as FormEvent, 'schedule')}>
                Planifier
              </Button>
            )}
            {!form.scheduledAt && (
              <Button isLoading={isSaving} onClick={(e) => handleSubmit(e as unknown as FormEvent, 'send')}>
                Envoyer maintenant
              </Button>
            )}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

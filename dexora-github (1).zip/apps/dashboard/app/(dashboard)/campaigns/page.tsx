'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Plus, Send, Ban, Sparkles } from 'lucide-react';
import { apiFetch } from '@/lib/api-client';
import { Card, CardBody } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatDateTime } from '@/lib/format';
import type { Campaign, CampaignStatus, OpportunitiesSummary } from '@/lib/types';

const statusMeta: Record<CampaignStatus, { label: string; tone: 'success' | 'danger' | 'accent' | 'neutral' }> = {
  DRAFT: { label: 'Brouillon', tone: 'neutral' },
  SCHEDULED: { label: 'Planifiée', tone: 'accent' },
  SENDING: { label: 'Envoi en cours', tone: 'accent' },
  SENT: { label: 'Envoyée', tone: 'success' },
  CANCELLED: { label: 'Annulée', tone: 'danger' },
};

export default function CampaignsPage() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [opportunities, setOpportunities] = useState<OpportunitiesSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const load = () => {
    setIsLoading(true);
    Promise.all([
      apiFetch<Campaign[]>('/campaigns'),
      apiFetch<OpportunitiesSummary>('/campaigns/opportunities'),
    ])
      .then(([campaignsData, opportunitiesData]) => {
        setCampaigns(campaignsData);
        setOpportunities(opportunitiesData);
      })
      .finally(() => setIsLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const sendNow = async (id: string) => {
    if (!confirm('Envoyer cette campagne maintenant ?')) return;
    await apiFetch(`/campaigns/${id}/send-now`, { method: 'POST' });
    load();
  };

  const cancel = async (id: string) => {
    if (!confirm('Annuler cette campagne ?')) return;
    await apiFetch(`/campaigns/${id}/cancel`, { method: 'PATCH' });
    load();
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Campagnes & relances</h1>
          <p className="text-sm text-ink-soft">Réengagez vos clients au bon moment.</p>
        </div>
        <Link href="/campaigns/new">
          <Button>
            <Plus className="h-4 w-4" />
            Nouvelle campagne
          </Button>
        </Link>
      </div>

      {opportunities && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <OpportunityCard
            label={opportunities.interestedNoOrder.label}
            count={opportunities.interestedNoOrder.count}
            filter={opportunities.interestedNoOrder.suggestedFilter}
          />
          <OpportunityCard
            label={opportunities.inactive90Days.label}
            count={opportunities.inactive90Days.count}
            filter={opportunities.inactive90Days.suggestedFilter}
          />
          <OpportunityCard
            label={opportunities.vipCustomers.label}
            count={opportunities.vipCustomers.count}
            filter={opportunities.vipCustomers.suggestedFilter}
          />
        </div>
      )}

      <Card className="divide-y divide-border overflow-hidden">
        {isLoading && <p className="px-5 py-8 text-center text-sm text-ink-faint">Chargement…</p>}
        {!isLoading && campaigns.length === 0 && (
          <p className="px-5 py-8 text-center text-sm text-ink-faint">
            Aucune campagne. Créez-en une à partir d&rsquo;une opportunité ci-dessus ou depuis « Nouvelle campagne ».
          </p>
        )}
        {campaigns.map((campaign) => (
          <div key={campaign.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium text-ink">{campaign.name}</p>
                <Badge tone={statusMeta[campaign.status].tone}>{statusMeta[campaign.status].label}</Badge>
              </div>
              <p className="mt-0.5 max-w-lg truncate text-sm text-ink-faint">{campaign.message}</p>
              <p className="mt-1 text-xs text-ink-faint">
                {campaign.status === 'SENT' && campaign.sentAt
                  ? `Envoyée le ${formatDateTime(campaign.sentAt)} · ${campaign.sentCount} message(s)`
                  : campaign.scheduledAt
                    ? `Planifiée pour le ${formatDateTime(campaign.scheduledAt)}`
                    : `Créée le ${formatDateTime(campaign.createdAt)}`}
              </p>
            </div>

            {(campaign.status === 'DRAFT' || campaign.status === 'SCHEDULED') && (
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => sendNow(campaign.id)}>
                  <Send className="h-4 w-4" /> Envoyer
                </Button>
                <Button variant="ghost" onClick={() => cancel(campaign.id)}>
                  <Ban className="h-4 w-4" /> Annuler
                </Button>
              </div>
            )}
          </div>
        ))}
      </Card>
    </div>
  );
}

function OpportunityCard({
  label,
  count,
  filter,
}: {
  label: string;
  count: number;
  filter: OpportunitiesSummary['vipCustomers']['suggestedFilter'];
}) {
  const href = filter
    ? `/campaigns/new?${new URLSearchParams(filter as Record<string, string>).toString()}`
    : null;

  return (
    <Card>
      <CardBody className="flex flex-col gap-2">
        <div className="flex items-center gap-2 text-accent-dark">
          <Sparkles className="h-4 w-4" />
          <span className="font-display text-xl font-semibold text-ink">{count}</span>
        </div>
        <p className="text-sm text-ink-soft">{label}</p>
        {href && (
          <Link href={href} className="text-xs font-medium text-brand hover:underline">
            Créer une campagne pour ce segment →
          </Link>
        )}
      </CardBody>
    </Card>
  );
}

'use client';

import { FormEvent, useEffect, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Bot, Send, UserPlus, UserMinus } from 'lucide-react';
import { apiFetch } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { formatDateTime } from '@/lib/format';
import type { Conversation } from '@/lib/types';

export default function ConversationDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [content, setContent] = useState('');
  const [isSending, setIsSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const load = () => apiFetch<Conversation>(`/conversations/${params.id}`).then(setConversation);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation?.messages?.length]);

  const handleSend = async (e: FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    setIsSending(true);
    try {
      await apiFetch(`/conversations/${params.id}/messages`, {
        method: 'POST',
        body: JSON.stringify({ content }),
      });
      setContent('');
      await load();
    } finally {
      setIsSending(false);
    }
  };

  const toggleAssign = async () => {
    if (conversation?.assignedTo) {
      await apiFetch(`/conversations/${params.id}/unassign`, { method: 'PATCH' });
    } else {
      await apiFetch(`/conversations/${params.id}/assign`, { method: 'PATCH', body: JSON.stringify({}) });
    }
    await load();
  };

  if (!conversation) {
    return <p className="text-sm text-ink-soft">Chargement…</p>;
  }

  return (
    <div className="flex h-full flex-col gap-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => router.push('/conversations')} className="text-ink-soft hover:text-ink">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="font-semibold">{conversation.customer.name ?? conversation.customer.phoneNumber}</h1>
            <p className="font-mono text-xs text-ink-faint">{conversation.customer.phoneNumber}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {conversation.aiHandled && !conversation.assignedTo && (
            <span className="flex items-center gap-1.5 rounded bg-brand/10 px-2 py-1 text-xs font-medium text-brand">
              <Bot className="h-3.5 w-3.5" /> Géré par l&rsquo;IA
            </span>
          )}
          {conversation.assignedTo && (
            <span className="text-xs text-ink-soft">
              Assigné à <span className="font-medium text-ink">{conversation.assignedTo.name}</span>
            </span>
          )}
          <Button variant="secondary" onClick={toggleAssign}>
            {conversation.assignedTo ? (
              <>
                <UserMinus className="h-4 w-4" /> Rendre à l&rsquo;IA
              </>
            ) : (
              <>
                <UserPlus className="h-4 w-4" /> Prendre en charge
              </>
            )}
          </Button>
        </div>
      </div>

      <Card className="flex flex-1 flex-col overflow-hidden">
        <div className="flex-1 space-y-3 overflow-y-auto p-5">
          {conversation.messages?.map((message) => {
            const isCustomer = message.senderType === 'CUSTOMER';
            return (
              <div key={message.id} className={`flex ${isCustomer ? 'justify-start' : 'justify-end'}`}>
                <div
                  className={`max-w-[70%] rounded-lg px-3.5 py-2 text-sm ${
                    isCustomer ? 'bg-paper-dim text-ink' : 'bg-brand text-paper'
                  }`}
                >
                  <p>{message.content}</p>
                  <div
                    className={`mt-1 flex items-center gap-1.5 text-[11px] ${
                      isCustomer ? 'text-ink-faint' : 'text-paper/60'
                    }`}
                  >
                    {message.senderType === 'AI' && <Bot className="h-3 w-3" />}
                    {formatDateTime(message.createdAt)}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={handleSend} className="flex gap-2 border-t border-border p-3">
          <input
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Écrire une réponse…"
            className="flex-1 rounded border border-border bg-paper px-3 py-2 text-sm focus:border-brand focus:outline-none"
          />
          <Button type="submit" isLoading={isSending}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </Card>
    </div>
  );
}

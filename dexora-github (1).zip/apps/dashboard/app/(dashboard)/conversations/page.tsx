'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Bot, User as UserIcon } from 'lucide-react';
import { apiFetch } from '@/lib/api-client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatRelativeTime } from '@/lib/format';
import type { Conversation, ConversationStatus, Paginated } from '@/lib/types';

const statusLabels: Record<ConversationStatus, string> = {
  NEW: 'Nouveau',
  INTERESTED: 'Intéressé',
  ORDER: 'Commande',
  CUSTOMER: 'Client',
  RESOLVED: 'Résolu',
  ARCHIVED: 'Archivé',
};

const filters: { label: string; value: ConversationStatus | 'all' | 'unread' }[] = [
  { label: 'Tous', value: 'all' },
  { label: 'Non lus', value: 'unread' },
  { label: 'Nouveau', value: 'NEW' },
  { label: 'Intéressé', value: 'INTERESTED' },
  { label: 'Commande', value: 'ORDER' },
];

export default function ConversationsPage() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeFilter, setActiveFilter] = useState<(typeof filters)[number]['value']>('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams({ limit: '50' });
    if (activeFilter === 'unread') params.set('unreadOnly', 'true');
    else if (activeFilter !== 'all') params.set('status', activeFilter);

    setIsLoading(true);
    apiFetch<Paginated<Conversation>>(`/conversations?${params.toString()}`)
      .then((data) => setConversations(data.items))
      .finally(() => setIsLoading(false));
  }, [activeFilter]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-semibold">Conversations</h1>
        <p className="text-sm text-ink-soft">Toutes vos discussions WhatsApp, au même endroit.</p>
      </div>

      <div className="flex gap-2">
        {filters.map((f) => (
          <button
            key={f.value}
            onClick={() => setActiveFilter(f.value)}
            className={`rounded px-3 py-1.5 text-sm font-medium transition-colors ${
              activeFilter === f.value ? 'bg-brand text-paper' : 'bg-paper-dim text-ink-soft hover:bg-border/60'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <Card className="divide-y divide-border overflow-hidden">
        {isLoading && <p className="px-5 py-8 text-center text-sm text-ink-faint">Chargement…</p>}
        {!isLoading && conversations.length === 0 && (
          <p className="px-5 py-8 text-center text-sm text-ink-faint">Aucune conversation pour ce filtre.</p>
        )}
        {conversations.map((conv) => (
          <Link
            key={conv.id}
            href={`/conversations/${conv.id}`}
            className="flex items-center gap-4 px-5 py-4 hover:bg-paper-dim/50"
          >
            <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-brand/10 font-display font-semibold text-brand">
              {(conv.customer.name ?? conv.customer.phoneNumber).slice(0, 1).toUpperCase()}
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <p className="truncate font-medium text-ink">
                  {conv.customer.name ?? conv.customer.phoneNumber}
                </p>
                {conv.aiHandled && (
                  <span title="Géré par l'IA">
                    <Bot className="h-3.5 w-3.5 text-brand" />
                  </span>
                )}
              </div>
              <p className="truncate text-sm text-ink-faint">
                {conv.messages?.[0]?.content ?? 'Aucun message'}
              </p>
            </div>

            <div className="flex flex-shrink-0 flex-col items-end gap-1.5">
              <span className="text-xs text-ink-faint">{formatRelativeTime(conv.lastMessageAt)}</span>
              <div className="flex items-center gap-1.5">
                {conv.unreadCount > 0 && (
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-accent text-xs font-semibold text-white">
                    {conv.unreadCount}
                  </span>
                )}
                <Badge tone="neutral">{statusLabels[conv.status]}</Badge>
              </div>
            </div>
          </Link>
        ))}
      </Card>
    </div>
  );
}

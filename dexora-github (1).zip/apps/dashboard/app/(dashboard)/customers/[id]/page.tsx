'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Save } from 'lucide-react';
import { apiFetch } from '@/lib/api-client';
import { Card, CardBody, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatCurrency, formatDateTime } from '@/lib/format';
import type { Customer } from '@/lib/types';

export default function CustomerDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [notes, setNotes] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    apiFetch<Customer>(`/customers/${params.id}`).then((data) => {
      setCustomer(data);
      setNotes(data.notes ?? '');
    });
  }, [params.id]);

  const saveNotes = async () => {
    setIsSaving(true);
    try {
      await apiFetch(`/customers/${params.id}`, { method: 'PATCH', body: JSON.stringify({ notes }) });
    } finally {
      setIsSaving(false);
    }
  };

  if (!customer) return <p className="text-sm text-ink-soft">Chargement…</p>;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-3">
        <button onClick={() => router.push('/customers')} className="text-ink-soft hover:text-ink">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="font-semibold">{customer.name ?? 'Sans nom'}</h1>
          <p className="font-mono text-sm text-ink-soft">{customer.phoneNumber}</p>
        </div>
        <div className="ml-2 flex gap-1">
          {customer.tags.map((t) => (
            <Badge key={t} tone={t === 'VIP' ? 'accent' : 'neutral'}>
              {t}
            </Badge>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <CardBody>
            <p className="text-xs text-ink-faint">Total dépensé</p>
            <p className="font-display text-xl font-semibold">{formatCurrency(customer.totalSpent)}</p>
          </CardBody>
        </Card>
        <Card>
          <CardBody>
            <p className="text-xs text-ink-faint">Commandes</p>
            <p className="font-display text-xl font-semibold">{customer.totalOrders}</p>
          </CardBody>
        </Card>
        <Card>
          <CardBody>
            <p className="text-xs text-ink-faint">Client depuis</p>
            <p className="font-display text-xl font-semibold">{formatDateTime(customer.firstInteractionAt)}</p>
          </CardBody>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <Card>
            <CardHeader>
              <h2 className="font-semibold">Commandes récentes</h2>
            </CardHeader>
            <CardBody className="divide-y divide-border p-0">
              {(customer.orders ?? []).length === 0 && (
                <p className="px-5 py-4 text-sm text-ink-faint">Aucune commande.</p>
              )}
              {(customer.orders ?? []).map((order) => (
                <Link
                  key={order.id}
                  href={`/orders/${order.id}`}
                  className="flex items-center justify-between px-5 py-3 hover:bg-paper-dim/50"
                >
                  <span className="font-mono text-sm text-brand">{order.orderNumber}</span>
                  <span className="text-sm font-medium">{formatCurrency(order.total)}</span>
                </Link>
              ))}
            </CardBody>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="font-semibold">Conversations récentes</h2>
            </CardHeader>
            <CardBody className="divide-y divide-border p-0">
              {(customer.conversations ?? []).length === 0 && (
                <p className="px-5 py-4 text-sm text-ink-faint">Aucune conversation.</p>
              )}
              {(customer.conversations ?? []).map((conv) => (
                <Link
                  key={conv.id}
                  href={`/conversations/${conv.id}`}
                  className="flex items-center justify-between px-5 py-3 hover:bg-paper-dim/50"
                >
                  <span className="text-sm text-ink">{formatDateTime(conv.lastMessageAt)}</span>
                  <Badge tone="neutral">{conv.status}</Badge>
                </Link>
              ))}
            </CardBody>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <h2 className="font-semibold">Notes internes</h2>
          </CardHeader>
          <CardBody className="flex flex-col gap-3">
            <textarea
              rows={8}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Notes visibles uniquement par votre équipe…"
              className="rounded border border-border bg-paper px-3 py-2 text-sm focus:border-brand focus:outline-none"
            />
            <Button onClick={saveNotes} isLoading={isSaving} variant="secondary">
              <Save className="h-4 w-4" />
              Enregistrer
            </Button>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

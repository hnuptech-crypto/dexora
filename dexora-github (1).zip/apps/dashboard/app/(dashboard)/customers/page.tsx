'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiFetch } from '@/lib/api-client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatCurrency, formatRelativeTime } from '@/lib/format';
import type { Customer, Paginated } from '@/lib/types';

const tagFilters = ['Tous', 'Nouveau', 'Régulier', 'VIP', 'Intéressé', 'Inactif'];

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [tag, setTag] = useState('Tous');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams({ limit: '50' });
    if (search) params.set('search', search);
    if (tag !== 'Tous') params.set('tag', tag);

    setIsLoading(true);
    apiFetch<Paginated<Customer>>(`/customers?${params.toString()}`)
      .then((data) => {
        setCustomers(data.items);
        setTotal(data.pagination.total);
      })
      .finally(() => setIsLoading(false));
  }, [search, tag]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-semibold">Clients</h1>
        <p className="text-sm text-ink-soft">{total} client{total > 1 ? 's' : ''}</p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher un nom, un numéro…"
          className="w-full max-w-xs rounded border border-border bg-paper px-3 py-2 text-sm focus:border-brand focus:outline-none"
        />
        <div className="flex gap-2">
          {tagFilters.map((t) => (
            <button
              key={t}
              onClick={() => setTag(t)}
              className={`rounded px-3 py-1.5 text-sm font-medium transition-colors ${
                tag === t ? 'bg-brand text-paper' : 'bg-paper-dim text-ink-soft hover:bg-border/60'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="hidden overflow-x-auto md:block">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-paper-dim text-ink-soft">
              <tr>
                <th className="px-4 py-3 font-medium">Client</th>
                <th className="px-4 py-3 font-medium">Tags</th>
                <th className="px-4 py-3 font-medium">Commandes</th>
                <th className="px-4 py-3 font-medium">Total dépensé</th>
                <th className="px-4 py-3 font-medium">Dernière interaction</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-ink-faint">
                    Chargement…
                  </td>
                </tr>
              )}
              {!isLoading && customers.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-ink-faint">
                    Aucun client pour ce filtre.
                  </td>
                </tr>
              )}
              {customers.map((customer) => (
                <tr key={customer.id} className="border-b border-border last:border-0 hover:bg-paper-dim/50">
                  <td className="px-4 py-3">
                    <Link href={`/customers/${customer.id}`} className="font-medium text-ink hover:text-brand">
                      {customer.name ?? 'Sans nom'}
                    </Link>
                    <p className="font-mono text-xs text-ink-faint">{customer.phoneNumber}</p>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {customer.tags.map((t) => (
                        <Badge key={t} tone={t === 'VIP' ? 'accent' : 'neutral'}>
                          {t}
                        </Badge>
                      ))}
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono">{customer.totalOrders}</td>
                  <td className="px-4 py-3 font-medium">{formatCurrency(customer.totalSpent)}</td>
                  <td className="px-4 py-3 text-ink-faint">{formatRelativeTime(customer.lastInteractionAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="divide-y divide-border md:hidden">
          {isLoading && <p className="px-4 py-8 text-center text-ink-faint">Chargement…</p>}
          {!isLoading && customers.length === 0 && (
            <p className="px-4 py-8 text-center text-ink-faint">Aucun client pour ce filtre.</p>
          )}
          {customers.map((customer) => (
            <Link
              key={customer.id}
              href={`/customers/${customer.id}`}
              className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-paper-dim/50"
            >
              <div className="min-w-0">
                <p className="font-medium text-ink">{customer.name ?? 'Sans nom'}</p>
                <p className="font-mono text-xs text-ink-faint">{customer.phoneNumber}</p>
                <div className="mt-1 flex flex-wrap gap-1">
                  {customer.tags.map((t) => (
                    <Badge key={t} tone={t === 'VIP' ? 'accent' : 'neutral'}>
                      {t}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex-shrink-0 text-right">
                <p className="font-medium">{formatCurrency(customer.totalSpent)}</p>
                <p className="text-xs text-ink-faint">{customer.totalOrders} commande(s)</p>
              </div>
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Download, Wallet } from 'lucide-react';
import { apiFetch, apiFetchBlob, ApiError } from '@/lib/api-client';
import { Card, CardBody, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatCurrency, formatDateTime } from '@/lib/format';
import type { Order, OrderStatus, Payment, PaymentProvider } from '@/lib/types';

const statusFlow: OrderStatus[] = ['NEW', 'CONFIRMED', 'PREPARING', 'DELIVERING', 'DELIVERED'];
const statusLabels: Record<OrderStatus, string> = {
  NEW: 'Nouvelle',
  CONFIRMED: 'Confirmée',
  PREPARING: 'En préparation',
  DELIVERING: 'En livraison',
  DELIVERED: 'Livrée',
  CANCELLED: 'Annulée',
};

const paymentStatusTone: Record<string, 'success' | 'danger' | 'accent' | 'neutral'> = {
  PAID: 'success',
  FAILED: 'danger',
  PENDING: 'accent',
  REFUNDED: 'neutral',
};

const providerLabels: Record<PaymentProvider, string> = {
  MTN_MOMO: 'MTN Mobile Money',
  ORANGE_MONEY: 'Orange Money',
  WAVE: 'Wave',
};

export default function OrderDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [order, setOrder] = useState<Order | null>(null);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [payingWith, setPayingWith] = useState<PaymentProvider | null>(null);
  const [paymentNotice, setPaymentNotice] = useState<string | null>(null);

  const load = async () => {
    const [orderData, paymentsData] = await Promise.all([
      apiFetch<Order>(`/orders/${params.id}`),
      apiFetch<Payment[]>(`/orders/${params.id}/payment/history`).catch(() => []),
    ]);
    setOrder(orderData);
    setPayments(paymentsData);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id]);

  const updateStatus = async (status: OrderStatus) => {
    setIsUpdating(true);
    try {
      await apiFetch(`/orders/${params.id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
      await load();
    } finally {
      setIsUpdating(false);
    }
  };

  const downloadInvoice = async () => {
    setIsDownloading(true);
    try {
      const blob = await apiFetchBlob(`/orders/${params.id}/invoice`);
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
    } finally {
      setIsDownloading(false);
    }
  };

  const requestPayment = async (provider: PaymentProvider) => {
    setPayingWith(provider);
    setPaymentNotice(null);
    try {
      await apiFetch(`/orders/${params.id}/payment/link`, {
        method: 'POST',
        body: JSON.stringify({ provider }),
      });
      setPaymentNotice(
        provider === 'MTN_MOMO'
          ? 'Demande de paiement envoyée sur le téléphone du client.'
          : 'Lien de paiement envoyé au client par WhatsApp.',
      );
      await load();
    } catch (err) {
      setPaymentNotice(err instanceof ApiError ? err.message : "Échec de l'envoi du paiement.");
    } finally {
      setPayingWith(null);
    }
  };

  if (!order) return <p className="text-sm text-ink-soft">Chargement…</p>;

  const currentStepIndex = statusFlow.indexOf(order.status);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => router.push('/orders')} className="text-ink-soft hover:text-ink">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="font-mono font-semibold">{order.orderNumber}</h1>
            <p className="text-sm text-ink-soft">{formatDateTime(order.createdAt)}</p>
          </div>
        </div>

        <Button variant="secondary" onClick={downloadInvoice} isLoading={isDownloading}>
          <Download className="h-4 w-4" />
          Facture PDF
        </Button>
      </div>

      {order.status !== 'CANCELLED' ? (
        <div className="flex flex-wrap items-center gap-2">
          {statusFlow.map((step, i) => (
            <div key={step} className="flex items-center gap-2">
              <button
                disabled={isUpdating}
                onClick={() => updateStatus(step)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors disabled:opacity-60 ${
                  i <= currentStepIndex ? 'bg-brand text-paper' : 'bg-paper-dim text-ink-faint hover:bg-border/60'
                }`}
              >
                {statusLabels[step]}
              </button>
              {i < statusFlow.length - 1 && <div className="h-px w-4 bg-border" />}
            </div>
          ))}
          <button
            onClick={() => updateStatus('CANCELLED')}
            disabled={isUpdating}
            className="ml-4 text-xs font-medium text-danger hover:underline disabled:opacity-60"
          >
            Annuler la commande
          </button>
        </div>
      ) : (
        <Badge tone="danger">Commande annulée</Badge>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <h2 className="font-semibold">Articles</h2>
          </CardHeader>
          <CardBody className="divide-y divide-border p-0">
            {order.items.map((item) => (
              <div key={item.id} className="flex items-center justify-between px-5 py-3">
                <div>
                  <p className="font-medium text-ink">{item.productName}</p>
                  <p className="text-xs text-ink-faint">
                    {item.quantity} × {formatCurrency(item.unitPrice)}
                  </p>
                </div>
                <p className="font-medium">{formatCurrency(item.totalPrice)}</p>
              </div>
            ))}
            <div className="flex items-center justify-between px-5 py-3">
              <p className="font-semibold">Total</p>
              <p className="font-display text-lg font-semibold">{formatCurrency(order.total)}</p>
            </div>
          </CardBody>
        </Card>

        <div className="flex flex-col gap-6">
          <Card>
            <CardHeader>
              <h2 className="font-semibold">Client</h2>
            </CardHeader>
            <CardBody className="flex flex-col gap-2 text-sm">
              <p className="font-medium text-ink">{order.customer.name ?? 'Sans nom'}</p>
              <p className="font-mono text-ink-soft">{order.customer.phoneNumber}</p>
              {order.deliveryAddress && (
                <p className="text-ink-soft">
                  <span className="text-ink-faint">Livraison : </span>
                  {order.deliveryAddress}
                </p>
              )}
            </CardBody>
          </Card>

          <Card>
            <CardHeader className="flex items-center justify-between">
              <h2 className="font-semibold">Paiement</h2>
              <Badge tone={paymentStatusTone[order.paymentStatus] ?? 'neutral'}>{order.paymentStatus}</Badge>
            </CardHeader>
            <CardBody className="flex flex-col gap-3">
              {order.paymentStatus !== 'PAID' && (
                <div className="flex flex-col gap-2">
                  <p className="text-xs text-ink-faint">
                    Envoyer une demande de paiement au client (lien WhatsApp, ou push direct pour MoMo).
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {(Object.keys(providerLabels) as PaymentProvider[]).map((provider) => (
                      <Button
                        key={provider}
                        variant="secondary"
                        isLoading={payingWith === provider}
                        onClick={() => requestPayment(provider)}
                      >
                        <Wallet className="h-4 w-4" />
                        {providerLabels[provider]}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {paymentNotice && <p className="text-xs text-ink-soft">{paymentNotice}</p>}

              {payments.length > 0 && (
                <div className="mt-1 divide-y divide-border border-t border-border pt-2">
                  {payments.map((p) => (
                    <div key={p.id} className="flex items-center justify-between py-2 text-xs">
                      <span className="text-ink-soft">{providerLabels[p.provider]}</span>
                      <Badge tone={p.status === 'SUCCESSFUL' ? 'success' : p.status === 'FAILED' ? 'danger' : 'accent'}>
                        {p.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiFetch } from '@/lib/api-client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatCurrency, formatDateTime } from '@/lib/format';
import type { Order, OrderStatus, Paginated } from '@/lib/types';

const statusMeta: Record<OrderStatus, { label: string; tone: 'success' | 'danger' | 'accent' | 'neutral' }> = {
  NEW: { label: 'Nouvelle', tone: 'accent' },
  CONFIRMED: { label: 'Confirmée', tone: 'accent' },
  PREPARING: { label: 'En préparation', tone: 'accent' },
  DELIVERING: { label: 'En livraison', tone: 'accent' },
  DELIVERED: { label: 'Livrée', tone: 'success' },
  CANCELLED: { label: 'Annulée', tone: 'danger' },
};

const filters: (OrderStatus | 'all')[] = ['all', 'NEW', 'CONFIRMED', 'PREPARING', 'DELIVERING', 'DELIVERED', 'CANCELLED'];

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [total, setTotal] = useState(0);
  const [activeFilter, setActiveFilter] = useState<OrderStatus | 'all'>('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams({ limit: '50' });
    if (activeFilter !== 'all') params.set('status', activeFilter);

    setIsLoading(true);
    apiFetch<Paginated<Order>>(`/orders?${params.toString()}`)
      .then((data) => {
        setOrders(data.items);
        setTotal(data.pagination.total);
      })
      .finally(() => setIsLoading(false));
  }, [activeFilter]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-semibold">Commandes</h1>
        <p className="text-sm text-ink-soft">{total} commande{total > 1 ? 's' : ''}</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            className={`rounded px-3 py-1.5 text-sm font-medium transition-colors ${
              activeFilter === f ? 'bg-brand text-paper' : 'bg-paper-dim text-ink-soft hover:bg-border/60'
            }`}
          >
            {f === 'all' ? 'Toutes' : statusMeta[f].label}
          </button>
        ))}
      </div>

      <Card className="overflow-hidden">
        <div className="hidden overflow-x-auto md:block">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-paper-dim text-ink-soft">
              <tr>
                <th className="px-4 py-3 font-medium">Commande</th>
                <th className="px-4 py-3 font-medium">Client</th>
                <th className="px-4 py-3 font-medium">Total</th>
                <th className="px-4 py-3 font-medium">Statut</th>
                <th className="px-4 py-3 font-medium">Date</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-ink-faint">
                    Chargement…
                  </td>
                </tr>
              )}
              {!isLoading && orders.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-ink-faint">
                    Aucune commande pour ce filtre.
                  </td>
                </tr>
              )}
              {orders.map((order) => (
                <tr key={order.id} className="border-b border-border last:border-0 hover:bg-paper-dim/50">
                  <td className="px-4 py-3">
                    <Link href={`/orders/${order.id}`} className="font-mono text-sm font-medium text-brand hover:underline">
                      {order.orderNumber}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-ink">{order.customer.name ?? order.customer.phoneNumber}</td>
                  <td className="px-4 py-3 font-medium">{formatCurrency(order.total)}</td>
                  <td className="px-4 py-3">
                    <Badge tone={statusMeta[order.status].tone}>{statusMeta[order.status].label}</Badge>
                  </td>
                  <td className="px-4 py-3 text-ink-faint">{formatDateTime(order.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="divide-y divide-border md:hidden">
          {isLoading && <p className="px-4 py-8 text-center text-ink-faint">Chargement…</p>}
          {!isLoading && orders.length === 0 && (
            <p className="px-4 py-8 text-center text-ink-faint">Aucune commande pour ce filtre.</p>
          )}
          {orders.map((order) => (
            <Link
              key={order.id}
              href={`/orders/${order.id}`}
              className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-paper-dim/50"
            >
              <div className="min-w-0">
                <p className="font-mono text-sm font-medium text-brand">{order.orderNumber}</p>
                <p className="truncate text-sm text-ink-soft">
                  {order.customer.name ?? order.customer.phoneNumber}
                </p>
                <p className="text-xs text-ink-faint">{formatDateTime(order.createdAt)}</p>
              </div>
              <div className="flex flex-shrink-0 flex-col items-end gap-1.5">
                <p className="font-medium">{formatCurrency(order.total)}</p>
                <Badge tone={statusMeta[order.status].tone}>{statusMeta[order.status].label}</Badge>
              </div>
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}

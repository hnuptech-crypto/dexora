'use client';

import { useEffect, useState } from 'react';
import { Package, ShoppingBag, Users, MessageCircle } from 'lucide-react';
import { apiFetch, ApiError } from '@/lib/api-client';
import { useAuth } from '@/lib/auth-context';
import { Card, CardBody } from '@/components/ui/card';
import { CreateBusinessForm } from '@/components/layout/create-business-form';
import type { Business, Paginated, Product } from '@/lib/types';

interface StatCardData {
  label: string;
  value: number | null;
  icon: typeof Package;
}

export default function OverviewPage() {
  const { user, refreshProfile } = useAuth();
  const [business, setBusiness] = useState<Business | null>(null);
  const [needsBusiness, setNeedsBusiness] = useState(false);
  const [stats, setStats] = useState<{ products: number; orders: number; customers: number } | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadBusiness = async () => {
    setIsLoading(true);
    try {
      const data = await apiFetch<Business>('/business/me');
      setBusiness(data);
      setNeedsBusiness(false);
    } catch (err) {
      if (err instanceof ApiError && err.status === 404) {
        setNeedsBusiness(true);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadBusiness();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!business) return;
    Promise.all([
      apiFetch<Paginated<Product>>('/products?limit=1&status=all'),
      apiFetch<Paginated<unknown>>('/orders?limit=1'),
      apiFetch<Paginated<unknown>>('/customers?limit=1'),
    ])
      .then(([products, orders, customers]) => {
        setStats({
          products: products.pagination.total,
          orders: orders.pagination.total,
          customers: customers.pagination.total,
        });
      })
      .catch(() => setStats(null));
  }, [business]);

  if (isLoading) {
    return <div className="text-sm text-ink-soft">Chargement…</div>;
  }

  if (needsBusiness) {
    return (
      <CreateBusinessForm
        onCreated={async () => {
          await refreshProfile();
          await loadBusiness();
        }}
      />
    );
  }

  const cards: StatCardData[] = [
    { label: 'Produits au catalogue', value: stats?.products ?? null, icon: Package },
    { label: 'Commandes', value: stats?.orders ?? null, icon: ShoppingBag },
    { label: 'Clients', value: stats?.customers ?? null, icon: Users },
  ];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-semibold">Bonjour {user?.name?.split(' ')[0]} 👋</h1>
        <p className="text-sm text-ink-soft">
          {business?.name} · {business?.currency}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {cards.map(({ label, value, icon: Icon }) => (
          <Card key={label}>
            <CardBody className="flex items-center gap-4">
              <div className="rounded-lg bg-accent-soft p-3 text-accent-dark">
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <p className="font-display text-2xl font-semibold text-ink">{value ?? '—'}</p>
                <p className="text-sm text-ink-soft">{label}</p>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      <Card>
        <CardBody className="flex items-center gap-4">
          <div className="rounded-lg bg-brand/10 p-3 text-brand">
            <MessageCircle className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-medium text-ink">
              {business?.whatsappPhoneNumberId
                ? 'Connexion WhatsApp Business configurée.'
                : 'Connexion WhatsApp Business non configurée.'}
            </p>
            <p className="text-sm text-ink-soft">
              Configurable depuis Réglages → WhatsApp (page à venir dans un prochain sprint).
            </p>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

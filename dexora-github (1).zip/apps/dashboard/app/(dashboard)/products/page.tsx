'use client';

import { FormEvent, useEffect, useState } from 'react';
import { Plus, Search, Archive, Pencil, X } from 'lucide-react';
import { apiFetch, ApiError } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import type { Paginated, Product } from '@/lib/types';

const statusTone: Record<Product['status'], 'success' | 'danger' | 'neutral'> = {
  Disponible: 'success',
  Rupture: 'danger',
  Archivé: 'neutral',
};

const emptyForm = {
  name: '',
  description: '',
  price: '',
  promotionPrice: '',
  stock: '',
  sku: '',
  category: '',
  subCategory: '',
};

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const loadProducts = async (query = '') => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams({ status: 'all', limit: '50' });
      if (query) params.set('search', query);
      const data = await apiFetch<Paginated<Product>>(`/products?${params.toString()}`);
      setProducts(data.items);
      setTotal(data.pagination.total);
    } catch {
      // Une notification toast serait ajoutée avec le reste du design system.
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const openCreateForm = () => {
    setEditing(null);
    setForm(emptyForm);
    setFormError(null);
    setFormOpen(true);
  };

  const openEditForm = (product: Product) => {
    setEditing(product);
    setForm({
      name: product.name,
      description: product.description ?? '',
      price: String(product.price),
      promotionPrice: product.promotionPrice ? String(product.promotionPrice) : '',
      stock: String(product.stock),
      sku: product.sku ?? '',
      category: product.category,
      subCategory: product.subCategory ?? '',
    });
    setFormError(null);
    setFormOpen(true);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setIsSaving(true);

    const payload = {
      name: form.name,
      description: form.description || undefined,
      price: Number(form.price),
      promotionPrice: form.promotionPrice ? Number(form.promotionPrice) : undefined,
      stock: form.stock ? Number(form.stock) : 0,
      sku: form.sku || undefined,
      category: form.category,
      subCategory: form.subCategory || undefined,
    };

    try {
      if (editing) {
        await apiFetch(`/products/${editing.id}`, { method: 'PATCH', body: JSON.stringify(payload) });
      } else {
        await apiFetch('/products', { method: 'POST', body: JSON.stringify(payload) });
      }
      setFormOpen(false);
      await loadProducts(search);
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Enregistrement impossible.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleArchive = async (product: Product) => {
    if (!confirm(`Archiver "${product.name}" ? Il ne sera plus visible dans le catalogue actif.`)) return;
    await apiFetch(`/products/${product.id}`, { method: 'DELETE' });
    await loadProducts(search);
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Catalogue</h1>
          <p className="text-sm text-ink-soft">{total} produit{total > 1 ? 's' : ''}</p>
        </div>
        <Button onClick={openCreateForm}>
          <Plus className="h-4 w-4" />
          Nouveau produit
        </Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-faint" />
        <input
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            loadProducts(e.target.value);
          }}
          placeholder="Rechercher un produit, un SKU…"
          className="w-full rounded border border-border bg-paper py-2 pl-9 pr-3 text-sm focus:border-brand focus:outline-none"
        />
      </div>

      <Card className="overflow-hidden">
        {/* Vue tableau — desktop uniquement */}
        <div className="hidden overflow-x-auto md:block">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border bg-paper-dim text-ink-soft">
              <tr>
                <th className="px-4 py-3 font-medium">Produit</th>
                <th className="px-4 py-3 font-medium">Catégorie</th>
                <th className="px-4 py-3 font-medium">Prix</th>
                <th className="px-4 py-3 font-medium">Stock</th>
                <th className="px-4 py-3 font-medium">Statut</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-ink-faint">
                    Chargement…
                  </td>
                </tr>
              )}
              {!isLoading && products.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-ink-faint">
                    Aucun produit. Ajoutez votre premier article avec « Nouveau produit ».
                  </td>
                </tr>
              )}
              {products.map((product) => (
                <tr key={product.id} className="border-b border-border last:border-0 hover:bg-paper-dim/50">
                  <td className="px-4 py-3">
                    <p className="font-medium text-ink">{product.name}</p>
                    {product.sku && <p className="font-mono text-xs text-ink-faint">{product.sku}</p>}
                  </td>
                  <td className="px-4 py-3 text-ink-soft">{product.category}</td>
                  <td className="px-4 py-3">
                    {product.promotionPrice ? (
                      <span>
                        <span className="font-medium text-accent-dark">{product.promotionPrice.toLocaleString()}</span>{' '}
                        <span className="text-xs text-ink-faint line-through">{product.price.toLocaleString()}</span>
                      </span>
                    ) : (
                      <span>{product.price.toLocaleString()}</span>
                    )}
                  </td>
                  <td className="px-4 py-3 font-mono text-ink-soft">{product.stock}</td>
                  <td className="px-4 py-3">
                    <Badge tone={statusTone[product.status]}>{product.status}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => openEditForm(product)}
                        className="rounded p-1.5 text-ink-soft hover:bg-paper-dim"
                        aria-label={`Modifier ${product.name}`}
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      {product.status !== 'Archivé' && (
                        <button
                          onClick={() => handleArchive(product)}
                          className="rounded p-1.5 text-ink-soft hover:bg-paper-dim"
                          aria-label={`Archiver ${product.name}`}
                        >
                          <Archive className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Vue carte — mobile uniquement */}
        <div className="divide-y divide-border md:hidden">
          {isLoading && <p className="px-4 py-8 text-center text-ink-faint">Chargement…</p>}
          {!isLoading && products.length === 0 && (
            <p className="px-4 py-8 text-center text-ink-faint">
              Aucun produit. Ajoutez votre premier article avec « Nouveau produit ».
            </p>
          )}
          {products.map((product) => (
            <div key={product.id} className="flex items-start justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <p className="truncate font-medium text-ink">{product.name}</p>
                <p className="text-xs text-ink-faint">{product.category}</p>
                <div className="mt-1 flex items-center gap-2 text-sm">
                  {product.promotionPrice ? (
                    <>
                      <span className="font-medium text-accent-dark">
                        {product.promotionPrice.toLocaleString()}
                      </span>
                      <span className="text-xs text-ink-faint line-through">
                        {product.price.toLocaleString()}
                      </span>
                    </>
                  ) : (
                    <span className="font-medium">{product.price.toLocaleString()}</span>
                  )}
                  <span className="font-mono text-xs text-ink-faint">· stock {product.stock}</span>
                </div>
                <Badge tone={statusTone[product.status]} className="mt-1.5">
                  {product.status}
                </Badge>
              </div>
              <div className="flex flex-shrink-0 items-center gap-1">
                <button
                  onClick={() => openEditForm(product)}
                  className="rounded p-2 text-ink-soft hover:bg-paper-dim"
                  aria-label={`Modifier ${product.name}`}
                >
                  <Pencil className="h-4 w-4" />
                </button>
                {product.status !== 'Archivé' && (
                  <button
                    onClick={() => handleArchive(product)}
                    className="rounded p-2 text-ink-soft hover:bg-paper-dim"
                    aria-label={`Archiver ${product.name}`}
                  >
                    <Archive className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {formOpen && (
        <div className="fixed inset-0 z-10 flex items-center justify-center bg-ink/40 px-4">
          <Card className="w-full max-w-lg bg-paper">
            <div className="flex items-center justify-between border-b border-border px-5 py-4">
              <h2 className="font-semibold">{editing ? 'Modifier le produit' : 'Nouveau produit'}</h2>
              <button onClick={() => setFormOpen(false)} className="text-ink-faint hover:text-ink">
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="grid max-h-[70vh] grid-cols-1 gap-4 overflow-y-auto p-5 sm:grid-cols-2">
              <Input
                label="Nom"
                required
                className="sm:col-span-2"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
              <Input
                label="Catégorie"
                required
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
              />
              <Input
                label="Sous-catégorie"
                value={form.subCategory}
                onChange={(e) => setForm({ ...form, subCategory: e.target.value })}
              />
              <Input
                label="Prix (FCFA)"
                type="number"
                required
                min={0}
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
              />
              <Input
                label="Prix promo (optionnel)"
                type="number"
                min={0}
                value={form.promotionPrice}
                onChange={(e) => setForm({ ...form, promotionPrice: e.target.value })}
              />
              <Input
                label="Stock"
                type="number"
                min={0}
                value={form.stock}
                onChange={(e) => setForm({ ...form, stock: e.target.value })}
              />
              <Input label="SKU" value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} />
              <div className="sm:col-span-2 flex flex-col gap-1.5">
                <label className="text-sm font-medium text-ink-soft">Description</label>
                <textarea
                  rows={3}
                  className="rounded border border-border bg-paper px-3 py-2 text-sm focus:border-brand focus:outline-none"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>

              {formError && <p className="sm:col-span-2 text-sm text-danger">{formError}</p>}

              <div className="sm:col-span-2 flex justify-end gap-2 pt-2">
                <Button type="button" variant="ghost" onClick={() => setFormOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit" isLoading={isSaving}>
                  {editing ? 'Enregistrer' : 'Créer le produit'}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
}

'use client';

import { FormEvent, useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { apiFetch, ApiError } from '@/lib/api-client';
import { useAuth } from '@/lib/auth-context';
import { Card, CardBody, CardHeader } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { AiConfig, Business, TeamMember } from '@/lib/types';

function SavedNotice({ show }: { show: boolean }) {
  if (!show) return null;
  return <span className="text-xs font-medium text-success">Enregistré ✓</span>;
}

function BusinessSection() {
  const [business, setBusiness] = useState<Business | null>(null);
  const [saved, setSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    apiFetch<Business>('/business/me').then(setBusiness);
  }, []);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!business) return;
    setIsSaving(true);
    try {
      await apiFetch('/business/me', {
        method: 'PATCH',
        body: JSON.stringify({
          name: business.name,
          address: business.address,
          description: business.description,
          deliveryPolicy: business.deliveryPolicy,
          paymentPolicy: business.paymentPolicy,
          operatingHours: business.operatingHours,
        }),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setIsSaving(false);
    }
  };

  if (!business) return null;

  return (
    <Card>
      <CardHeader>
        <h2 className="font-semibold">Entreprise</h2>
        <p className="text-sm text-ink-soft">
          Ces informations sont utilisées telles quelles par l&rsquo;assistant IA pour répondre à vos clients.
        </p>
      </CardHeader>
      <CardBody>
        <form onSubmit={save} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input
            label="Nom"
            value={business.name}
            onChange={(e) => setBusiness({ ...business, name: e.target.value })}
          />
          <Input
            label="Adresse"
            value={business.address ?? ''}
            onChange={(e) => setBusiness({ ...business, address: e.target.value })}
          />
          <Input
            label="Politique de livraison"
            className="sm:col-span-2"
            value={business.deliveryPolicy ?? ''}
            onChange={(e) => setBusiness({ ...business, deliveryPolicy: e.target.value })}
          />
          <Input
            label="Politique de paiement"
            className="sm:col-span-2"
            value={business.paymentPolicy ?? ''}
            onChange={(e) => setBusiness({ ...business, paymentPolicy: e.target.value })}
          />
          <Input
            label="Horaires"
            className="sm:col-span-2"
            value={business.operatingHours ?? ''}
            onChange={(e) => setBusiness({ ...business, operatingHours: e.target.value })}
          />
          <div className="sm:col-span-2 flex items-center gap-3">
            <Button type="submit" isLoading={isSaving}>
              Enregistrer
            </Button>
            <SavedNotice show={saved} />
          </div>
        </form>
      </CardBody>
    </Card>
  );
}

function WhatsappSection() {
  const [business, setBusiness] = useState<Business | null>(null);
  const [saved, setSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    apiFetch<Business>('/business/me').then(setBusiness);
  }, []);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!business) return;
    setIsSaving(true);
    try {
      await apiFetch('/business/me', {
        method: 'PATCH',
        body: JSON.stringify({
          whatsappApiKey: business.whatsappApiKey,
          whatsappPhoneNumberId: business.whatsappPhoneNumberId,
        }),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setIsSaving(false);
    }
  };

  if (!business) return null;

  return (
    <Card>
      <CardHeader>
        <h2 className="font-semibold">Connexion WhatsApp Business</h2>
        <p className="text-sm text-ink-soft">
          Trouvez ces valeurs dans votre espace développeur Meta, sous votre app WhatsApp Business.
        </p>
      </CardHeader>
      <CardBody>
        <form onSubmit={save} className="grid grid-cols-1 gap-4">
          <Input
            label="Phone Number ID"
            value={business.whatsappPhoneNumberId ?? ''}
            onChange={(e) => setBusiness({ ...business, whatsappPhoneNumberId: e.target.value })}
          />
          <Input
            label="Access Token"
            type="password"
            value={business.whatsappApiKey ?? ''}
            onChange={(e) => setBusiness({ ...business, whatsappApiKey: e.target.value })}
          />
          <div className="flex items-center gap-3">
            <Button type="submit" isLoading={isSaving}>
              Enregistrer
            </Button>
            <SavedNotice show={saved} />
          </div>
        </form>
      </CardBody>
    </Card>
  );
}

function PaymentsSection() {
  const [business, setBusiness] = useState<Business | null>(null);
  const [saved, setSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    apiFetch<Business>('/business/me').then(setBusiness);
  }, []);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!business) return;
    setIsSaving(true);
    try {
      await apiFetch('/business/me', {
        method: 'PATCH',
        body: JSON.stringify({
          mtnMomoApiUserId: business.mtnMomoApiUserId,
          mtnMomoApiKey: business.mtnMomoApiKey,
          mtnMomoSubscriptionKey: business.mtnMomoSubscriptionKey,
          orangeMoneyMerchantKey: business.orangeMoneyMerchantKey,
          orangeMoneyApiKey: business.orangeMoneyApiKey,
          waveApiKey: business.waveApiKey,
        }),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setIsSaving(false);
    }
  };

  if (!business) return null;

  return (
    <Card>
      <CardHeader>
        <h2 className="font-semibold">Paiements Mobile Money</h2>
        <p className="text-sm text-ink-soft">
          Identifiants marchands MTN MoMo, Orange Money et Wave. Non testé contre de vrais comptes
          sandbox — à valider avec votre équipe technique avant mise en production.
        </p>
      </CardHeader>
      <CardBody>
        <form onSubmit={save} className="flex flex-col gap-6">
          <div>
            <p className="mb-2 text-sm font-medium text-ink">MTN Mobile Money</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <Input
                label="API User ID"
                value={business.mtnMomoApiUserId ?? ''}
                onChange={(e) => setBusiness({ ...business, mtnMomoApiUserId: e.target.value })}
              />
              <Input
                label="API Key"
                type="password"
                value={business.mtnMomoApiKey ?? ''}
                onChange={(e) => setBusiness({ ...business, mtnMomoApiKey: e.target.value })}
              />
              <Input
                label="Subscription Key"
                type="password"
                value={business.mtnMomoSubscriptionKey ?? ''}
                onChange={(e) => setBusiness({ ...business, mtnMomoSubscriptionKey: e.target.value })}
              />
            </div>
          </div>

          <div>
            <p className="mb-2 text-sm font-medium text-ink">Orange Money</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Input
                label="Merchant Key"
                value={business.orangeMoneyMerchantKey ?? ''}
                onChange={(e) => setBusiness({ ...business, orangeMoneyMerchantKey: e.target.value })}
              />
              <Input
                label="API Key"
                type="password"
                value={business.orangeMoneyApiKey ?? ''}
                onChange={(e) => setBusiness({ ...business, orangeMoneyApiKey: e.target.value })}
              />
            </div>
          </div>

          <div>
            <p className="mb-2 text-sm font-medium text-ink">Wave</p>
            <Input
              label="API Key"
              type="password"
              value={business.waveApiKey ?? ''}
              onChange={(e) => setBusiness({ ...business, waveApiKey: e.target.value })}
            />
          </div>

          <div className="flex items-center gap-3">
            <Button type="submit" isLoading={isSaving}>
              Enregistrer
            </Button>
            <SavedNotice show={saved} />
          </div>
        </form>
      </CardBody>
    </Card>
  );
}

function AiConfigSection() {
  const [config, setConfig] = useState<AiConfig | null>(null);
  const [saved, setSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [testMessage, setTestMessage] = useState('');
  const [testReply, setTestReply] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  useEffect(() => {
    apiFetch<AiConfig>('/ai/config').then(setConfig);
  }, []);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!config) return;
    setIsSaving(true);
    try {
      await apiFetch('/ai/config', { method: 'PATCH', body: JSON.stringify(config) });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setIsSaving(false);
    }
  };

  const runTest = async () => {
    if (!testMessage.trim()) return;
    setIsTesting(true);
    setTestReply(null);
    try {
      const result = await apiFetch<{ reply: string }>('/ai/config/test', {
        method: 'POST',
        body: JSON.stringify({ message: testMessage }),
      });
      setTestReply(result.reply);
    } catch (err) {
      setTestReply(err instanceof ApiError ? err.message : 'Test impossible.');
    } finally {
      setIsTesting(false);
    }
  };

  if (!config) return null;

  return (
    <Card>
      <CardHeader className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold">Assistant IA</h2>
          <p className="text-sm text-ink-soft">Le prompt système, la personnalité et le comportement de Dexora.</p>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={config.isActive}
            onChange={(e) => setConfig({ ...config, isActive: e.target.checked })}
          />
          Actif
        </label>
      </CardHeader>
      <CardBody className="flex flex-col gap-4">
        <form onSubmit={save} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-ink-soft">Prompt système</label>
            <textarea
              rows={8}
              value={config.systemPrompt}
              onChange={(e) => setConfig({ ...config, systemPrompt: e.target.value })}
              className="rounded border border-border bg-paper px-3 py-2 font-mono text-xs focus:border-brand focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-3">
            <Button type="submit" isLoading={isSaving}>
              Enregistrer
            </Button>
            <SavedNotice show={saved} />
          </div>
        </form>

        <div className="border-t border-border pt-4">
          <p className="mb-2 text-sm font-medium text-ink-soft">Tester l&rsquo;assistant</p>
          <div className="flex gap-2">
            <input
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              placeholder="Avez-vous des iPhone en stock ?"
              className="flex-1 rounded border border-border bg-paper px-3 py-2 text-sm focus:border-brand focus:outline-none"
            />
            <Button type="button" variant="secondary" onClick={runTest} isLoading={isTesting}>
              Tester
            </Button>
          </div>
          {testReply && (
            <div className="mt-3 rounded bg-paper-dim px-3 py-2 text-sm text-ink">{testReply}</div>
          )}
        </div>
      </CardBody>
    </Card>
  );
}

function TeamSection() {
  const { user } = useAuth();
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'AGENT' });
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const load = () => apiFetch<TeamMember[]>('/users/team').then(setTeam).catch(() => setTeam([]));

  useEffect(() => {
    load();
  }, []);

  if (user?.role === 'AGENT') return null; // Réservé à OWNER/MANAGER côté API de toute façon.

  const invite = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSaving(true);
    try {
      await apiFetch('/users/team', { method: 'POST', body: JSON.stringify(form) });
      setFormOpen(false);
      setForm({ name: '', email: '', password: '', role: 'AGENT' });
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Invitation impossible.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader className="flex items-center justify-between">
        <h2 className="font-semibold">Équipe</h2>
        <Button variant="secondary" onClick={() => setFormOpen((v) => !v)}>
          <Plus className="h-4 w-4" /> Inviter
        </Button>
      </CardHeader>
      <CardBody className="flex flex-col gap-4">
        {formOpen && (
          <form onSubmit={invite} className="grid grid-cols-1 gap-3 rounded border border-border p-4 sm:grid-cols-2">
            <Input label="Nom" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <Input
              label="Email"
              type="email"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
            <Input
              label="Mot de passe temporaire"
              type="password"
              required
              minLength={8}
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium text-ink-soft">Rôle</label>
              <select
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value })}
                className="rounded border border-border bg-paper px-3 py-2 text-sm focus:border-brand focus:outline-none"
              >
                <option value="AGENT">Agent</option>
                <option value="MANAGER">Manager</option>
              </select>
            </div>
            {error && <p className="sm:col-span-2 text-sm text-danger">{error}</p>}
            <Button type="submit" isLoading={isSaving} className="sm:col-span-2">
              Envoyer l&rsquo;invitation
            </Button>
          </form>
        )}

        <div className="divide-y divide-border">
          {team.map((member) => (
            <div key={member.id} className="flex items-center justify-between py-3">
              <div>
                <p className="text-sm font-medium text-ink">{member.name}</p>
                <p className="text-xs text-ink-faint">{member.email}</p>
              </div>
              <Badge tone={member.role === 'MANAGER' ? 'accent' : 'neutral'}>{member.role}</Badge>
            </div>
          ))}
        </div>
      </CardBody>
    </Card>
  );
}

export default function SettingsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-semibold">Réglages</h1>
        <p className="text-sm text-ink-soft">Entreprise, WhatsApp, assistant IA et équipe.</p>
      </div>

      <BusinessSection />
      <WhatsappSection />
      <PaymentsSection />
      <AiConfigSection />
      <TeamSection />
    </div>
  );
}

import { ImageResponse } from 'next/og';

export const runtime = 'edge';

export async function GET() {
  const size = 192;
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#2D2A5C',
        }}
      >
        <span
          style={{
            fontSize: 108,
            fontWeight: 700,
            color: '#E8A33D',
            fontFamily: 'sans-serif',
          }}
        >
          D
        </span>
      </div>
    ),
    { width: size, height: size },
  );
}

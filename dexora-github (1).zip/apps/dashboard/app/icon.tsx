import { ImageResponse } from 'next/og';

export const runtime = 'edge';
export const size = { width: 32, height: 32 };
export const contentType = 'image/png';

export default async function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#2D2A5C',
          borderRadius: 6,
        }}
      >
        <span style={{ fontSize: 20, fontWeight: 700, color: '#E8A33D', fontFamily: 'sans-serif' }}>D</span>
      </div>
    ),
    { ...size },
  );
}

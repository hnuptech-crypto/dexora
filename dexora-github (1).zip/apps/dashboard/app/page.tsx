'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { Loader2 } from 'lucide-react';

export default function RootPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (isLoading) return;
    router.replace(user ? '/overview' : '/login');
  }, [isLoading, user, router]);

  return (
    <div className="flex h-screen items-center justify-center bg-paper">
      <Loader2 className="h-6 w-6 animate-spin text-brand" />
    </div>
  );
}

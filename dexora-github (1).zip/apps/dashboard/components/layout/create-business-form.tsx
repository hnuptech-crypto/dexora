'use client';

import { FormEvent, useState } from 'react';
import { apiFetch, ApiError } from '@/lib/api-client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardBody, CardHeader } from '@/components/ui/card';

export function CreateBusinessForm({ onCreated }: { onCreated: () => void }) {
  const [form, setForm] = useState({ name: '', phone: '', whatsappNumber: '', address: '' });
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const update = (field: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    try {
      await apiFetch('/business', { method: 'POST', body: JSON.stringify(form) });
      onCreated();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Création impossible.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="mx-auto max-w-lg">
      <CardHeader>
        <h2 className="text-base font-semibold">Bienvenue sur Dexora IA 👋</h2>
        <p className="mt-1 text-sm text-ink-soft">
          Dernière étape : décrivez votre entreprise pour activer le catalogue, WhatsApp et l&rsquo;IA.
        </p>
      </CardHeader>
      <CardBody>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <Input label="Nom de l'entreprise" required value={form.name} onChange={update('name')} />
          <Input
            label="Téléphone de contact"
            required
            placeholder="+229 00 00 00 00"
            value={form.phone}
            onChange={update('phone')}
          />
          <Input
            label="Numéro WhatsApp Business"
            required
            placeholder="+229 00 00 00 00"
            value={form.whatsappNumber}
            onChange={update('whatsappNumber')}
          />
          <Input label="Adresse (optionnel)" value={form.address} onChange={update('address')} />

          {error && <p className="text-sm text-danger">{error}</p>}

          <Button type="submit" isLoading={isLoading}>
            Créer mon entreprise
          </Button>
        </form>
      </CardBody>
    </Card>
  );
}

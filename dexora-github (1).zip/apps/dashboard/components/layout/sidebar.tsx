'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  MessageCircle,
  Package,
  ShoppingBag,
  Users,
  Megaphone,
  BarChart3,
  Settings,
  X,
} from 'lucide-react';

const navItems = [
  { href: '/overview', label: "Vue d'ensemble", icon: LayoutDashboard },
  { href: '/conversations', label: 'Conversations', icon: MessageCircle },
  { href: '/products', label: 'Catalogue', icon: Package },
  { href: '/orders', label: 'Commandes', icon: ShoppingBag },
  { href: '/customers', label: 'Clients', icon: Users },
  { href: '/campaigns', label: 'Campagnes', icon: Megaphone },
  { href: '/analytics', label: 'Analytics', icon: BarChart3 },
  { href: '/settings', label: 'Réglages', icon: Settings },
];

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname();

  return (
    <>
      {/* Fond sombre derrière le tiroir, mobile uniquement */}
      {isOpen && (
        <button
          aria-label="Fermer le menu"
          onClick={onClose}
          className="fixed inset-0 z-20 bg-ink/40 md:hidden"
        />
      )}

      <aside
        className={`seam-border fixed inset-y-0 left-0 z-30 flex w-64 flex-shrink-0 flex-col bg-brand text-paper
          transition-transform duration-200 ease-out
          md:static md:z-auto md:w-60 md:translate-x-0
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="flex items-center justify-between px-5 py-6">
          <span className="font-display text-xl font-semibold">Dexora IA</span>
          <button onClick={onClose} className="text-paper/70 hover:text-paper md:hidden" aria-label="Fermer">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3">
          {navItems.map(({ href, label, icon: Icon }) => {
            const isActive = pathname?.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                onClick={onClose}
                className={`flex items-center gap-3 rounded px-3 py-2.5 text-sm transition-colors
                  ${isActive ? 'bg-white/10 font-medium text-paper' : 'text-paper/70 hover:bg-white/5 hover:text-paper'}`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="px-5 py-4 text-xs text-paper/50">Dexora IA · v0.1</div>
      </aside>
    </>
  );
}

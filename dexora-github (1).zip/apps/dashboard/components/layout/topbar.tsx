'use client';

import { LogOut, Menu } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';

const roleLabels: Record<string, string> = {
  OWNER: 'Propriétaire',
  MANAGER: 'Manager',
  AGENT: 'Agent',
};

interface TopbarProps {
  onMenuClick: () => void;
}

export function Topbar({ onMenuClick }: TopbarProps) {
  const { user, logout } = useAuth();

  return (
    <header className="flex h-14 flex-shrink-0 items-center justify-between border-b border-border bg-paper px-4 sm:h-16 sm:px-6">
      <button
        onClick={onMenuClick}
        className="rounded p-2 text-ink-soft hover:bg-paper-dim md:hidden"
        aria-label="Ouvrir le menu"
      >
        <Menu className="h-5 w-5" />
      </button>
      <div className="hidden md:block" />

      <div className="flex items-center gap-3 sm:gap-4">
        {user && (
          <div className="hidden text-right sm:block">
            <p className="text-sm font-medium text-ink">{user.name}</p>
            <p className="text-xs text-ink-faint">{roleLabels[user.role] ?? user.role}</p>
          </div>
        )}
        <button
          onClick={() => logout()}
          className="flex items-center gap-2 rounded px-2 py-1.5 text-sm text-ink-soft hover:bg-paper-dim"
        >
          <LogOut className="h-4 w-4" />
          <span className="hidden sm:inline">Déconnexion</span>
        </button>
      </div>
    </header>
  );
}

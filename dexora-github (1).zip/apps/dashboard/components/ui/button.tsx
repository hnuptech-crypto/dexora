import { ButtonHTMLAttributes, forwardRef } from 'react';
import { Loader2 } from 'lucide-react';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  isLoading?: boolean;
}

const variantClasses: Record<string, string> = {
  primary: 'bg-brand text-paper hover:bg-brand-light disabled:bg-brand/50',
  secondary: 'bg-paper-dim text-ink border border-border hover:bg-border/60',
  ghost: 'bg-transparent text-ink-soft hover:bg-paper-dim',
  danger: 'bg-danger text-paper hover:bg-danger/90',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className = '', variant = 'primary', isLoading, disabled, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={`inline-flex items-center justify-center gap-2 rounded px-4 py-2 text-sm font-medium
          transition-colors disabled:cursor-not-allowed ${variantClasses[variant]} ${className}`}
        {...props}
      >
        {isLoading && <Loader2 className="h-4 w-4 animate-spin" />}
        {children}
      </button>
    );
  },
);
Button.displayName = 'Button';

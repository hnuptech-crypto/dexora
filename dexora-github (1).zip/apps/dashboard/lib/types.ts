export type UserRole = 'OWNER' | 'MANAGER' | 'AGENT';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  businessId: string | null;
  phoneNumber: string | null;
}

export interface Business {
  id: string;
  name: string;
  phone: string;
  whatsappNumber: string;
  whatsappPhoneNumberId: string | null;
  whatsappApiKey: string | null;
  address: string | null;
  description: string | null;
  currency: string;
  deliveryPolicy: string | null;
  paymentPolicy: string | null;
  operatingHours: string | null;
  mtnMomoApiUserId: string | null;
  mtnMomoApiKey: string | null;
  mtnMomoSubscriptionKey: string | null;
  orangeMoneyMerchantKey: string | null;
  orangeMoneyApiKey: string | null;
  waveApiKey: string | null;
}

export interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  promotionPrice: number | null;
  stock: number;
  sku: string | null;
  category: string;
  subCategory: string | null;
  images: string[];
  tags: string[];
  isAvailable: boolean;
  isArchived: boolean;
  status: 'Disponible' | 'Rupture' | 'Archivé';
  createdAt: string;
}

export interface Customer {
  id: string;
  phoneNumber: string;
  name: string | null;
  email: string | null;
  address: string | null;
  totalSpent: number;
  totalOrders: number;
  lastPurchaseAt: string | null;
  firstInteractionAt: string;
  lastInteractionAt: string;
  tags: string[];
  notes: string | null;
  orders?: Order[];
  conversations?: Conversation[];
}

export type ConversationStatus = 'NEW' | 'INTERESTED' | 'ORDER' | 'CUSTOMER' | 'RESOLVED' | 'ARCHIVED';
export type Priority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
export type SenderType = 'CUSTOMER' | 'USER' | 'SYSTEM' | 'AI';

export interface TeamMemberRef {
  id: string;
  name: string;
  email: string;
}

export interface Message {
  id: string;
  content: string;
  senderType: SenderType;
  mediaType: string | null;
  mediaUrl: string | null;
  isDelivered: boolean;
  isRead: boolean;
  createdAt: string;
}

export interface Conversation {
  id: string;
  status: ConversationStatus;
  priority: Priority;
  unreadCount: number;
  aiHandled: boolean;
  lastMessageAt: string;
  customer: Customer;
  assignedTo: TeamMemberRef | null;
  messages?: Message[];
}

export type OrderStatus = 'NEW' | 'CONFIRMED' | 'PREPARING' | 'DELIVERING' | 'DELIVERED' | 'CANCELLED';

export interface OrderItem {
  id: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export type PaymentProvider = 'MTN_MOMO' | 'ORANGE_MONEY' | 'WAVE';
export type PaymentTransactionStatus = 'PENDING' | 'SUCCESSFUL' | 'FAILED' | 'EXPIRED';

export interface Payment {
  id: string;
  provider: PaymentProvider;
  checkoutUrl: string | null;
  amount: number;
  currency: string;
  status: PaymentTransactionStatus;
  createdAt: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  status: OrderStatus;
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  deliveryAddress: string | null;
  paymentMethod: string | null;
  paymentStatus: string;
  createdAt: string;
  customer: Customer;
  items: OrderItem[];
  assignedTo?: TeamMemberRef | null;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phoneNumber: string | null;
  isActive: boolean;
  createdAt: string;
}

export interface AiConfig {
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
  model: string;
  isActive: boolean;
}

export type CampaignType = 'PROMOTION' | 'REMINDER' | 'ANNOUNCEMENT' | 'FOLLOWUP';
export type CampaignStatus = 'DRAFT' | 'SCHEDULED' | 'SENDING' | 'SENT' | 'CANCELLED';

export interface SegmentFilter {
  search?: string;
  tag?: string;
  minSpent?: number;
  inactiveSinceDays?: number;
}

export interface Campaign {
  id: string;
  name: string;
  type: CampaignType;
  message: string;
  mediaUrl: string | null;
  status: CampaignStatus;
  scheduledAt: string | null;
  sentAt: string | null;
  sentCount: number;
  deliveredCount: number;
  respondedCount: number;
  convertedCount: number;
  createdAt: string;
  targetSegments: { id: string; segmentName: string; filter: SegmentFilter }[];
}

export interface Opportunity {
  label: string;
  count: number;
  suggestedFilter: SegmentFilter | null;
}

export interface OpportunitiesSummary {
  interestedNoOrder: Opportunity;
  inactive90Days: Opportunity;
  vipCustomers: Opportunity;
}

export interface AnalyticsSummary {
  period: 'today' | 'week' | 'month';
  since: string;
  newConversations: number;
  newOrders: number;
  revenue: number;
  conversionRate: number;
  topProducts: { productId: string; name: string; quantitySold: number; revenue: number }[];
  alerts: {
    lowStock: { id: string; name: string; stock: number }[];
    lateOrders: number;
  };
  aiPerformance: {
    totalInteractions: number;
    resolutionRate: number | null;
  };
}

export interface Paginated<T> {
  items: T[];
  pagination: { page: number; limit: number; total: number; totalPages: number };
}

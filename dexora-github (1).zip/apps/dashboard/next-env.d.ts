/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: ce fichier est normalement régénéré automatiquement par `next dev`
// ou `next build`. Il est inclus ici pour que `tsc` fonctionne dès le premier
// clone, avant même le premier démarrage du serveur de dev.

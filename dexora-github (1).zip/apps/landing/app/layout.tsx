import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Dexora IA — L\u2019intelligence commerciale au service de votre WhatsApp',
  description:
    "Dexora IA transforme votre WhatsApp en boutique automatisée : catalogue, assistant IA, commandes et clients gérés depuis une interface unique.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}

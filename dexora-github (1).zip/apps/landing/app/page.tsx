import { Nav } from '@/components/sections/nav';
import { Hero } from '@/components/sections/hero';
import { Problem } from '@/components/sections/problem';
import { HowItWorks } from '@/components/sections/how-it-works';
import { Features } from '@/components/sections/features';
import { Regions } from '@/components/sections/regions';
import { FinalCta } from '@/components/sections/final-cta';
import { Footer } from '@/components/sections/footer';

export default function HomePage() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Problem />
        <HowItWorks />
        <Features />
        <Regions />
        <FinalCta />
      </main>
      <Footer />
    </>
  );
}

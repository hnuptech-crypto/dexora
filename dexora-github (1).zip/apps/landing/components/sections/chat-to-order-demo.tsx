'use client';

import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, Bot } from 'lucide-react';

interface Step {
  bubble: { from: 'customer' | 'ai'; text: string };
  field?: { label: string; value: string };
}

const steps: Step[] = [
  { bubble: { from: 'customer', text: 'Avez-vous l\u2019iPhone 13 Pro Max en stock ?' } },
  {
    bubble: { from: 'ai', text: 'Oui ! 420\u00A0000 FCFA, il en reste 5 en stock.' },
    field: { label: 'Produit', value: 'iPhone 13 Pro Max' },
  },
  {
    bubble: { from: 'customer', text: 'Je le prends, livraison à Cotonou svp.' },
    field: { label: 'Livraison', value: 'Cotonou' },
  },
  {
    bubble: { from: 'ai', text: 'Commande confirmée \u2705 DEXORA-20260829-004' },
    field: { label: 'Statut', value: 'Nouvelle commande' },
  },
];

const CYCLE_MS = 2400;

export function ChatToOrderDemo() {
  const [visibleSteps, setVisibleSteps] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setVisibleSteps((v) => (v >= steps.length ? 0 : v + 1));
    }, CYCLE_MS);
    return () => clearInterval(interval);
  }, []);

  const activeSteps = steps.slice(0, visibleSteps);
  const fields = activeSteps.map((s) => s.field).filter(Boolean) as { label: string; value: string }[];

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      {/* Colonne WhatsApp */}
      <div className="flex min-h-[280px] flex-col justify-end gap-2 rounded-xl border border-border bg-white p-4 shadow-soft">
        <p className="mb-1 text-xs font-medium uppercase tracking-wide text-ink-faint">WhatsApp</p>
        <AnimatePresence initial={false}>
          {activeSteps.map((step, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex ${step.bubble.from === 'customer' ? 'justify-start' : 'justify-end'}`}
            >
              <div
                className={`max-w-[85%] rounded-lg px-3 py-2 text-sm ${
                  step.bubble.from === 'customer' ? 'bg-paper-dim text-ink' : 'bg-brand text-paper'
                }`}
              >
                {step.bubble.from === 'ai' && (
                  <span className="mb-0.5 flex items-center gap-1 text-[10px] font-medium text-paper/70">
                    <Bot className="h-3 w-3" /> Dexora
                  </span>
                )}
                {step.bubble.text}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Colonne commande structurée */}
      <div className="flex min-h-[280px] flex-col rounded-xl border border-border bg-white p-4 shadow-soft">
        <p className="mb-3 text-xs font-medium uppercase tracking-wide text-ink-faint">Commande Dexora</p>
        <div className="flex flex-1 flex-col justify-center gap-3">
          <AnimatePresence>
            {fields.map((field) => (
              <motion.div
                key={field.label}
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="flex items-center justify-between border-b border-border pb-2 text-sm"
              >
                <span className="text-ink-faint">{field.label}</span>
                <span className="flex items-center gap-1.5 font-medium text-ink">
                  {field.value}
                  {field.label === 'Statut' && (
                    <span className="flex h-4 w-4 items-center justify-center rounded-full bg-success text-white">
                      <Check className="h-2.5 w-2.5" />
                    </span>
                  )}
                </span>
              </motion.div>
            ))}
          </AnimatePresence>
          {fields.length === 0 && (
            <p className="text-center text-sm text-ink-faint">En attente du prochain message…</p>
          )}
        </div>
      </div>
    </div>
  );
}

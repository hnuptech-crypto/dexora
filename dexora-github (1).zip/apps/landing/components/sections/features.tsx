import {
  Package,
  Bot,
  Inbox,
  Users,
  BellRing,
  BarChart3,
  Wallet,
  UserCog,
} from 'lucide-react';
import { Reveal } from '../ui/reveal';

const features = [
  {
    icon: Package,
    title: 'Catalogue intelligent',
    text: 'Photos, prix en FCFA, variantes, stock — importés en CSV ou ajoutés un par un, avec liens de partage générés automatiquement.',
  },
  {
    icon: Bot,
    title: 'Assistant IA disponible 24h/24',
    text: 'Comprend le langage naturel, propose des alternatives, qualifie les prospects et transmet les cas complexes à un humain.',
  },
  {
    icon: Inbox,
    title: 'Boîte de réception unifiée',
    text: 'Toutes vos conversations WhatsApp au même endroit, filtrables par statut, assignables à votre équipe.',
  },
  {
    icon: Users,
    title: 'Mini CRM client',
    text: 'Historique d\u2019achats, tags automatiques, segments dynamiques — chaque client devient une fiche exploitable, pas juste un numéro.',
  },
  {
    icon: BellRing,
    title: 'Relance intelligente',
    text: 'Détecte les clients intéressés sans commande, les inactifs, et lance des campagnes ciblées sans jamais spammer.',
  },
  {
    icon: BarChart3,
    title: 'Tableau de bord & analytics',
    text: 'Chiffre d\u2019affaires, taux de conversion, top produits, alertes de stock — la vue que WhatsApp ne vous donnera jamais.',
  },
  {
    icon: Wallet,
    title: 'Paiements adaptés à l\u2019Afrique',
    text: 'Mobile Money, paiement à la livraison, et bientôt Wave — pensé pour vos moyens de paiement réels.',
  },
  {
    icon: UserCog,
    title: 'Gestion d\u2019équipe',
    text: 'Rôles Propriétaire / Manager / Agent, avec des permissions adaptées à chacun.',
  },
];

export function Features() {
  return (
    <section id="fonctionnalites" className="border-t border-border bg-paper-dim">
      <div className="mx-auto max-w-6xl px-6 py-20">
        <Reveal>
          <h2 className="text-center text-2xl font-semibold sm:text-3xl">
            Tout ce qu&rsquo;il faut pour vendre sérieusement sur WhatsApp
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={(i % 4) * 0.06}>
              <div className="h-full rounded-lg border border-border bg-white p-5">
                <f.icon className="h-5 w-5 text-brand" />
                <h3 className="mt-3 text-sm font-semibold text-ink">{f.title}</h3>
                <p className="mt-1.5 text-sm text-ink-soft">{f.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

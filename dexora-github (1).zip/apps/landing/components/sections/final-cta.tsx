import { ArrowRight } from 'lucide-react';
import { Reveal } from '../ui/reveal';

const DASHBOARD_URL = process.env.NEXT_PUBLIC_DASHBOARD_URL ?? 'http://localhost:3001';

export function FinalCta() {
  return (
    <section className="bg-brand">
      <div className="mx-auto max-w-3xl px-6 py-20 text-center">
        <Reveal>
          <h2 className="text-2xl font-semibold text-paper sm:text-3xl">
            Votre prochain client WhatsApp mérite une réponse en 5 secondes, pas en 5 heures.
          </h2>
        </Reveal>
        <Reveal delay={0.08}>
          <a
            href={`${DASHBOARD_URL}/register`}
            className="mt-8 inline-flex items-center gap-2 rounded bg-accent px-6 py-3 text-sm font-medium text-ink hover:bg-accent-dark hover:text-paper"
          >
            Commencer gratuitement <ArrowRight className="h-4 w-4" />
          </a>
        </Reveal>
      </div>
    </section>
  );
}

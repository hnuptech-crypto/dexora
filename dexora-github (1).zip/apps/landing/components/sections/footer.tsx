export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-10 sm:flex-row">
        <span className="font-display font-semibold text-brand">Dexora IA</span>
        <p className="text-sm text-ink-faint">
          contact@dexora.ai · &copy; {new Date().getFullYear()} Dexora IA. Tous droits réservés.
        </p>
      </div>
    </footer>
  );
}

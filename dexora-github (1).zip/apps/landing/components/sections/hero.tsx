import { ArrowRight } from 'lucide-react';
import { Reveal } from '../ui/reveal';
import { ChatToOrderDemo } from './chat-to-order-demo';

const DASHBOARD_URL = process.env.NEXT_PUBLIC_DASHBOARD_URL ?? 'http://localhost:3001';

export function Hero() {
  return (
    <section className="mx-auto max-w-6xl px-6 pb-20 pt-16 sm:pt-24">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <div>
          <Reveal>
            <span className="inline-block rounded-full bg-accent-soft px-3 py-1 text-xs font-medium text-accent-dark">
              Fait pour le commerce WhatsApp en Afrique
            </span>
          </Reveal>

          <Reveal delay={0.05}>
            <h1 className="mt-5 text-4xl font-semibold leading-[1.1] sm:text-5xl">
              Votre WhatsApp vend déjà.
              <br />
              <span className="text-brand">Donnez-lui une mémoire.</span>
            </h1>
          </Reveal>

          <Reveal delay={0.1}>
            <p className="mt-5 max-w-md text-lg text-ink-soft">
              Dexora transforme vos conversations WhatsApp en catalogue, commandes et fiches
              clients structurées — avec un assistant IA qui répond, vend et prend les commandes
              24h/24, sans jamais inventer un prix.
            </p>
          </Reveal>

          <Reveal delay={0.15}>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a
                href={`${DASHBOARD_URL}/register`}
                className="flex items-center gap-2 rounded bg-brand px-5 py-3 text-sm font-medium text-paper hover:bg-brand-light"
              >
                Commencer gratuitement <ArrowRight className="h-4 w-4" />
              </a>
              <a href="#comment-ca-marche" className="text-sm font-medium text-ink-soft hover:text-ink">
                Voir comment ça marche
              </a>
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <p className="mt-6 text-xs text-ink-faint">
              Aucune carte bancaire requise · Prise en main en 5 minutes
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.1}>
          <ChatToOrderDemo />
        </Reveal>
      </div>
    </section>
  );
}

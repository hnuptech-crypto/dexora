import { Reveal } from '../ui/reveal';

const steps = [
  {
    number: '01',
    title: 'Votre client écrit sur WhatsApp',
    text: 'Comme d\u2019habitude — aucun changement pour lui. Pas d\u2019app à installer, pas de nouveau numéro.',
  },
  {
    number: '02',
    title: 'Dexora répond, avec vos vraies données',
    text: 'Prix, stock, politique de livraison : l\u2019IA ne répond qu\u2019à partir de votre catalogue réel, jamais de mémoire.',
  },
  {
    number: '03',
    title: 'La commande se crée toute seule',
    text: 'Une fois le client confirmé, la commande est enregistrée, le stock ajusté, la fiche client mise à jour.',
  },
  {
    number: '04',
    title: 'Vous pilotez tout depuis un seul endroit',
    text: 'Inbox, commandes, clients, relances et statistiques — votre équipe travaille depuis un tableau de bord, pas depuis WhatsApp.',
  },
];

export function HowItWorks() {
  return (
    <section id="comment-ca-marche" className="mx-auto max-w-6xl px-6 py-20">
      <Reveal>
        <h2 className="text-center text-2xl font-semibold sm:text-3xl">Comment ça marche</h2>
      </Reveal>

      <div className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((step, i) => (
          <Reveal key={step.number} delay={i * 0.08}>
            <span className="font-display text-3xl font-semibold text-border">{step.number}</span>
            <h3 className="mt-3 font-semibold text-ink">{step.title}</h3>
            <p className="mt-2 text-sm text-ink-soft">{step.text}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

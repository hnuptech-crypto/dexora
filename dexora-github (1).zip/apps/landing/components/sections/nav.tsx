const DASHBOARD_URL = process.env.NEXT_PUBLIC_DASHBOARD_URL ?? 'http://localhost:3001';

const links = [
  { href: '#fonctionnalites', label: 'Fonctionnalités' },
  { href: '#comment-ca-marche', label: 'Comment ça marche' },
  { href: '#zones', label: 'Zones desservies' },
];

export function Nav() {
  return (
    <header className="sticky top-0 z-10 border-b border-border bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <span className="font-display text-lg font-semibold text-brand">Dexora IA</span>

        <nav className="hidden gap-8 text-sm text-ink-soft md:flex">
          {links.map((link) => (
            <a key={link.href} href={link.href} className="hover:text-ink">
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a href={`${DASHBOARD_URL}/login`} className="text-sm font-medium text-ink-soft hover:text-ink">
            Se connecter
          </a>
          <a
            href={`${DASHBOARD_URL}/register`}
            className="rounded bg-brand px-4 py-2 text-sm font-medium text-paper hover:bg-brand-light"
          >
            Commencer gratuitement
          </a>
        </div>
      </div>
    </header>
  );
}

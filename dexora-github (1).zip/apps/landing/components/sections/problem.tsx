import { Reveal } from '../ui/reveal';

export function Problem() {
  return (
    <section className="border-y border-border bg-paper-dim">
      <div className="mx-auto max-w-4xl px-6 py-20 text-center">
        <Reveal>
          <h2 className="text-2xl font-semibold sm:text-3xl">
            Des milliers de contacts. Des centaines de produits.
            <br />
            Zéro base de données.
          </h2>
        </Reveal>
        <Reveal delay={0.05}>
          <p className="mx-auto mt-5 max-w-2xl text-ink-soft">
            Vous vendez déjà sur WhatsApp — mais chaque vente vit et meurt dans une conversation.
            Impossible de savoir qui a acheté quoi, qui attend une relance, ou quel produit part le
            plus vite. Votre business tourne, mais il est enfermé dans un fil de discussion que
            vous seul(e) pouvez lire.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

import { Reveal } from '../ui/reveal';

const regions = ['Bénin', 'Togo', 'Côte d\u2019Ivoire', 'Sénégal', 'Cameroun', 'Burkina Faso', 'Guinée'];

export function Regions() {
  return (
    <section id="zones" className="mx-auto max-w-4xl px-6 py-20 text-center">
      <Reveal>
        <h2 className="text-2xl font-semibold sm:text-3xl">Pensé pour les réalités africaines</h2>
        <p className="mx-auto mt-4 max-w-xl text-ink-soft">
          FCFA, Mobile Money, langues locales — Dexora est construit pour les commerçants qui
          vendent déjà sur WhatsApp dans ces pays.
        </p>
      </Reveal>

      <Reveal delay={0.1}>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          {regions.map((region) => (
            <span
              key={region}
              className="rounded-full border border-border bg-white px-4 py-2 text-sm font-medium text-ink-soft"
            >
              {region}
            </span>
          ))}
        </div>
      </Reveal>
    </section>
  );
}

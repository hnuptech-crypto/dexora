import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#FAF7F2',
        'paper-dim': '#F1ECE1',
        ink: '#1C1B29',
        'ink-soft': '#5B5872',
        'ink-faint': '#8B87A0',
        brand: {
          DEFAULT: '#2D2A5C',
          light: '#413C82',
          dark: '#181731',
        },
        accent: {
          DEFAULT: '#E8A33D',
          dark: '#C97F1F',
          soft: '#FBEBD2',
        },
        success: { DEFAULT: '#2F9E7C', soft: '#DCF1EA' },
        danger: { DEFAULT: '#C24444', soft: '#F6E1E1' },
        border: '#E4DFD3',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      borderRadius: {
        DEFAULT: '8px',
        lg: '12px',
        xl: '20px',
      },
      boxShadow: {
        soft: '0 1px 2px 0 rgb(28 27 41 / 0.04), 0 1px 3px 0 rgb(28 27 41 / 0.06)',
        lifted: '0 20px 60px -15px rgb(45 42 92 / 0.35)',
      },
    },
  },
  plugins: [],
};

export default config;
